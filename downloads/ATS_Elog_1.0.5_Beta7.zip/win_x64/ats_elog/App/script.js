// === BUILD STAMP ===
// Conservé uniquement dans la console de développement. Il ne doit jamais
// masquer le bas de l'interface utilisateur.
window.ATS_ELOG_BUILD = "1.0.5";
console.log("%cATS Elog " + window.ATS_ELOG_BUILD,
  "background:#111;color:#0f0;padding:2px 6px;border-radius:4px;font-weight:700");

// Une fenêtre PC peut être étroite : ne pas l'assimiler à un mobile sur la
// seule largeur d'écran. Cette classe pilote les liens de contact et l'APK.
if (/android|iphone|ipad|ipod/i.test(navigator.userAgent || '')) {
  document.documentElement.classList.add('mobile-client');
  document.addEventListener('DOMContentLoaded', () => document.body.classList.add('mobile-client'), { once:true });
}

// ===== RODS TZ PLAN (fuseau réglementaire figé par journée) =====
const RODS_TZ_PLAN_KEY = 'atselog.rods.tz_plan';

function _loadRodsTzPlan(){
  try { return JSON.parse(localStorage.getItem(RODS_TZ_PLAN_KEY)||'{}') || {}; } catch { return {}; }
}
function _saveRodsTzPlan(p){
  try { localStorage.setItem(RODS_TZ_PLAN_KEY, JSON.stringify(p)); } catch {}
}

// --- HTZ courant (fuseau HQ basé sur le QG / cache index) ---
function getCurrentHTZKey() {
  // 1) Essaye de lire le cache atselog.tz écrit par index.html
  try {
    const cache = JSON.parse(localStorage.getItem('atselog.tz') || 'null');
    if (cache && typeof cache.key === 'string' && cache.key) {
      // ex: "pac", "mtn", "cen", "est"
      return cache.key;
    }
  } catch (_) {}

  // 2) Fallback basé sur la ville du QG si dispo
  try {
    const slug =
      localStorage.getItem('atselog.hq_city') ||
      localStorage.getItem('atselog.htz.raw_city') ||
      '';
    if (slug && typeof getCityBySlugSmart === 'function') {
      const city = getCityBySlugSmart(slug);
      if (city) {
        if (typeof city.tzKey === 'string' && city.tzKey) return city.tzKey;
        const key = tzKeyForState(city.state || city.country || '');
        if (key) return key;
      }
    }
  } catch (_) {}

  // 3) Fallback ultime : HEURE DE BASE DU JEU (MDT)
  //    → on force 'mtn' (offset 0 dans ta table TZ)
  return 'mtn';
}



// Id de "jour RODS" (entier) selon baseDay/baseMin + fuseau HTZ
function getRodDayId(baseDay, baseMin, htzKey){
  const offMin = (TZ[htzKey]?.off || 0) * 60;
  return baseDay + Math.floor((baseMin + offMin) / 1440);
}

// Lecture du tzKey RODS pour un jour donné
function getRodsTzKeyForDay(rodDayId){
  const plan = _loadRodsTzPlan();
  const rec  = plan[rodDayId];
  if (rec?.key && TZ[rec.key]) return rec.key;
  return getCurrentHTZKey();
}

// Programmer le nouveau tz "à partir de demain RODS"
function scheduleRodsTzChangeForTomorrow(baseDay, baseMin, oldKey, newKey){
  if (!newKey || newKey===oldKey) return false;
  const todayId  = getRodDayId(baseDay, baseMin, oldKey);
  const tomorrow = todayId + 1;
  const plan = _loadRodsTzPlan();
  plan[tomorrow] = {
    key: newKey,
    abbr: TZ[newKey]?.abbr || '',
    hq: (localStorage.getItem('atselog.hq_city')||''),
    ts: Date.now()
  };
  _saveRodsTzPlan(plan);
  return true;
}


console.log("ATS Elog script chargé !");
window.lastSentOffset = null;
// Source finale de villes (priorité Sheet)
window.citiesFinal = [];
window.citiesReady = false;   // false ⇒ on n'affiche pas de ville

const endpoint = "/data91";
const refreshMs = 1000;
let lastCity = "";
let lastState = "";
let lastTz = null;
let lastCitySent = "";
let lastStateSent = "";
let stableCity = null;
let pendingCityKey = "";
let pendingCityHits = 0;

// Préférence purement visuelle, conservée sur chaque appareil. On l'applique
// avant le rendu de la page afin d'éviter un flash blanc la nuit.
function applyElogTheme() {
  const dark = localStorage.getItem('atselog.theme') === 'dark';
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  const control = document.getElementById('darkMode');
  if (control) control.checked = dark;
}
applyElogTheme();
window.addEventListener('storage', event => {
  if (event.key === 'atselog.theme') applyElogTheme();
});
document.addEventListener('DOMContentLoaded', () => {
  applyElogTheme();
  const control = document.getElementById('darkMode');
  if (!control) return;
  control.addEventListener('change', () => {
    localStorage.setItem('atselog.theme', control.checked ? 'dark' : 'light');
    applyElogTheme();
  });
});

const translations = {
  fr: {
    hos: "HOS",
    home: "Accueil",
    settings: "Réglages",
    logs: "LogBooks",
    about: "À propos",
	dev:"Contribution",
	titre_about: "ATS Elog — A propos", 
    rest_in: "Repos",
    drive_rem: "Conduite restante",
    rest_Rem: "Service restant",
    cycle_rem: "Cycle 70h/8 jours",
    language: "Langue",
    dark_mode: "Mode sombre",
   
   // libellés Fuseau Horaire
	tz_label: "Fuseau horaire",
	tz_mode_off:  "Désactivé (heure de base)",
	tz_mode_auto: "Automatique (position)",
	tz_mode_htz:  "Terminal d’attache (HTZ)",

	// statuts Fuseau Horaire
	tz_status_off:  "Source : Désactivé (heure de base)",
	tz_status_auto: "Source : Automatique (position)",
	tz_status_htz:  "Source : Terminal d’attache (HTZ)",

	// actions / aide Fuseau Horaire 
	tz_detect_hq_btn: "Détecter le QG maintenant",
	htz_tooltip:
	"ATS Elog lit automatiquement le QG depuis la dernière sauvegarde, sans modifier votre partie.",
   
    endpoint: "Endpoint données",
    save: "Enregistrer",
    saved: "Sauvegardé !",
    editChauffeur: "Nom du Conducteur",
	// ↓↓ mise a jours a faire dans les autres langues ↓↓
	vehicules_btn: "🗂️ Vehicules",		
	elog_day: "Jour",
	elog_week: "Semaine",
	villeActuelle: "Ville",
	elEtat: "État / Province",
	pays: "Pays",
	immat_non_def: "⚠️ Merci de renseigner les plaques des remorques secondaires dans la page VEHICULES pour respecter la réglementation de ce convoi !", //plaque supp a informer
	trailer_model: "Type",
	trailer: "Remorque",
	trailer1: "Trailer 1",
	trailer2: "Trailer 2",
	trailer3: "Trailer 3",
	plate_placeholder: "Mettre plaque d’immatriculation",
	saveTrailerPlates: "Enregistrer plaques secondaires",
	vehicules: "Véhicules",
	camion: "Camion",
	marque: "Marque",
	modele: "Modèle",
	plaque_immat_truck: "Plaque d'immatriculation",
	
	
	overlay_move: "Deplacer l'Overlay",
	copyright: "©2025 ATS Elog développé par Eric R",
	version: "",
	
	reset_cache: "Reinitialiser le cache de l'overlay",
	
	a_propos_txt1:"Informations",
	a_propos_txt2: "Je suis camionneur de métier et passionné de simulation. ATS Elog est un projet personnel que je développe seul : je ne suis pas codeur, j’apprends en avançant, en cherchant les infos et en testant.",
	a_propos_txt3: "Je me heurte souvent à des obstacles, mais je finis toujours par les surmonter. Merci pour votre patience et votre soutien.",
	a_propos_txt5: "Pour plus d’informations et les liens officiels, rejoignez-moi :",
	a_propos_txt6:"Discord",
	a_propos_txt8:"Forum SCS Software",
	support_project: "Offrir un café",
	feedback_title: "Votre retour compte",
	feedback_text: "Une idée, un problème ou une suggestion ? Choisissez le moyen qui vous convient.",
	feedback_discord: "Échanger sur Discord",
	feedback_email: "Envoyer un e-mail",
	feedback_copy: "Copier l’adresse e-mail",
	feedback_copied: "Adresse e-mail copiée : ats.elog@gmail.com",
	feedback_tip: "Pour faciliter le suivi, indiquez la version d’ATS Elog et d’ATS, puis ajoutez une capture ou les étapes pour reproduire le problème si possible.",
	thanks_cities: "Merci pour la contribution des villes :",
	Convoy_MP: "Convoi/MP (réset manuelle des heures)",
	envoyer_city: "Envoyer",
	ajout_ville: "Ajouter une nouvelle ville",
	dev: "Ajouter une ville",
	dev_intro: "Ajoute des villes manquantes à la base. Tes contributions aident toute la communauté ATS Elog.",
	gps_coords: "Coordonnées GPS",
	
	update_title: "Nouvelle version disponible",
    current_version:"Version installée",
    latest_version:"Version disponible",
    later: "Plus tard",
    dont_show: "Ne plus afficher pour cette version",
	update_mobile_pc: "Mise à jour du plugin disponible. Sur le PC où ATS est installé, ouvre http://localhost:8080/index.html : le bouton Télécharger ouvrira le ZIP officiel GitHub.",
	android_update_title: "Mise à jour Android disponible",
	android_update_message: "Une nouvelle version de l’application Android est disponible. Le téléchargement s’ouvrira directement sur ce téléphone depuis GitHub officiel.",
	android_download: "Télécharger l’APK Android",
	official_download: "Source officielle : GitHub Eric-R-Qc/ATS-Elog-Releases",
	download: "Télécharger",
	download_version: "Télécharger la version",
	install_wait: "Veuillez patienter",
	install_wait_mobile_manual: "Installation de l’application manuelle",
	application_web: "Application Web",
	pwa_tip0: "Windows: En haut a droite de la barre d’adresse, il doit avoir une icone qui propose d’installer en Application",
    pwa_tip: "iPhone/iPad: Bouton Partager → Ajouter à l’écran d’accueil.",
    pwa_tip2: "Android: Ouvrir avec App Internet natif(Samsung Internet) → Menu en bas a droite → Ajouter à → Écran d’accueil. Autre navigateur = racourci web et pas la version application",
	text_ip: "Lien pour interface Externe (mobile/Tablette):",
    bouton_ip: "Afficher",
    text_ip1: "Accès depuis un autre appareil",
    text_ip2: "Utilise ce lien sur ton téléphone / tablette :",
    fermer: "Fermer",
	reset_cache_app: "Réinitialiser le cache (dépannage)",
	
	features_title: "Fonctionnalités",
	arcade_mode: "Mode Arcade",
	simulation_mode: "Mode Simulation",
	android_beta_button: "🤖 Android",
	ios_button: " iOS",
	android_beta_title: "🤖 ATS Elog Mobile — Android (bêta expérimentale)",
	android_beta_intro: "Cette version Android est expérimentale. Scanne le QR code avec ton téléphone pour télécharger l’APK de test.",
	android_beta_mobile_intro: "APK expérimentale : télécharge-la, installe-la puis reviens ici pour la connecter.",
	ios_title: " ATS Elog Mobile — iPhone / iPad",
	ios_pc_intro: "Ouvre cette adresse dans Safari sur ton iPhone ou iPad :",
	ios_install_steps: "Dans Safari : touche Partager (□↑), choisis « Ajouter à l’écran d’accueil », puis confirme Ajouter. ATS Elog apparaîtra comme une application sur ton téléphone.",
	android_beta_download: "1 — Télécharger l’APK Android",
	android_beta_connect: "3 — Ouvrir et connecter ATS Elog",
	android_web_alternative_title: "Alternative : application Web",
	android_web_alternative: "Sur Android comme sur iOS, tu peux aussi utiliser ATS Elog directement dans le navigateur puis choisir « Installer l’application » : aucune APK n’est nécessaire.",
	android_web_show_link: "Afficher le lien Web mobile",
	changelog: "Historique",

	// Arcade
	arcade_fatigue_on: "Activer la simulation de la fatigue dans le jeu (redémarrage d’ATS requis lorsque vous cochez/décochez la case pour que le plugin change de mode).",
	arcade_auto_control: "Contrôle des statuts ON / SB / D 100 % automatique.",
	arcade_buttons_locked: "Boutons OFF / SB / ON non cliquables.",
	arcade_driving_5mph: "CONDUITE détectée automatiquement ≥ 5 mph (≥ 8 km/h).",
	arcade_reset_service: "Réinitialiser le temps de service = dormir sur les emplacements.",
	arcade_reset_cycle: "Réinitialiser le cycle = dormir 3 fois de suite sans interruption.",


	// Simulation
	sim_fatigue_off: "Désactiver la simulation de la fatigue dans le jeu (redémarrage d’ATS requis lorsque vous cochez/décochez la case pour que le plugin change de mode).",
	sim_manual_buttons_warn: "Boutons OFF / SB / ON manuels (attention lors des pauses).",
	sim_driving_5mph: "CONDUITE automatique ≥ 5 mph (≥ 8 km/h).",
	sim_secondary_plates_required: "Plaques d’immatriculation secondaires des remorques obligatoires (bi-train/double/triple).",
	rest_management_title: "Gestion Repos",
	sim_rest_enabled: "Simulation du niveau de repos activée dans ATS = dormir sur les parkings prévus dans ATS en position OFF/SB.",
	sim_rest_disabled: "Simulation du niveau de repos désactivée dans ATS = dormir sur les parkings prévus dans ATS en OFF/SB, ou dormir n’importe où sur la carte (voir l’explication de la commande g_set_time dans le tuto).",
	sim_dev_console_enable: "Activer la console développeur pour avancer le temps librement et débloquer la caméra libre (voir tuto ci-dessous).",
	sim_daily_rest: "Repos journalier = OFF/SB pendant 10 h continues.",
	sim_cycle_34h_variants: "Repos hebdomadaire (réinitialiser le cycle des 70 h) = OFF/SB pendant 24 h continues.",

	tuto_title: "Tuto",
	tuto_dev_console_path: "Console Développeur : allez dans « Documents → American Truck Simulator → config.cfg », recherchez « uset g_console \"0\" » et « uset g_developer \"0\" », remplacez « 0 » par « 1 », enregistrez, puis démarrez ATS.",
	tuto_free_cam_keys: "Activer la caméra libre : touche 0 (au-dessus de P). Déplacements au pavé numérique : 9/3 = monter/descendre, 8/5 = avancer/reculer, 4/6 = gauche/droite ; molette souris = vitesse.",
	tuto_open_console: "Ouvrir la console développeur : touche « ~ » (au-dessus de Tab).",
	tuto_change_time: "Changer l’heure (attention à votre statut OFF/SB/ON) : ex. aller à 5h30 → commande : g_set_time 5.50",


	changelog_empty: "Aucun changelog disponible pour le moment.",

},
  en: {
    hos: "HOS",
    home: "Home",
    settings: "Settings",
    logs: "LogBooks",
    about: "About",
	titre_about: "ATS Elog — About",
    rest_in: "Rest",
    drive_rem: "Drive remaining",
    rest_Rem: "Service remaining",
    cycle_rem: "70h/8 days cycle",
    language: "Language",

	// libellés Fuseau Horaire
	tz_label: "Time zone",
	tz_mode_off:  "Disabled (base time)",
	tz_mode_auto: "Automatic (position)",
	tz_mode_htz:  "Home terminal (HTZ)",

	// actions / aide Fuseau Horaire 
	tz_status_off:  "Source: Disabled (base time)",
	tz_status_auto: "Source: Automatic (position)",
	tz_status_htz:  "Source: Home terminal (HTZ)",

	// statuts Fuseau Horaire
	tz_detect_hq_btn: "Detect home terminal now",
	htz_tooltip:
	"For HTZ: open the ATS console and type g_save_format 2 , then make a quicksave so the plugin can read `hq_city` from the save.",

    endpoint: "Data endpoint",
    save: "Save",
    saved: "Saved!",
    editChauffeur: "Driver name",
	vehicules_btn: "🗂️ Vehcicle",
	elog_day: "Day",
	elog_week: "Week",
	villeActuelle: "City",
	elEtat: "State / Province",
	pays: "Country",
	immat_non_def: "⚠️ Please fill in the secondary trailer license plates on the VEHICLES page to comply with regulations for this convoy!",	//plaque supp a informer
	trailer_model: "Type",
	trailer: "Trailer",
	trailer1: "Trailer 1",
	trailer2: "Trailer 2",
	trailer3: "Trailer 3",
	plate_placeholder: "Enter license plate",
	saveTrailerPlates: "Save secondary plates",
	vehicules: "Vehicles",
    camion: "Truck",
    marque: "Make",
    modele: "Model",
    plaque_immat_truck: "License Plate",

    copyright: "©2025 ATS Elog developed by Eric R",
    version: "",
	overlay_move: "Move the overlay",
	reset_cache: "Clear the overlay cache",
	a_propos_txt1: "Information",
    a_propos_txt2: "I'm a professional truck driver and a simulation enthusiast. ATS Elog is a one-person project—I'm not a programmer; I learn as I go, researching and experimenting.",
	a_propos_txt3: "I often run into hurdles, but I work through them over time. Thank you for your patience and support.",
	a_propos_txt5: "For more information and official links, join me:",
    a_propos_txt6: "Discord",
    a_propos_txt8: "SCS Software Forum:",
	 support_project: "Buy me a coffee",
	 feedback_title: "Your feedback matters",
	 feedback_text: "An idea, an issue, or a suggestion? Choose the contact method that works for you.",
	 feedback_discord: "Discuss on Discord",
	 feedback_email: "Send an email",
	 feedback_copy: "Copy email address",
	 feedback_copied: "Email address copied: ats.elog@gmail.com",
	 feedback_tip: "To help us investigate, include your ATS Elog and ATS versions, plus a screenshot or steps to reproduce the issue when possible.",
	thanks_cities: "Thanks for city contributions:",
	Convoy_MP: "Convoy/MP (manual hours reset)",
	dark_mode: "Dark mode",
	envoyer_city: "Send",
	ajout_ville: "Add a new city",
	dev: "Add a city",
	dev_intro: "Add missing cities to the database. Your contributions help the entire ATS Elog community.",
	gps_coords: "",
	
	update_title: "New version available",
    current_version: "Installed version",
    latest_version: "Available version",
    later: "Later",
    dont_show: "Don't show again for this version",
	update_mobile_pc: "A plugin update is available. On the PC where ATS is installed, open http://localhost:8080/index.html: the Download button will open the official GitHub ZIP.",
	android_update_title: "Android update available",
	android_update_message: "A newer Android app version is available. The download will open directly on this phone from official GitHub.",
	android_download: "Download Android APK",
	official_download: "Official source: GitHub Eric-R-Qc/ATS-Elog-Releases",
	download: "Download",
	download_version: "Download version",
	install_wait: "Please wait",
	install_wait_mobile_manual: "Manual app installation",
	application_web: "Web app",
    pwa_tip: "On iPhone/iPad: Share → Add to Home Screen.<br>On Android/Chrome/Microsoft Edge: Browser menu → Install app.",
    text_ip: "External interface link (Mobile/Tablet):",
    bouton_ip: "Show",
    text_ip1: "Access from another device",
    text_ip2: "Use this link on your phone/tablet:",
    fermer: "Close",
	reset_cache_app: "Reset cache (troubleshooting)",
	
	features_title: "Features",
	arcade_mode: "Arcade Mode",
	simulation_mode: "Simulation Mode",
	android_beta_button: "🤖 Android",
	ios_button: " iOS",
	android_beta_title: "🤖 ATS Elog Mobile — Android (experimental beta)",
	android_beta_intro: "This Android version is experimental. Scan the QR code with your phone to download the test APK.",
	android_beta_mobile_intro: "Experimental APK: download it, install it, then return here to connect it.",
	ios_title: " ATS Elog Mobile — iPhone / iPad",
	ios_pc_intro: "Open this address in Safari on your iPhone or iPad:",
	ios_install_steps: "In Safari: tap Share (□↑), choose “Add to Home Screen”, then confirm Add. ATS Elog will appear as an app on your phone.",
	android_beta_download: "1 — Download the Android APK",
	android_beta_connect: "3 — Open and connect ATS Elog",
	android_web_alternative_title: "Alternative: Web app",
	android_web_alternative: "On Android and iOS, you can also use ATS Elog directly in your browser and choose “Install app”: no APK is needed.",
	android_web_show_link: "Show the mobile Web link",
	changelog: "Changelog",

	// Arcade
	arcade_fatigue_on: "Enable fatigue simulation in the game (restarting ATS is required when you check/uncheck the box so the plugin switches mode).",
	arcade_auto_control: "100% automatic control of ON / SB / D states.",
	arcade_buttons_locked: "OFF / SB / ON buttons are disabled.",
	arcade_driving_5mph: "DRIVING detected automatically ≥ 5 mph (≥ 8 km/h).",
	arcade_reset_service: "Reset service time = sleep at rest areas.",
	arcade_reset_cycle: "Reset cycle = sleep three times in a row without interruption.",

	// Simulation
	sim_fatigue_off: "Disable fatigue simulation in the game (restarting ATS is required when you check/uncheck the box so the plugin switches mode).",
	sim_manual_buttons_warn: "Manual OFF / SB / ON buttons (be careful with pauses).",
	sim_driving_5mph: "DRIVING automatic ≥ 5 mph (≥ 8 km/h).",
	sim_secondary_plates_required: "Secondary trailer license plates required (double/triple).",
	rest_management_title: "Rest management",
	sim_rest_enabled: "Rest simulation enabled in ATS = sleep at ATS-designated parking areas while in OFF/SB.",
	sim_rest_disabled: "Rest simulation disabled in ATS = sleep at ATS-designated parking areas in OFF/SB, or sleep anywhere on the map (see the g_set_time explanation in the tutorial).",
	sim_dev_console_enable: "Enable the developer console to skip time freely and unlock the free camera (see tutorial below).",
	sim_daily_rest: "Daily rest = OFF/SB for 10 consecutive hours.",
	sim_cycle_34h_variants: "Weekly rest (reset the 70-hour cycle) = OFF/SB for 24 consecutive hours.",

	tuto_title: "Tutorial",
	tuto_dev_console_path: "Developer Console: go to “Documents → American Truck Simulator → config.cfg”, find “uset g_console \"0\"” and “uset g_developer \"0\"”, change “0” to “1”, save, then start ATS.",
	tuto_free_cam_keys: "Enable free camera: key 0 (above P). Numpad: 9/3 = up/down, 8/5 = forward/back, 4/6 = left/right; mouse wheel = speed.",
	tuto_open_console: "Open the developer console: “~” (above Tab).",
	tuto_change_time: "Change time (watch your OFF/SB/ON status): e.g., to 5:30 → command: g_set_time 5.50",


	changelog_empty: "No changelog available at the moment.",

	
  },

  es: {
    hos: "HOS",                             // HOS (Horas de Servicio) utilisé partout en Espagne/Amérique Latine
    home: "Inicio",
    settings: "Configuración",
    logs: "Registros",
    about: "Acerca de",
	titre_about: "ATS Elog — Acerca de",
    rest_in: "Descanso",
    drive_rem: "Conducción restante",
    rest_Rem: "Servicio restante",
    cycle_rem: "Ciclo de 70h/8 días",
    language: "Idioma",

	// libellés Fuseau Horaire
	tz_label: "Zona horaria",
	tz_mode_off:  "Desactivado (hora base)",
	tz_mode_auto: "Automático (posición)",
	tz_mode_htz:  "Terminal de base (HTZ)",

	// actions / aide Fuseau Horaire 
	tz_status_off:  "Fuente: Desactivado (hora base)",
	tz_status_auto: "Fuente: Automático (posición)",
	tz_status_htz:  "Fuente: Terminal de base (HTZ)",

	// statuts Fuseau Horaire
	tz_detect_hq_btn: "Detectar terminal de base ahora",
	htz_tooltip:
	"Para HTZ: abre la consola de ATS y escribe g_save_format 2 ; luego haz un guardado rápido (quicksave) para que el plugin lea `hq_city` de la partida.",

    endpoint: "Endpoint de datos",
    save: "Guardar",
    saved: "¡Guardado!",
    editChauffeur: "Nombre del conductor",
	vehicules_btn: "🗂️ Vehículos",
	elog_day: "Día",
	elog_week: "Semana",
	villeActuelle: "Ciudad",
	elEtat: "Estado / Provincia",
	pays: "País",
	immat_non_def: "⚠️ ¡Por favor, rellene las matrículas de los remolques secundarios en la página VEHICULOS para cumplir con la normativa de este convoy!",	//plaque supp a informer
    trailer_model: "Tipo",
	trailer: "Remolque",
	trailer1: "Remolque 1",
	trailer2: "Remolque 2",
	trailer3: "Remolque 3",
	plate_placeholder: "Introducir matrícula",
	saveTrailerPlates: "Guardar placas secundarias",
	vehicules: "Vehículos",
	camion: "Camión",
    marque: "Marca",
    modele: "Modelo",
    plaque_immat_truck: "Matrícula",
	
	copyright: "©2025 ATS Elog desarrollado por Eric R",
    version: "",
	overlay_move: "Mover la superposición",
	reset_cache: "Borrar la caché de la superposición",
	a_propos_txt1: "Información",
	a_propos_txt2: "Soy camionero de profesión y un apasionado de la simulación. ATS Elog es un proyecto de una sola persona; no soy programador: aprendo sobre la marcha, investigando y probando.",
	a_propos_txt3: "A menudo me encuentro con obstáculos, pero con el tiempo los supero. Gracias por su paciencia y apoyo.",
	a_propos_txt5: "Para más información y enlaces oficiales, únete aquí:",
    a_propos_txt6: "Discord",
    a_propos_txt8: "Foro de SCS Software:",
	 support_project: "Invitar a un café",
	 feedback_title: "Tu opinión importa",
	 feedback_text: "¿Una idea, un problema o una sugerencia? Elige el medio de contacto que prefieras.",
	 feedback_discord: "Hablar en Discord",
	 feedback_email: "Enviar un correo",
	 feedback_copy: "Copiar dirección de correo",
	 feedback_copied: "Dirección copiada: ats.elog@gmail.com",
	 feedback_tip: "Para facilitar el seguimiento, indica las versiones de ATS Elog y ATS, y añade una captura o los pasos para reproducir el problema si es posible.",
	thanks_cities: "Gracias por contribuir con ciudades:",
	Convoy_MP: "Convoy/MP (reinicio manual de las horas)",
	dark_mode: "Modo oscuro",
	envoyer_city: "Enviar",
	ajout_ville: "Agregar una nueva ciudad",
	dev: "Agregar ciudad",
	dev_intro: "Añade ciudades faltantes a la base de datos. Tus aportes ayudan a toda la comunidad de ATS Elog.",
	gps_coords: "",
	
	update_title: "Nueva versión disponible",
    current_version:"Versión instalada",
    latest_version:"Versión disponible",
    later: "Más tarde",
    dont_show: "No volver a mostrar para esta versión",
	update_mobile_pc: "Hay una actualización del plugin disponible. En el PC donde está instalado ATS, abre http://localhost:8080/index.html: el botón Descargar abrirá el ZIP oficial de GitHub.",
	android_update_title: "Actualización de Android disponible",
	android_update_message: "Hay una nueva versión de la aplicación Android. La descarga se abrirá directamente en este teléfono desde GitHub oficial.",
	android_download: "Descargar APK Android",
	official_download: "Fuente oficial: GitHub Eric-R-Qc/ATS-Elog-Releases",
	download: "Descargar",
	download_version: "Descargar versión",
	install_wait: "Por favor espere",
	install_wait_mobile_manual: "Instalación manual de la aplicación",
	application_web: "Aplicación web",
    pwa_tip: "En iPhone/iPad: Compartir → Añadir a la pantalla de inicio.<br>En Android/Chrome/Microsoft Edge: menú del navegador → Instalar aplicación.",
    text_ip: "Enlace de interfaz externa (Móvil/Tableta):",
    bouton_ip: "Mostrar",
    text_ip1: "Acceso desde otro dispositivo",
    text_ip2: "Usa este enlace en tu teléfono / tableta:",
    fermer: "Cerrar",
	reset_cache_app: "Restablecer la caché (solución de problemas)", 
	
	features_title: "Funcionalidades",
	arcade_mode: "Modo Arcade",
	simulation_mode: "Modo Simulación",
	android_beta_button: "🤖 Android",
	ios_button: " iOS",
	android_beta_title: "🤖 ATS Elog Mobile — Android (beta experimental)",
	android_beta_intro: "Esta versión de Android es experimental. Escanea el código QR con tu teléfono para descargar la APK de prueba.",
	android_beta_mobile_intro: "APK experimental: descárgala, instálala y vuelve aquí para conectarla.",
	ios_title: " ATS Elog Mobile — iPhone / iPad",
	ios_pc_intro: "Abre esta dirección en Safari en tu iPhone o iPad:",
	ios_install_steps: "En Safari: toca Compartir (□↑), elige « Añadir a la pantalla de inicio » y confirma Añadir. ATS Elog aparecerá como una aplicación en tu teléfono.",
	android_beta_download: "1 — Descargar APK Android",
	android_beta_connect: "3 — Abrir y conectar ATS Elog",
	android_web_alternative_title: "Alternativa: aplicación Web",
	android_web_alternative: "En Android e iOS también puedes usar ATS Elog directamente en el navegador y elegir « Instalar aplicación »: no se necesita APK.",
	android_web_show_link: "Mostrar el enlace Web móvil",
	changelog: "Cambios",

	// Arcade
	arcade_fatigue_on: "Activar la simulación de fatiga en el juego (se requiere reiniciar ATS cuando marques/desmarques la casilla para que el plugin cambie de modo).",
	arcade_auto_control: "Control 100 % automático de los estados ON / SB / D.",
	arcade_buttons_locked: "Botones OFF / SB / ON deshabilitados.",
	arcade_driving_5mph: "CONDUCCIÓN detectada automáticamente ≥ 5 mph (≥ 8 km/h).",
	arcade_reset_service: "Restablecer el tiempo de servicio = dormir en áreas de descanso.",
	arcade_reset_cycle: "Restablecer el ciclo = dormir 3 veces seguidas sin interrupción.",

	
	// Simulation
	sim_fatigue_off: "Desactivar la simulación de fatiga en el juego (se requiere reiniciar ATS cuando marques/desmarques la casilla para que el plugin cambie de modo).",
	sim_manual_buttons_warn: "Botones OFF / SB / ON manuales (cuidado con las pausas).",
	sim_driving_5mph: "CONDUCCIÓN automática ≥ 5 mph (≥ 8 km/h).",
	sim_secondary_plates_required: "Placas secundarias de los remolques obligatorias (bi-tren/doble/triple).",
	rest_management_title: "Gestión del descanso",
	sim_rest_enabled: "Simulación de descanso activada en ATS = dormir en los estacionamientos previstos por ATS en posición OFF/SB.",
	sim_rest_disabled: "Simulación de descanso desactivada en ATS = dormir en los estacionamientos previstos por ATS en OFF/SB, o dormir en cualquier lugar del mapa (consulta la explicación de g_set_time en el tutorial).",
	sim_dev_console_enable: "Activar la consola de desarrollador para adelantar el tiempo libremente y desbloquear la cámara libre (ver tutorial abajo).",
	sim_daily_rest: "Descanso diario = OFF/SB durante 10 horas consecutivas.",
	sim_cycle_34h_variants: "Descanso semanal (reiniciar el ciclo de 70 horas) = OFF/SB durante 24 horas consecutivas.",

	tuto_title: "Tutorial",
	tuto_dev_console_path: "Consola de desarrollador: ve a « Documentos → American Truck Simulator → config.cfg », busca « uset g_console \"0\" » y « uset g_developer \"0\" », cambia « 0 » por « 1 », guarda y arranca ATS.",
	tuto_free_cam_keys: "Activar la cámara libre: tecla 0 (encima de P). Teclado numérico: 9/3 = subir/bajar, 8/5 = avanzar/retroceder, 4/6 = izquierda/derecha; rueda del ratón = velocidad.",
	tuto_open_console: "Abrir la consola de desarrollador: « ~ » (encima de Tab).",
	tuto_change_time: "Cambiar la hora (ojo con el estado OFF/SB/ON): p. ej., a las 5:30 → comando: g_set_time 5.50",


	changelog_empty: "No hay registro de cambios disponible por el momento.",

	
},
  de: {
    hos: "LZV",                        // HOS = Lenk- und Ruhezeiten (abrégé LZV)
    home: "Startseite",
    settings: "Einstellungen",
    logs: "Protokolle",
    about: "Über",
	titre_about: "ATS Elog — Über",
    rest_in: "Pause",                   // "Repos" (pause, repos, etc.)
    drive_rem: "Restfahrzeit",          // "Conduite restante"
    rest_Rem: "Restdienstzeit",         // "Service restant"
    cycle_rem: "70-Stunden-Zyklus / 8 Tage",
    language: "Sprache",

	// libellés Fuseau Horaire
	tz_label: "Zeitzone",
	tz_mode_off:  "Deaktiviert (Basiszeit)",
	tz_mode_auto: "Automatisch (Position)",
	tz_mode_htz:  "Heimat-Depot (HTZ)",

	// actions / aide Fuseau Horaire 
	tz_status_off:  "Quelle: Deaktiviert (Basiszeit)",
	tz_status_auto: "Quelle: Automatisch (Position)",
	tz_status_htz:  "Quelle: Heimat-Depot (HTZ)",

	// statuts Fuseau Horaire
	tz_detect_hq_btn: "Heimat-Depot jetzt ermitteln",
	htz_tooltip:
	"Für HTZ: Öffne die ATS-Konsole und gib g_save_format 2 ein, dann Quick-Save erstellen, damit das Plugin `hq_city` aus dem Spielstand lesen kann.",

    endpoint: "Daten-Endpunkt",
    save: "Speichern",                  // "Enregistrer"
    saved: "Gespeichert!",              // "Sauvegardé !"
    editChauffeur: "Fahrername",        // "Nom du Conducteur"
	vehicules_btn: "🗂️ Fahrzeuge",
	elog_day: "Tag",
	elog_week: "Woche",
	villeActuelle: "Stadt",
	elEtat: "Bundesstaat / Provinz",
	pays: "Land",
	immat_non_def: "⚠️ Bitte geben Sie die Kennzeichen der zusätzlichen Anhänger auf der FAHRZEUGE-Seite ein, um die Vorschriften für diesen Konvoi einzuhalten!", //plaque supp a informer
    trailer_model: "Typ",
	trailer: "Anhänger",
	trailer1: "Anhänger 1",
	trailer2: "Anhänger 2",
	trailer3: "Anhänger 3",
	plate_placeholder: "Kennzeichen eingeben",
	saveTrailerPlates: "Sekundäre Kennzeichen speichern",
	vehicules: "Fahrzeuge",
	camion: "Lkw",
    marque: "Marke",
    modele: "Modell",
    plaque_immat_truck: "Kennzeichen",
	
	copyright: "©2025 ATS Elog entwickelt von Eric R",
    version: "",
	overlay_move: "Overlay verschieben",
	reset_cache: "Overlay-Cache leeren",
	a_propos_txt1: "Informationen",
	a_propos_txt2: "Ich bin Berufskraftfahrer und Simulations-Fan. ATS Elog ist ein Ein-Mann-Projekt – ich bin kein Programmierer; ich lerne Schritt für Schritt, recherchiere und teste.",
	a_propos_txt3: "Es gibt oft Hürden, aber mit der Zeit meistere ich sie. Danke für eure Geduld und eure Unterstützung.",
	a_propos_txt5: "Weitere Infos und offizielle Links findest du hier:",
    a_propos_txt6: "Discord",
    a_propos_txt8: "SCS Software Forum:",
	 support_project: "Einen Kaffee spendieren",
	 feedback_title: "Dein Feedback zählt",
	 feedback_text: "Eine Idee, ein Problem oder ein Vorschlag? Wähle den Kontaktweg, der dir passt.",
	 feedback_discord: "Auf Discord schreiben",
	 feedback_email: "E-Mail senden",
	 feedback_copy: "E-Mail-Adresse kopieren",
	 feedback_copied: "E-Mail-Adresse kopiert: ats.elog@gmail.com",
	 feedback_tip: "Für eine schnellere Bearbeitung nenne bitte die Versionen von ATS Elog und ATS sowie möglichst einen Screenshot oder Schritte zum Nachstellen.",
	thanks_cities: "Danke für die Städte-Beiträge:",
	Convoy_MP: "Konvoi/MP (Stunden manuell zurücksetzen)",
	dark_mode: "Dunkelmodus",
	envoyer_city: "Senden",
	ajout_ville: "Neue Stadt hinzufügen",
	dev: "Stadt hinzufügen",
	dev_intro: "Füge fehlende Städte zur Datenbank hinzu. Deine Beiträge helfen der gesamten ATS-Elog-Community.",
	gps_coords: "",
	
	update_title: "Neue Version verfügbar",
    current_version: "Installierte Version",
    latest_version: "Verfügbare Version",
    later: "Später",
    dont_show: "Für diese Version nicht mehr anzeigen",
	update_mobile_pc: "Ein Plugin-Update ist verfügbar. Öffne auf dem PC mit ATS http://localhost:8080/index.html: Die Schaltfläche Herunterladen öffnet die offizielle GitHub-ZIP-Datei.",
	android_update_title: "Android-Update verfügbar",
	android_update_message: "Eine neue Android-App-Version ist verfügbar. Der Download wird auf diesem Telefon über das offizielle GitHub geöffnet.",
	android_download: "Android-APK herunterladen",
	official_download: "Offizielle Quelle: GitHub Eric-R-Qc/ATS-Elog-Releases",
	 download: "Herunterladen",
	 download_version: "Version herunterladen",
	install_wait: "Bitte warten",
	install_wait_mobile_manual: "Manuelle App-Installation",
	application_web: "Web-App",
    pwa_tip: "Auf iPhone/iPad: Teilen → Zum Home-Bildschirm hinzufügen.<br>Auf Android/Chrome/Microsoft Edge: Browser-Menü → App installieren.",
    text_ip: "Externer Schnittstellen-Link (Mobil/Tablet):",
    bouton_ip: "Anzeigen",
    text_ip1: "Zugriff von einem anderen Gerät",
    text_ip2: "Verwende diesen Link auf deinem Handy / Tablet:",
    fermer: "Schließen",
	reset_cache_app: "Cache zurücksetzen (Fehlerbehebung)",
	
	features_title: "Funktionen",
	arcade_mode: "Arcade-Modus",
	simulation_mode: "Simulationsmodus",
	android_beta_button: "🤖 Android",
	ios_button: " iOS",
	android_beta_title: "🤖 ATS Elog Mobile — Android (experimentelle Beta)",
	android_beta_intro: "Diese Android-Version ist experimentell. Scanne den QR-Code mit deinem Telefon, um die Test-APK herunterzuladen.",
	android_beta_mobile_intro: "Experimentelle APK: herunterladen, installieren und hierher zurückkehren, um sie zu verbinden.",
	ios_title: " ATS Elog Mobile — iPhone / iPad",
	ios_pc_intro: "Öffne diese Adresse in Safari auf deinem iPhone oder iPad:",
	ios_install_steps: "In Safari: Teilen (□↑) antippen, „Zum Home-Bildschirm“ wählen und Hinzufügen bestätigen. ATS Elog erscheint als App auf deinem Telefon.",
	android_beta_download: "1 — Android-APK herunterladen",
	android_beta_connect: "3 — ATS Elog öffnen und verbinden",
	android_web_alternative_title: "Alternative: Web-App",
	android_web_alternative: "Auf Android und iOS kannst du ATS Elog auch direkt im Browser nutzen und „App installieren“ wählen: keine APK erforderlich.",
	android_web_show_link: "Mobilen Web-Link anzeigen",
	changelog: "Änderungen",
	
	// Arcade
	arcade_fatigue_on: "Ermüdungssimulation im Spiel aktivieren (ATS-Neustart erforderlich, wenn du das Kästchen an-/abwählst, damit das Plugin den Modus wechselt).",
	arcade_auto_control: "100 % automatische Steuerung der Zustände ON / SB / D.",
	arcade_buttons_locked: "Schaltflächen OFF / SB / ON deaktiviert.",
	arcade_driving_5mph: "FAHREN wird automatisch erkannt ≥ 5 mph (≥ 8 km/h).",
	arcade_reset_service: "Dienstzeit zurücksetzen = auf Rastplätzen schlafen.",
	arcade_reset_cycle: "Zyklus zurücksetzen = drei Mal hintereinander ohne Unterbrechung schlafen.",

	
	 // Simulation
	sim_fatigue_off: "Ermüdungssimulation im Spiel deaktivieren (ATS-Neustart erforderlich, wenn du das Kästchen an-/abwählst, damit das Plugin den Modus wechselt).",
	sim_manual_buttons_warn: "Manuelle OFF / SB / ON-Schaltflächen (Achtung bei Pausen).",
	sim_driving_5mph: "FAHREN automatisch ≥ 5 mph (≥ 8 km/h).",
	sim_secondary_plates_required: "Zusätzliche Anhängerkennzeichen erforderlich (Bi-Train/Double/Triple).",
	rest_management_title: "Ruhezeitverwaltung",
	sim_rest_enabled: "Ruhesimulation in ATS aktiviert = auf den von ATS vorgesehenen Parkplätzen im Status OFF/SB schlafen.",
	sim_rest_disabled: "Ruhesimulation in ATS deaktiviert = auf ATS-Parkplätzen im Status OFF/SB oder überall auf der Karte schlafen (siehe Erklärung zu g_set_time im Tutorial).",
	sim_dev_console_enable: "Entwicklerkonsole aktivieren, um die Zeit frei zu verstellen und die freie Kamera zu entsperren (siehe Tutorial unten).",
	sim_daily_rest: "Tägliche Ruhezeit = 10 aufeinanderfolgende Stunden OFF/SB.",
	sim_cycle_34h_variants: "Wöchentliche Ruhezeit (70-Stunden-Zyklus zurücksetzen) = 24 aufeinanderfolgende Stunden OFF/SB.",

	tuto_title: "Tutorial",
	tuto_dev_console_path: "Entwicklerkonsole: Datei „Dokumente → American Truck Simulator → config.cfg“, Zeilen „uset g_console \"0\"“ und „uset g_developer \"0\"“ suchen, „0“ durch „1“ ersetzen, speichern und ATS starten.",
	tuto_free_cam_keys: "Freie Kamera aktivieren: Taste 0 (über P). Ziffernblock: 9/3 = hoch/runter, 8/5 = vor/zurück, 4/6 = links/rechts; Mausrad = Geschwindigkeit.",
	tuto_open_console: "Entwicklerkonsole öffnen: „~“ (über Tab).",
	tuto_change_time: "Uhrzeit ändern (Achtung auf OFF/SB/ON-Status): z. B. 5:30 → Befehl: g_set_time 5.50",

	changelog_empty: "Derzeit kein Änderungsprotokoll verfügbar.",

	
}
};

const langSel = document.getElementById("lang");
const LANG = localStorage.getItem('lang') || 'fr';

// Langue courante (synchro avec ton stockage)
window.currentLang = localStorage.getItem('lang') || 'fr';

// Raccourci de traduction
function t(key){
  return (translations[currentLang] && translations[currentLang][key])
      || (translations.fr && translations.fr[key])
      || key;
}

// Appliquer les traductions sur un sous-arbre (ou tout le doc)
function applyI18n(root = document){
  root.querySelectorAll('[data-i18n]').forEach(el => {
    const k = el.dataset.i18n;
    const v = t(k);
    if (v != null) el.textContent = v;
  });
}

// au chargement des réglages
const convoyEl = document.getElementById('convoyMode');
if (convoyEl) convoyEl.checked = localStorage.getItem('convoy_mode') === '1';

function applyTranslations() {
  // remplace l’utilisation de LANG par currentLang
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n;
    const txt = translations[currentLang]?.[key];
    if (txt != null) el.textContent = txt;
  });

  // version UI (si tu veux la garder ici)
  const version = document.querySelectorAll('[data-version]');
  version.forEach(el => el.textContent = "v1.1.14");
}




/* === Popup MAJ == */
function normalizeVer(v){ return String(v || '').trim().replace(/^v/i,''); }

// Évite de proposer une ancienne version lorsqu'un serveur de métadonnées n'a
// pas encore été mis à jour. Les suffixes beta/alpha sont classés avant une
// version finale portant les mêmes chiffres.
function compareVersions(left, right) {
  const parse = value => {
    const raw = normalizeVer(value).toLowerCase();
    return {
      numbers: (raw.match(/\d+/g) || []).map(Number),
      prerelease: /(alpha|beta|rc|dev|test)/.test(raw)
    };
  };
  const a = parse(left), b = parse(right);
  const length = Math.max(a.numbers.length, b.numbers.length);
  for (let i = 0; i < length; i += 1) {
    const diff = (a.numbers[i] || 0) - (b.numbers[i] || 0);
    if (diff) return diff;
  }
  if (a.prerelease === b.prerelease) return 0;
  return a.prerelease ? -1 : 1;
}

// Les métadonnées peuvent signaler une version plus récente, mais un fichier
// d'installation n'est proposé que depuis le dépôt officiel de l'auteur.
// Source code stays private; public binaries and update metadata are published here.
const OFFICIAL_GITHUB_REPOSITORY = 'https://github.com/Eric-R-Qc/ATS-Elog-Releases';
const OFFICIAL_RELEASES_PAGE = OFFICIAL_GITHUB_REPOSITORY;

function getOfficialReleaseLinks(links) {
  return (Array.isArray(links) ? links : []).filter(link => {
    const raw = typeof link === 'string' ? link : link?.url;
    try {
      const url = new URL(String(raw || ''));
      return url.protocol === 'https:'
        && url.hostname === 'github.com'
        && url.pathname.startsWith('/Eric-R-Qc/ATS-Elog-Releases/raw/');
    } catch (_) {
      return false;
    }
  });
}

function showUpdateModal(currentVer, latestVer, links){
  let el = document.getElementById('update-modal');
  if (!el) {
    el = document.createElement('div');
    el.id = 'update-modal';
    el.className = 'update-modal';
    el.innerHTML = `
      <div class="update-card">
        <h3 data-i18n="update_title">Nouvelle version disponible</h3>
        <div class="update-versions">
          <p><span data-i18n="current_version">Version installée</span><strong class="cur">—</strong></p>
          <p><span data-i18n="latest_version">Version disponible</span><strong class="latest">—</strong></p>
        </div>
        <div class="update-links"></div>
        <div class="update-actions">
          <button class="btn" data-close data-i18n="later">Plus tard</button>
          <button class="btn btn-primary" data-skip data-i18n="dont_show">Ne plus afficher pour cette version</button>
        </div>
      </div>`;
    document.body.appendChild(el);
    el.querySelector('[data-close]').onclick = () => el.classList.remove('show');
    el.querySelector('[data-skip]').onclick  = () => {
      const v = el.getAttribute('data-latest') || '';
      localStorage.setItem('atselog.skipVersion', v);
      el.classList.remove('show');
    };
  }
  el.querySelector('.cur').textContent    = currentVer || '—';
  el.querySelector('.latest').textContent = latestVer  || '—';
  el.setAttribute('data-latest', latestVer || '');

const box = el.querySelector('.update-links');
box.innerHTML = '';
const officialLinks = getOfficialReleaseLinks(links);
const officialSource = document.createElement('div');
officialSource.className = 'caption';
officialSource.textContent = t('official_download');
box.appendChild(officialSource);
const isMobile = /android|iphone|ipad|ipod/i.test(navigator.userAgent);
if (isMobile) {
  const note = document.createElement('div');
  note.className = 'caption';
  note.textContent = t('update_mobile_pc');
  box.appendChild(note);
} else {
  const linksToShow = officialLinks.length ? officialLinks : [{
    url: OFFICIAL_RELEASES_PAGE,
    text: OFFICIAL_RELEASES_PAGE
  }];
  linksToShow.forEach(li => {
  const wrap = document.createElement('div');

  const a = document.createElement('a');
  a.className = 'btn btn-primary btn-download';
  // URL directe vers un ZIP : GitHub Releases ou l'hébergeur doit répondre
  // avec Content-Disposition: attachment pour lancer le téléchargement.
  a.href = li.url || li; a.download = ''; a.rel = 'noopener';
  a.textContent = `${t('download_version')} ${latestVer}`;
  wrap.appendChild(a);

  if (li.text && li.text !== li.url) {
    const cap = document.createElement('div');
    cap.className = 'caption';
    cap.textContent = li.text;
    wrap.appendChild(cap);
  }
  box.appendChild(wrap);
  });
}

// ⇩⇩ ajoute cette ligne pour traduire tous les [data-i18n] de la modale
applyI18n(el);

el.classList.add('show');}

function getOfficialZipAsset(release) {
  const assets = Array.isArray(release?.assets) ? release.assets : [];
  return assets.find(asset => {
    const url = String(asset?.browser_download_url || '');
    return /\.zip$/i.test(String(asset?.name || ''))
      && url.startsWith('https://github.com/Eric-R-Qc/ATS-Elog-Releases/releases/download/');
  }) || null;
}

async function checkVersionAgainstSheet(){
  try{
    const d = await fetch(`${endpoint}?t=${Date.now()}`).then(r=>r.json()).catch(()=>({}));
    const current = normalizeVer(d.version || (document.querySelector('.ui-version')?.textContent || ''));
    if (!current) return;

    // The release-only repository is public while the source repository stays private.
    const response = await fetch(OFFICIAL_GITHUB_RELEASES_API, {
      headers: { Accept: 'application/vnd.github+json' }, cache: 'no-store'
    });
    if (!response.ok) return;
    const releases = await response.json();
    const latest = (Array.isArray(releases) ? releases : [])
      .filter(release => !release.draft)
      .map(release => ({
        version: normalizeVer(release.tag_name || release.name),
        asset: getOfficialZipAsset(release)
      }))
      .filter(item => item.version && item.asset)
      .reduce((best, item) => !best || compareVersions(item.version, best.version) > 0 ? item : best, null);

    if (!latest || latest.version === localStorage.getItem('atselog.skipVersion')) return;
    if (compareVersions(latest.version, current) > 0) {
      showUpdateModal(current, latest.version, [{
        url: latest.asset.browser_download_url,
        text: latest.asset.name
      }]);
    }
  }catch(e){ console.warn('[UpdateCheck]', e); }
}

// Les mises à jour Android sont volontairement séparées des mises à jour du
// plugin. Seule l'APK native consulte les releases GitHub et propose un APK.
const OFFICIAL_GITHUB_RELEASES_API = 'https://raw.githubusercontent.com/Eric-R-Qc/ATS-Elog-Releases/main/release-manifest.json';

function isNativeAndroidClient() {
  return Boolean(window.Android && typeof window.Android.getAppVersion === 'function');
}

function getOfficialApkAsset(release) {
  const assets = Array.isArray(release?.assets) ? release.assets : [];
  return assets.find(asset => {
    const url = String(asset?.browser_download_url || '');
    return /\.apk$/i.test(String(asset?.name || ''))
      && url.startsWith('https://github.com/Eric-R-Qc/ATS-Elog-Releases/raw/');
  }) || null;
}

function showAndroidUpdateModal(currentVer, latestVer, apkUrl) {
  let el = document.getElementById('android-update-modal');
  if (!el) {
    el = document.createElement('div');
    el.id = 'android-update-modal';
    el.className = 'update-modal';
    el.innerHTML = `
      <div class="update-card">
        <h3 data-i18n="android_update_title">Mise à jour Android disponible</h3>
        <div class="update-versions">
          <p><span data-i18n="current_version">Version installée</span><strong class="cur">—</strong></p>
          <p><span data-i18n="latest_version">Version disponible</span><strong class="latest">—</strong></p>
        </div>
        <p class="caption" data-i18n="android_update_message">Une nouvelle version de l’application Android est disponible.</p>
        <a class="btn btn-primary btn-download" data-apk-download data-i18n="android_download">Télécharger l’APK Android</a>
        <div class="update-actions">
          <button class="btn" data-close data-i18n="later">Plus tard</button>
          <button class="btn btn-primary" data-skip data-i18n="dont_show">Ne plus afficher pour cette version</button>
        </div>
      </div>`;
    document.body.appendChild(el);
    el.querySelector('[data-close]').onclick = () => el.classList.remove('show');
    el.querySelector('[data-skip]').onclick = () => {
      localStorage.setItem('atselog.skipAndroidVersion', el.getAttribute('data-latest') || '');
      el.classList.remove('show');
    };
  }

  el.querySelector('.cur').textContent = currentVer;
  el.querySelector('.latest').textContent = latestVer;
  el.setAttribute('data-latest', latestVer);
  const download = el.querySelector('[data-apk-download]');
  download.href = apkUrl;
  download.onclick = event => {
    if (window.Android && typeof window.Android.downloadOfficialApk === 'function') {
      event.preventDefault();
      window.Android.downloadOfficialApk(apkUrl);
    }
  };
  applyI18n(el);
  el.classList.add('show');
}

async function checkAndroidUpdate() {
  if (!isNativeAndroidClient()) return;
  try {
    const current = normalizeVer(window.ATS_ELOG_ANDROID_VERSION || window.Android.getAppVersion());
    if (!current) return;
    const response = await fetch(OFFICIAL_GITHUB_RELEASES_API, {
      headers: { Accept: 'application/vnd.github+json' }, cache: 'no-store'
    });
    if (!response.ok) return;
    const releases = await response.json();
    const candidates = (Array.isArray(releases) ? releases : [])
      .filter(release => !release.draft)
      .map(release => ({ version: normalizeVer(release.tag_name || release.name), asset: getOfficialApkAsset(release) }))
      .filter(item => item.version && item.asset);
    const latest = candidates.reduce((best, item) =>
      !best || compareVersions(item.version, best.version) > 0 ? item : best, null);
    if (!latest || compareVersions(latest.version, current) <= 0) return;
    if (latest.version === localStorage.getItem('atselog.skipAndroidVersion')) return;
    showAndroidUpdateModal(current, latest.version, latest.asset.browser_download_url);
  } catch (error) {
    console.warn('[AndroidUpdateCheck]', error);
  }
}

/* == Fin Popup MAJ ==*/

/* === Boot TZ from cache (avant tout rendu) === */
(function bootTzFromCache() {
  try {
    const raw = localStorage.getItem('atselog.tz');
    if (!raw) return;
    const o = JSON.parse(raw);
    // Priorité au nouveau champ offFinal ; fallback sur l'ancien off
    const off = Number.isFinite(o?.offFinal) ? o.offFinal : Number(o?.off);
    if (Number.isFinite(off)) window.timeZoneOffset = off;  // heures "finales"
    if (typeof o?.abbr === 'string') window.timeZoneAbbr = o.abbr;
  } catch {}
})();



// --- PRIORITÉ SOURCES VILLES: SHEET > TRUCKY > LOCAL ---
function getTruckyCities() {
  return fetch("https://api.truckyapp.com/v2/map/cities/ats")
    .then(r => r.json())
    .then(d => Array.isArray(d?.response) ? d.response : [])
    .catch(() => []);
}

// clé stable pour dédoublonner (même ville/état/coord ≈ même clé)
function _cityKey(c) {
  return [
    (c.realName || c.name || "").toLowerCase().trim(),
    (c.country || "").toLowerCase().trim(),
    Math.round(Number(c.x) || 0),
    Math.round(Number(c.z) || 0)
  ].join("|");
}

// fusion avec priorité au 2e puis 3e … (dernier gagne)
function mergeByPriority(...lists) {
  const map = new Map();
  for (const list of lists) {
    for (const c of list || []) map.set(_cityKey(c), c);
  }
  return [...map.values()];
}

// === GOOGLE SHEET (GLOBAL) ===============================================
// URL du dernier déploiement WebApp (global)
window.GAS_URL = 'https://script.google.com/macros/s/AKfycbxraUXnnhHVusEgeT6DnX3gI5v21WHh643y74GAyf8WJxx3Ejt__n9UMiSvbQx_D7TM/exec';


// JSONP utilitaire global (pas de CORS)
function jsonp(url) {
  return new Promise((resolve, reject) => {
    const cb = 'gascb_' + Math.random().toString(36).slice(2);
    const s  = document.createElement('script');
    const sep = url.includes('?') ? '&' : '?';
    s.src = `${url}${sep}callback=${cb}`;
    window[cb] = (payload) => { delete window[cb]; s.remove(); resolve(payload); };
    s.onerror  = () => { delete window[cb]; s.remove(); reject(new Error('JSONP échoué')); };
    document.body.appendChild(s);
  });
}


// Récupère les villes depuis le Sheet et normalise -> {realName,country,x,z}
async function fetchSheetCities() {
  try {
    const payload = await jsonp(`${window.GAS_URL}?list=1`);
    const rows = Array.isArray(payload?.rows) ? payload.rows : [];
    return rows.map(r => ({
      realName: r.realName || r.city || r.name || '',
      country:  r.country  || r.stateCountry || '',
      x: Number(r.x ?? r.pos_x ?? r.lon ?? 0),
      z: Number(r.z ?? r.pos_z ?? r.lat ?? 0),
    })).filter(c => c.realName && isFinite(c.x) && isFinite(c.z));
  } catch (e) {
    console.warn('[Sheet] lecture échouée → fallback', e);
    return [];
  }
}


// CHARGEMENT CENTRALISÉ: d’abord Sheet, puis on complète avec Trucky/Local
async function initCitiesPriority() {
  const pSheet  = fetchSheetCities().catch(() => []);
  const pTrucky = getTruckyCities().catch(() => []);
  const local   = normalizeLocalCities(loadLocalCities());

  // The embedded city list is available synchronously. Publish it first so
  // HTZ clocks and timeline segments do not briefly render in another zone
  // while remote Sheet/Trucky sources are loading.
  if (!window.citiesReady && local.length) {
    window.citiesFinal = local;
    window.citiesReady = true;
    window.citiesLoadedFrom = "local";
    if (window.lastGameData) updateUI(window.lastGameData);
  }

  // 1) Attendre le Sheet d'abord
  const sheet = await pSheet;

  if (sheet.length) {
    // Sheet prêt ⇒ on le publie tout de suite (priorité Sheet)
    window.citiesFinal = mergeByPriority(local, sheet);   // sheet gagne
    window.citiesReady = true;
    window.citiesLoadedFrom = "sheet";
    console.log("[Cities] source = sheet, total =", window.citiesFinal.length);
    if (window.lastGameData) updateUI(window.lastGameData);
  }

  // 2) Quand Trucky arrive, on complète (sans casser les villes du Sheet)
  const trucky = await pTrucky;
  const merged = mergeByPriority(local, trucky, sheet);   // ordre => dernier gagne (sheet)
  window.citiesFinal = merged;

  // 3) Fallback si le Sheet était vide
  if (!window.citiesReady) {
    window.citiesReady = true;
    window.citiesLoadedFrom = trucky.length ? "trucky" : "local";
    console.log("[Cities] source =", window.citiesLoadedFrom, "total =", merged.length);
    if (window.lastGameData) updateUI(window.lastGameData);
  }
}



// --- ÉTAPE 1 : FONCTIONS D'IMPORT ET DE FUSION ---
function loadLocalCities() {
  if (!window.citiesATS) {
    console.warn("Variable citiesATS non trouvée, vérifie l'inclusion du fichier cities-ats.js");
    return {};
  }
  return window.citiesATS;
}

function normalizeLocalCities(localCities) {
  const normalized = [];
  Object.entries(localCities).forEach(([key, city]) => {
    if (!city) return;
    const coordX = Number(city.x || city.coord_x);
    const coordZ = Number(city.z || city.coord_y);
    // Les définitions de villes des maps moddés donnent toujours un alias,
    // un nom et un pays, mais pas forcément les coordonnées monde. Elles
    // restent utiles pour le QG et le fuseau ; nearestCity() les ignore
    // naturellement tant que les coordonnées n'ont pas été importées.
    const hasCoords = Number.isFinite(coordX) && Number.isFinite(coordZ) &&
      !(String(city.x ?? city.coord_x ?? '').trim() === '') &&
      !(String(city.z ?? city.coord_y ?? '').trim() === '');
    normalized.push({
      _id: city._id || key,
      realName: city.realName || city.name || "",
      x: hasCoords ? coordX : undefined,
      z: hasCoords ? coordZ : undefined,
      country: city.country || '',
      state: city.state || '',
      dlc: city.dlc || '',
      mod: city.mod || '',
      relative_radius: city.relative_radius || 0.5,
      timezone: city.timezone || ''
    });
  });
  return normalized;
}


function mergeCities(truckyCities, localCitiesNormalized) {
  const map = new Map();
  truckyCities.forEach(city => { if (city._id) map.set(city._id, city); });
  localCitiesNormalized.forEach(city => { if (!map.has(city._id)) map.set(city._id, city); });
  return Array.from(map.values());
}



function showToast(msg, duration = 1000) { // <-- par défaut : 2 secondes
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = msg;
  toast.style.display = 'block';
  clearTimeout(showToast._timeout);
  showToast._timeout = setTimeout(() => {
    toast.style.display = 'none';
  }, duration);
}

document.addEventListener('DOMContentLoaded', () => {
  const copyButton = document.getElementById('copy-feedback-email');
  if (!copyButton) return;
  copyButton.addEventListener('click', async () => {
    const address = 'ats.elog@gmail.com';
    try {
      await navigator.clipboard.writeText(address);
    } catch (_) {
      const field = document.createElement('textarea');
      field.value = address;
      field.style.position = 'fixed';
      field.style.opacity = '0';
      document.body.appendChild(field);
      field.select();
      document.execCommand('copy');
      field.remove();
    }
    showToast(translations[currentLang]?.feedback_copied || `Adresse e-mail copiée : ${address}`, 2200);
  });
});

// --- sauvegarde du réglage "Mode convoi" quand on clique Enregistrer ---
document.addEventListener('DOMContentLoaded', () => {
  const convoyEl = document.getElementById('convoyMode');
  const saveBtn  = document.getElementById('saveBtn');

  // (re)cocher la case selon l'état sauvé
  if (convoyEl) convoyEl.checked = localStorage.getItem('convoy_mode') === '1'; // déjà présent chez toi

  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      if (convoyEl) localStorage.setItem('convoy_mode', convoyEl.checked ? '1' : '0');
      // ta logique existante: toast + redirection…
    });
  }
});


// --- FUSEAU HORAIRE LOCAL VIA API TRUCKY ---
let truckyCities = [];
let allCities = [];

/*fetch("https://api.truckyapp.com/v2/map/cities/ats")
  .then(r => r.json())
  .then(d => {
    truckyCities = d.response;
    const localCitiesRaw = loadLocalCities();
    const localCities = normalizeLocalCities(localCitiesRaw);
    allCities = mergeCities(truckyCities, localCities);
    if (window.lastGameData) updateUI(window.lastGameData);
  })
  .catch((e) => { truckyCities = []; allCities = []; });
*/
  

// Offsets RELATIFS à l’heure de base ATS (MDT)
const TZ = {
  pac: { off: -1, abbr: "PDT" }, // Pacific = 1h plus tôt que MDT
  mtn: { off:  0, abbr: "MDT" }, // Mountain = base ATS
  cen: { off: +1, abbr: "CDT" }, // Central = +1h vs MDT
  est: { off: +2, abbr: "EDT" }  // Eastern = +2h vs MDT
  // Optionnel: ak: { off: -2, abbr: "AKDT" }  // Alaska (si tu l’ajoutes au mapping)
};

function setPickedTZ(tz) {
  window.timeZoneOffset = tz.off;    // offset RELATIF à MDT (en heures)
  window.timeZoneAbbr   = tz.abbr;
  try {
    localStorage.setItem('atselog.tz', JSON.stringify({
      offFinal: tz.off,
      abbr: tz.abbr
    }));
  } catch {}
}



// Trouve la ville la plus proche (selon coord du jeu)
function nearestCity(px, pz) {
  const list = Array.isArray(window.citiesFinal) ? window.citiesFinal : [];
  if (!list.length) return null;
  let best = null, bestD2 = Infinity;
  for (const c of list) {
    const x = Number(c.x), z = Number(c.z);
    if (!isFinite(x) || !isFinite(z)) continue;
    const d2 = (px - x)*(px - x) + (pz - z)*(pz - z);
    if (d2 < bestD2) { bestD2 = d2; best = c; }
  }
  return best;
}






// Calcule l’heure locale selon la ville la plus proche
function getLocalGameTime(data) {
  const clock = String(data?.clock || "--:--");
  const [H, M] = clock.split(':').map(v => parseInt(v,10) || 0);
  const baseMin = ((H*60 + M) % 1440 + 1440) % 1440; // heure de base (MDT)

  const mode = getTzMode();
  if (mode === 'off') return clock; // heure de base, sans abréviation

  let offMin = 0, abbr = '';

  if (window.citiesReady && typeof window.getTzOffsetMin === 'function') {
    // chemin normal
    const res = window.getTzOffsetMin(data);
    offMin = res?.offMin || 0;
    abbr   = res?.abbr   || '';
  } else {
    // pré-peinture: on prend le cache sauvegardé
    try {
      const c = JSON.parse(localStorage.getItem('atselog.cache.tz') || '{}');
      if (Number.isFinite(c?.offFinal)) {
        offMin = (c.offFinal || 0) * 60; // heures -> minutes
        abbr   = c.abbr || '';
      }
    } catch {}
  }

  const localMin = (baseMin + offMin + 1440) % 1440;
  const hh = String(Math.floor(localMin/60)).padStart(2,'0');
  const mm = String(localMin%60).padStart(2,'0');
  return `${hh}:${mm}${abbr ? ' ' + abbr : ''}`;
}


  


function parseHHMMtoSec(hhmm = "00:00") {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 3600 + m * 60;
}

function formatHMM(sec = 0) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  return `${String(h).padStart(2, '0')}h${String(m).padStart(2, '0')}`;
}
function formatHMStr(str = "--:--") {
  return str.replace(':', 'h');
}

// Affiche l'heure locale OU heure jeu selon settings
function updateDisplayedTime(data){
  const el = document.getElementById('header-game-time');
  if (!el) return;
  const txt = getLocalGameTime(data || {});
  el.textContent = txt;

  // garder un cache utilisable au prochain reload
  try {
    // si getTzOffsetMin vient de tourner, il a dû poser offFinal/abbr en LS (voir 2.A)
    // Sinon on tente d’extraire l’abbr depuis le texte:
    const abbr = (txt.match(/\s([A-Z]{2,4})$/)||[])[1] || '';
    const c = JSON.parse(localStorage.getItem('atselog.cache.tz') || '{}');
    if (abbr && typeof c.offFinal === 'number') {
      c.abbr = abbr; c.t = Date.now();
      localStorage.setItem('atselog.cache.tz', JSON.stringify(c));
    }
  } catch {}
}
// Quand la case fuseau est cochée/décochée, ou offset changé :
function syncTimezoneWithPlugin(active, offset) {
  fetch(`/api/eld/timezone?active=${active ? 1 : 0}&offset=${offset}`)
    .then(r => r.text())
    .then(console.log)
    .catch(console.error);
}

// Le plugin et l'interface doivent impérativement utiliser le même référentiel.
// Ne jamais envoyer un offset récupéré d'un ancien cache ou de la ville courante
// lorsque l'utilisateur a choisi le terminal d'attache (HTZ).
function syncSelectedTimezoneWithPlugin(data) {
  const mode = getTzMode();
  const active = mode !== 'off';
  const resolved = (typeof window.getTzOffsetMin === 'function')
    ? window.getTzOffsetMin(data || window.lastGameData || {})
    : { offMin: 0, abbr: '' };
  const offset = active ? Math.trunc(Number(resolved.offMin || 0) / 60) : 0;
  const fingerprint = `${active ? 1 : 0}:${offset}`;

  if (window.lastSentTimezone === fingerprint) return;

  window.timeZoneOffset = offset;
  window.timeZoneAbbr = resolved.abbr || '';
  window.lastSentTimezone = fingerprint;
  syncTimezoneWithPlugin(active, offset);
}

// À appeler à chaque fois qu’on change le fuseau sur l’UI (ou position GPS si tu veux 100% auto)
const tz = document.getElementById('atsTimezone');
if (tz) {
  tz.checked = localStorage.getItem('ats_timezone') === '1';
  tz.addEventListener('change', () => {
    localStorage.setItem('ats_timezone', tz.checked ? '1' : '0');
    // Le mode sélectionné (HTZ/auto/désactivé), et non un cache, décide l'offset.
    if (!tz.checked) localStorage.setItem(TZMODE_KEY, 'off');
    syncSelectedTimezoneWithPlugin(window.lastGameData || {});
    updateDisplayedTime(window.lastGameData || {});
  });
}



// --- Helpers TZ & villes ---

// === Clés centralisées ===
const TZMODE_KEY   = 'tz_mode';
const HQ_SLUG_KEY  = 'atselog.hq_city';
const HQ_RAW_KEY   = 'atselog.htz.raw_city';

// Mode TZ unifié
function getTzMode(){
  const legacy = localStorage.getItem('ats_timezone') === '1' ? 'auto' : null;
  return localStorage.getItem(TZMODE_KEY) || legacy || 'off';
}

// Lecture “safe” du HQ (slug)
function getSavedHQSlug(){
  const v = localStorage.getItem(HQ_SLUG_KEY) || localStorage.getItem(HQ_RAW_KEY) || '';
  return String(v).trim();
}

// Forcer initialisation depuis l’API /api/profile/hq
async function ensureHQFromApi(){
  try{
    const r = await fetch('/api/profile/hq', {cache:'no-store'});
    const j = await r.json();
    if (j?.ok && j.hq_city){
      localStorage.setItem(HQ_SLUG_KEY, j.hq_city);
      console.log('[HQ] from API =>', j.hq_city);
      return true;
    }
  }catch(e){ console.warn(e); }
  return false;
}

// --- TZ Mode UI (OFF / AUTO / HTZ) ---
document.addEventListener('DOMContentLoaded', () => {
  const tzSel    = document.getElementById('tzMode');
  const tzStatus = document.getElementById('tzModeStatus');
  const htzTools = document.getElementById('tzHTZTools');
  const detectBtn= document.getElementById('detectHQBtn'); // <- ID CORRECT
  const help     = document.getElementById('htzHelp');

  // utilitaire : clé de statut -> texte
  const statusKeyFor = (mode) => (mode === 'auto') ? 'tz_status_auto'
                               : (mode === 'htz')  ? 'tz_status_htz'
                               : 'tz_status_off';

  function applyStatus(mode){
    // 1) texte "Source : …"
    if (tzStatus){
      tzStatus.dataset.i18n = statusKeyFor(mode);
      if (typeof applyI18n === 'function') applyI18n(tzStatus);
    }
    // 2) outils HTZ visibles seulement en HTZ
    if (htzTools) htzTools.style.display = (mode === 'htz') ? 'flex' : 'none';
  }

  // i18n pour les bulles (data-i18n-tooltip -> title + data-tooltip)
  function applyI18nTooltips(){
  document.querySelectorAll('[data-i18n-tooltip]').forEach(el => {
    const key = el.getAttribute('data-i18n-tooltip');
    setTooltipFromI18n(el, key);
  });
}

  // init : valeur, UI, bulles
  if (tzSel){
    const cur = localStorage.getItem('tz_mode') || 'off';
    tzSel.value = cur;
    applyStatus(cur);
    applyI18nTooltips();

    tzSel.addEventListener('change', (e) => {
      const mode = e.target.value;
      localStorage.setItem('tz_mode', mode);
      applyStatus(mode); // <— c’était l’appel manquant
      if (window.refreshHQLabel) window.refreshHQLabel();
      if (window.lastGameData)   updateDisplayedTime(window.lastGameData);
    });
  } else {
    // page index.html : assure juste les bulles traduites si présentes
    applyI18nTooltips();
  }



  // bouton "Détecter le QG maintenant"
  if (detectBtn){
    detectBtn.addEventListener('click', async () => {
      try{
        const r = await fetch('/api/profile/hq', {cache:'no-store'});
        const j = await r.json();
        if (j && j.ok && j.hq_city){
          localStorage.setItem('atselog.hq_city', j.hq_city);
		  if (window.refreshHQLabel) window.refreshHQLabel(true);
          if (typeof refreshHQLabel === 'function') refreshHQLabel();
          alert('QG détecté : ' + j.hq_city);
        } else {
          alert('QG introuvable dans la dernière sauvegarde. Fais une sauvegarde rapide dans ATS puis réessaie.');
        }
      }catch{
        alert('Erreur pendant la détection du QG.');
      }
    });
  }

	const tick = setInterval(()=>{
    if (window.citiesReady) {
      clearInterval(tick);
      if (typeof refreshHQLabel === 'function') refreshHQLabel();
	  if (window.refreshHQLabel) window.refreshHQLabel();
      if (window.lastGameData)   updateDisplayedTime(window.lastGameData);
    }
  }, 200);
  // nettoyage anti "485" + premier affichage
  const bad = localStorage.getItem('atselog.hq_city');
  if (bad && /^\d+$/.test(bad)) localStorage.removeItem('atselog.hq_city');
  if (typeof refreshHQLabel === 'function') refreshHQLabel();
});


function setTzMode(m){ localStorage.setItem('tz_mode', m); }

// Alias sûr -> on réutilise ton findCityBySlug
function _cityFromSlug(slug){
  return (typeof findCityBySlug === 'function') ? findCityBySlug(slug||'') : null;
}


// Lancer villes + QG + header une fois le DOM prêt
document.addEventListener('DOMContentLoaded', async () => {
  try { initCitiesPriority(); } catch {}
  if (window.refreshHQLabel) window.refreshHQLabel();
  if (window.lastGameData)   updateDisplayedTime(window.lastGameData);

  // si ton <select id="tzMode"> existe déjà en Réglages
  const tzSel = document.getElementById('tzMode');
  if (tzSel) {
    const current = localStorage.getItem('tz_mode') || 'off';
    tzSel.value = current;
    tzSel.addEventListener('change', e => {
      localStorage.setItem('tz_mode', e.target.value);
      if (window.lastGameData) updateDisplayedTime(window.lastGameData);
      if (window.refreshHQLabel) window.refreshHQLabel();
    });
  }
});


function _slugifyCityName(s=""){ return String(s).toLowerCase().replace(/\s+/g,'_').trim(); }
function _extractStateCode(label=''){ const m = String(label).match(/\((\w{2})\)/); return m ? m[1] : ""; }

function _findCityLoose(name){
  const s = String(name||'').toLowerCase().trim();
  const list = Array.isArray(window.citiesFinal) ? window.citiesFinal : [];
  if (!list.length) return null;
  for (const c of list){
    const slug = _slugifyCityName(c.realName||c.name||'');
    const id   = _slugifyCityName(c._id||'');
    if (s===slug || s===id) return c;
  }
  for (const c of list){
    const n = String(c.realName||c.name||'').toLowerCase();
    if (n===s || n.startsWith(s) || n.includes(s)) return c;
  }
  return null;
}

// Affiche: "Ville, ST MDT" si une ville HQ est connue
// -------- Helpers QG --------
function _norm(s){ return String(s||'').toLowerCase().replace(/[\s_\-]/g,'').replace(/city$/,''); }
function _title(s){ return String(s||'').replace(/_/g,' ').replace(/\b\w/g,c=>c.toUpperCase()); }

// Cherche une ville dans final -> sheet -> local -> trucky
function getCityBySlugSmart(slug){
  const sets = [window.citiesFinal, window.citiesSheet, window.citiesLocal, window.citiesTrucky];
  const q = _norm(slug);
  for (const arr of sets){
    if (!Array.isArray(arr)) continue;
    // match exact (_id / realName / name)
    for (const c of arr){ const a=[c._id, c.realName, c.name].map(_norm); if (a.some(v=>v===q)) return c; }
    // match partiel (ex: "salt_lake" -> "salt_lake_city")
    for (const c of arr){ const a=[c._id, c.realName, c.name].map(_norm); if (a.some(v=>v.startsWith(q))) return c; }
  }
  return null;
}

// "USA (UT)" -> {country:"USA", code:"UT"}
function parseCountryField(s){
  const m = String(s||'').match(/^(.+?)\s*\((\w{2,3})\)$/);
  return m ? { country: m[1].trim(), code: m[2] } : { country: String(s||''), code: '' };
}

// Noms d’États/Provinces (incomplete -> ajoute si besoin)
const STATE_NAMES = {
  USA: { UT:'Utah', WA:'Washington', OR:'Oregon', CA:'California', ID:'Idaho', MT:'Montana', WY:'Wyoming', NV:'Nevada', CO:'Colorado', NM:'New Mexico', AZ:'Arizona', NE:'Nebraska', SD:'South Dakota', ND:'North Dakota', KS:'Kansas', OK:'Oklahoma', TX:'Texas', MN:'Minnesota', WI:'Wisconsin', IA:'Iowa', MO:'Missouri', AR:'Arkansas', LA:'Louisiana', MS:'Mississippi', IL:'Illinois' },
  Canada: { QC:'Québec', ON:'Ontario', AB:'Alberta', BC:'Colombie-Britannique', SK:'Saskatchewan', MB:'Manitoba', NT:'Territoires du Nord-Ouest', YT:'Yukon' },
  Mexico: { BC:'Baja California', BCS:'Baja California Sur', SON:'Sonora', CHH:'Chihuahua', SIN:'Sinaloa', DGO:'Durango', NAY:'Nayarit', ZAC:'Zacatecas', SLP:'San Luis Potosí', AGS:'Aguascalientes', JAL:'Jalisco' },
};

// API HQ unifiée : renvoie un objet avec ville / état / pays / tz
function getCurrentHQ() {
  try {
    const slug =
      localStorage.getItem("atselog.hq_city") ||
      localStorage.getItem("atselog.htz.raw_city") ||
      "";

    if (!slug) return null;

    const city = (typeof getCityBySlugSmart === "function")
      ? getCityBySlugSmart(slug)
      : null;

    let name = "";
    let countryInfo = "";
    let stateCode = "";
    let countryLabel = "";

    if (city) {
      name = (city.realName || city.name || "").trim();
      countryInfo = (city.country || "").trim();
      stateCode = (city.state || city.region || "").trim();

      // 1) Format "Canada (BC)" → code = BC, pays = Canada
      if (countryInfo && typeof parseCountryField === "function") {
        const parsed = parseCountryField(countryInfo);
        if (parsed.code && !stateCode) stateCode = parsed.code.toUpperCase();
        if (parsed.country && parsed.code) countryLabel = parsed.country;
      }

      // 2) Format texte type "British Columbia", "Alberta", etc.
            // 2) Format texte type "British Columbia", "Alberta", etc.
      // 2) Format texte type "British Columbia", "Washington", "Baja California", etc.
      if (countryInfo) {
        const lc = countryInfo.toLowerCase().trim();

        const regionMap = {
          // 🇨🇦 Canada – provinces & territoires (si jamais "country" contient ça)
          "british columbia":        { code: "BC",  country: "Canada" },
          "alberta":                 { code: "AB",  country: "Canada" },
          "saskatchewan":            { code: "SK",  country: "Canada" },
          "manitoba":                { code: "MB",  country: "Canada" },
          "ontario":                 { code: "ON",  country: "Canada" },
          "quebec":                  { code: "QC",  country: "Canada" },
          "new brunswick":           { code: "NB",  country: "Canada" },
          "nova scotia":             { code: "NS",  country: "Canada" },
          "prince edward island":    { code: "PE",  country: "Canada" },
          "newfoundland and labrador": { code: "NL", country: "Canada" },
          "yukon":                   { code: "YT",  country: "Canada" },
          "northwest territories":   { code: "NT",  country: "Canada" },
          "territoires du nord-ouest": { code: "NT", country: "Canada" },
          "nunavut":                 { code: "NU",  country: "Canada" },

          // 🇺🇸 USA – 50 États + DC
          "alabama":                 { code: "AL",  country: "USA" },
          "alaska":                  { code: "AK",  country: "USA" },
          "arizona":                 { code: "AZ",  country: "USA" },
          "arkansas":                { code: "AR",  country: "USA" },
          "california":              { code: "CA",  country: "USA" },
          "colorado":                { code: "CO",  country: "USA" },
          "connecticut":             { code: "CT",  country: "USA" },
          "delaware":                { code: "DE",  country: "USA" },
          "florida":                 { code: "FL",  country: "USA" },
          "georgia":                 { code: "GA",  country: "USA" },
          "hawaii":                  { code: "HI",  country: "USA" },
          "idaho":                   { code: "ID",  country: "USA" },
          "illinois":                { code: "IL",  country: "USA" },
          "indiana":                 { code: "IN",  country: "USA" },
          "iowa":                    { code: "IA",  country: "USA" },
          "kansas":                  { code: "KS",  country: "USA" },
          "kentucky":                { code: "KY",  country: "USA" },
          "louisiana":               { code: "LA",  country: "USA" },
          "maine":                   { code: "ME",  country: "USA" },
          "maryland":                { code: "MD",  country: "USA" },
          "massachusetts":           { code: "MA",  country: "USA" },
          "michigan":                { code: "MI",  country: "USA" },
          "minnesota":               { code: "MN",  country: "USA" },
          "mississippi":             { code: "MS",  country: "USA" },
          "missouri":                { code: "MO",  country: "USA" },
          "montana":                 { code: "MT",  country: "USA" },
          "nebraska":                { code: "NE",  country: "USA" },
          "nevada":                  { code: "NV",  country: "USA" },
          "new hampshire":           { code: "NH",  country: "USA" },
          "new jersey":              { code: "NJ",  country: "USA" },
          "new mexico":              { code: "NM",  country: "USA" },
          "new york":                { code: "NY",  country: "USA" },
          "north carolina":          { code: "NC",  country: "USA" },
          "north dakota":            { code: "ND",  country: "USA" },
          "ohio":                    { code: "OH",  country: "USA" },
          "oklahoma":                { code: "OK",  country: "USA" },
          "oregon":                  { code: "OR",  country: "USA" },
          "pennsylvania":            { code: "PA",  country: "USA" },
          "rhode island":            { code: "RI",  country: "USA" },
          "south carolina":          { code: "SC",  country: "USA" },
          "south dakota":            { code: "SD",  country: "USA" },
          "tennessee":               { code: "TN",  country: "USA" },
          "texas":                   { code: "TX",  country: "USA" },
          "utah":                    { code: "UT",  country: "USA" },
          "vermont":                 { code: "VT",  country: "USA" },
          "virginia":                { code: "VA",  country: "USA" },
          "washington":              { code: "WA",  country: "USA" },
          "west virginia":           { code: "WV",  country: "USA" },
          "wisconsin":               { code: "WI",  country: "USA" },
          "wyoming":                 { code: "WY",  country: "USA" },
          "district of columbia":    { code: "DC",  country: "USA" },

          // 🇲🇽 Mexique – 32 États
          "aguascalientes":          { code: "AGS",  country: "Mexico" },
          "baja california":         { code: "BCN",  country: "Mexico" },
          "baja california sur":     { code: "BCS",  country: "Mexico" },
          "campeche":                { code: "CAM",  country: "Mexico" },
          "chiapas":                 { code: "CHIS", country: "Mexico" },
          "chihuahua":               { code: "CHIH", country: "Mexico" },
          "coahuila":                { code: "COAH", country: "Mexico" },
          "colima":                  { code: "COL",  country: "Mexico" },
          "durango":                 { code: "DUR",  country: "Mexico" },
          "guanajuato":              { code: "GTO",  country: "Mexico" },
          "guerrero":                { code: "GRO",  country: "Mexico" },
          "hidalgo":                 { code: "HGO",  country: "Mexico" },
          "jalisco":                 { code: "JAL",  country: "Mexico" },
          "méxico":                  { code: "MEX",  country: "Mexico" },
          "mexico":                  { code: "MEX",  country: "Mexico" },
          "michoacán":               { code: "MICH", country: "Mexico" },
          "michoacan":               { code: "MICH", country: "Mexico" },
          "morelos":                 { code: "MOR",  country: "Mexico" },
          "nayarit":                 { code: "NAY",  country: "Mexico" },
          "nuevo león":              { code: "NL",   country: "Mexico" },
          "nuevo leon":              { code: "NL",   country: "Mexico" },
          "oaxaca":                  { code: "OAX",  country: "Mexico" },
          "puebla":                  { code: "PUE",  country: "Mexico" },
          "querétaro":               { code: "QRO",  country: "Mexico" },
          "queretaro":               { code: "QRO",  country: "Mexico" },
          "quintana roo":            { code: "QROO", country: "Mexico" },
          "san luis potosí":         { code: "SLP",  country: "Mexico" },
          "san luis potosi":         { code: "SLP",  country: "Mexico" },
          "sinaloa":                 { code: "SIN",  country: "Mexico" },
          "sonora":                  { code: "SON",  country: "Mexico" },
          "tabasco":                 { code: "TAB",  country: "Mexico" },
          "tamaulipas":              { code: "TAMPS",country: "Mexico" },
          "tlaxcala":                { code: "TLA",  country: "Mexico" },
          "veracruz":                { code: "VER",  country: "Mexico" },
          "yucatán":                 { code: "YUC",  country: "Mexico" },
          "yucatan":                 { code: "YUC",  country: "Mexico" },
          "zacatecas":               { code: "ZAC",  country: "Mexico" }
        };

        const region = regionMap[lc];
        if (region) {
          if (!stateCode) stateCode = region.code;
          // Le pays du regionMap est prioritaire sur ce qu'on avait avant
          countryLabel = region.country || countryLabel;
        }

      }


    }

    // Si on n'a pas trouvé de ville dans les listes, on utilise le slug humanisé
    if (!city) {
      name = slug.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
    }

    // Pays par défaut si on n'a toujours rien
    if (!countryLabel) {
      if (/canada/i.test(countryInfo)) countryLabel = "Canada";
      else if (/usa|united states|états-unis/i.test(countryInfo)) countryLabel = "USA";
      else if (/mexico|méxico/i.test(countryInfo)) countryLabel = "Mexico";
      else if (!countryInfo && stateCode) {
        // Pour toi, on suppose Canada si on a juste une province
        countryLabel = "Canada";
      }
    }

    // Détermination du tzKey (HTZ)
    let tzKey = null;

    // 1) Si la ville a déjà un tzKey (ex: depuis ton Sheet), on le respecte
    if (city && typeof city.tzKey === "string" && city.tzKey) {
      tzKey = city.tzKey;
    }

    // 2) Essayer d'abord le couple pays + état, ex: "USA (WA)", "CANADA (BC)"
    if (!tzKey && stateCode && countryLabel) {
      const combo = `${countryLabel.toUpperCase()} (${stateCode.toUpperCase()})`;
      tzKey = tzKeyForState(combo);
    }

    // 3) Ensuite tenter avec juste le code ou le nom brut
    if (!tzKey && stateCode) {
      tzKey = tzKeyForState(stateCode);
    }
    if (!tzKey && countryInfo) {
      tzKey = tzKeyForState(countryInfo);
    }
    if (!tzKey && countryLabel) {
      tzKey = tzKeyForState(countryLabel);
    }

    // 4) Fallback : Mountain (comme ATS vanilla) si vraiment rien trouvé
    if (!tzKey) {
      tzKey = "mtn";
    }

    const abbr = (TZ[tzKey]?.abbr) || "MDT";

    return {
      slug,
      city: name,
      stateCode,
      country: countryLabel,
      tzKey,
      abbr
    };

  } catch (e) {
    console.error("getCurrentHQ error", e);
    return null;
  }
}


// Label QG: "Ville, État (Pays), ABBR" avec cache solide
// Label QG: "Ville, État, Pays"
// Label QG: "Ville, État, Pays" (avec cache)
function refreshHQLabel(fromWatcher = false) {
  const el = document.getElementById("hqLabel");
  if (!el) return;

  const CACHE_LABEL_KEY = 'atselog.cache.hqLabelText';
  const CACHE_SLUG_KEY  = 'atselog.cache.hqSlug';

  // Slug actuel du QG (vient du save_game / API)
  let currentSlug = '';
  if (typeof getSavedHQSlug === 'function') {
    currentSlug = getSavedHQSlug() || '';
  } else {
    currentSlug =
      localStorage.getItem('atselog.hq_city') ||
      localStorage.getItem('atselog.htz.raw_city') ||
      '';
  }
  currentSlug = String(currentSlug).trim();

  const cachedLabel = localStorage.getItem(CACHE_LABEL_KEY) || '';
  const cachedSlug  = localStorage.getItem(CACHE_SLUG_KEY)  || '';

  // 1) Même QG qu'avant + label déjà calculé → on réutilise tel quel
  if (cachedLabel && cachedSlug && cachedSlug === currentSlug) {
    el.textContent = cachedLabel;
    return;
  }

  // 2) Nouveau QG détecté mais les villes ne sont pas prêtes → on attend
  //    (on ne change pas le texte pour éviter une valeur "sale" type MDT)
  if (currentSlug && !window.citiesReady) {
    return;
  }

  let label = "QG et fuseau horaire non défini";
  let hq = null;

  try {
    hq = (typeof getCurrentHQ === "function") ? getCurrentHQ() : null;

    if (hq) {
      const parts = [];
      if (hq.city)      parts.push(hq.city);
      if (hq.stateCode) parts.push(hq.stateCode);
      if (hq.country)   parts.push(hq.country);
      label = parts.join(", ");
      if (hq.abbr) label += ", " + hq.abbr;
    }
  } catch (e) {
    console.error("refreshHQLabel error", e);
  }

  el.textContent = label;

  // 3) Sauvegarde du label + slug pour les prochains refresh
  try {
    if (hq) {
      localStorage.setItem(CACHE_LABEL_KEY, label);
      localStorage.setItem(CACHE_SLUG_KEY, currentSlug || hq.slug || '');
      // On met aussi à jour le cache TZ HQ utilisé ailleurs
      if (hq.tzKey && window.TZ && TZ[hq.tzKey]) {
        const tz = TZ[hq.tzKey];
        localStorage.setItem('atselog.tz', JSON.stringify({
          key: hq.tzKey,
          abbr: tz.abbr || hq.abbr || hq.tzKey.toUpperCase(),
          offFinal: tz.off
        }));
      }
    } else {
      // QG non défini → on nettoie le cache HQ
      localStorage.removeItem(CACHE_LABEL_KEY);
      localStorage.removeItem(CACHE_SLUG_KEY);
      localStorage.removeItem('atselog.tz');
    }
  } catch (e) {
    console.warn("[HQ] refreshHQLabel cache error", e);
  }
}



// Normalisation pour comparer les noms/slug de villes
function _normCityKey(v) {
  return (v || "")
    .toString()
    .toLowerCase()
    .replace(/\s+/g, "")      // espaces
    .replace(/[_-]/g, "")     // underscore et tirets
    .replace(/city$/g, "");   // suffixe "city"
}

// Cherche une ville (Trucky / Sheet / local) à partir d'un slug
function getCityBySlugSmart(slug) {
  if (!slug) return null;

  const q = _normCityKey(slug);
  const sources = [
    window.citiesFinal,
    window.citiesSheet,
    window.citiesLocal,
    window.citiesTrucky
  ];

  for (const arr of sources) {
    if (!Array.isArray(arr)) continue;

    // 1) Match exact (_id, realName ou name)
    for (const c of arr) {
      const keys = [
        c._id,
        c.realName,
        c.name
      ].map(_normCityKey);
      if (keys.some(v => v === q)) return c;
    }

    // 2) Match "large" / partiel :
    //    - "coquitlam_bc" doit matcher "coquitlam"
    //    - ou l'inverse
    for (const c of arr) {
      const keys = [
        c._id,
        c.realName,
        c.name
      ].map(_normCityKey);
      if (keys.some(v => v && (v.includes(q) || q.includes(v)))) {
        return c;
      }
    }
  }

  return null;
}


document.addEventListener('DOMContentLoaded', async () => {
  try {
    if (!localStorage.getItem('atselog.hq_city') &&
        !localStorage.getItem('atselog.htz.raw_city')) {
      const r = await fetch('/api/profile/hq', {cache:'no-store'});
      const j = await r.json();
      if (j?.ok && j.hq_city) localStorage.setItem('atselog.hq_city', j.hq_city);
    }
  } catch {}
  if (typeof refreshHQLabel === 'function') refreshHQLabel();
    // 1) Si aucun HQ connu, tenter l’API (marche OFF/AUTO/HTZ)
  if (!getSavedHQSlug()) {
    await ensureHQFromApi();
  }
  // 2) Brancher le bouton détecter (ID correct)
  const btn = document.getElementById('detectHQBtn');
  if (btn){
    btn.addEventListener('click', async () => {
      await ensureHQFromApi();
      if (typeof refreshHQLabel === 'function') refreshHQLabel();
    });
  }

  // 3) Rafraîchir la ligne QG tout de suite
  if (typeof refreshHQLabel === 'function') refreshHQLabel();
});

// ====== Auto-watch du QG depuis /api/profile/hq ======
let hqWatchTimer = null;

function _slugifyCityName(s=""){ return String(s).toLowerCase().replace(/\s+/g,'_').trim(); }

// Tick: interroge l'API et met à jour si changement
async function _hqWatchTick(){
  // si la page est cachée, on saute ce tick (limite la charge)
  if (document.hidden) return;
  try{
    const r = await fetch('/api/profile/hq?ts=' + Date.now(), { cache: 'no-store' });
    const j = await r.json();
    if (!j || !j.ok || !j.hq_city) return;

    const newSlug = _slugifyCityName(j.hq_city);
    const oldSlug = localStorage.getItem('atselog.hq_city') ||
                    localStorage.getItem('atselog.htz.raw_city') || '';

    if (!newSlug || newSlug === oldSlug) return;

    // 1) enregistre le nouveau QG
    localStorage.setItem('atselog.hq_city', newSlug);

	// --- Programmer le nouveau fuseau pour "demain RODS" ---
	if (window.lastGameData) {
	  const data = window.lastGameData;
	  const oldKey = getRodsTzKeyForDay(getRodDayId(data.game_day, data.game_time, getCurrentHTZKey()));
	  const newKey = getCurrentHTZKey(); // après la maj de HQ, recalcul
	  scheduleRodsTzChangeForTomorrow(data.game_day, data.game_time, oldKey, newKey);
	}


    // 2) si la base villes n'est pas prête, ne casse pas l'affichage :
    //    garde l'ancien label en attendant, et un refresh forcé plus tard
    if (!window.citiesReady) {
      // on laissera le setInterval "citiesReady" re-peindre correctement
      return;
    }

    // 3) base prête → rafraîchis le label maintenant
    if (typeof window.refreshHQLabel === 'function') window.refreshHQLabel(true);

    // 4) si on est en HTZ, l'abréviation impacte l'heure du header
    if (typeof getTzMode === 'function' && getTzMode() === 'htz' && window.lastGameData) {
      updateDisplayedTime(window.lastGameData);
    }
	
	// ... après avoir détecté que le HQ a changé et mis à jour localStorage ...
	if (window.lastGameData) {
	  const data = window.lastGameData;
	  const oldKey = getRodsTzKeyForDay(getRodDayId(data.game_day, data.game_time, getCurrentHTZKey())); // clé du "aujourd'hui RODS"
	  const newKey = getCurrentHTZKey(); // après update HQ, re-calcule la clé HTZ "nouvelle"
	  scheduleRodsTzChangeForTomorrow(data.game_day, data.game_time, oldKey, newKey);
	}
	// rafraîchis le label QG comme tu le fais déjà
	if (window.refreshHQLabel) window.refreshHQLabel(true);
	// si header en mode HTZ, l'abréviation peut changer (mais logs restent sur le tz gelé du jour)
	if (getTzMode && getTzMode()==='htz' && window.lastGameData) updateDisplayedTime(window.lastGameData);

  }catch(e){
    // silencieux : on réessaiera au tick suivant
  }
}

function startHQWatcher(periodMs = 7000){
  stopHQWatcher();
  hqWatchTimer = setInterval(_hqWatchTick, periodMs);
  _hqWatchTick(); // premier tick immédiat
}
function stopHQWatcher(){
  if (hqWatchTimer){ clearInterval(hqWatchTimer); hqWatchTimer = null; }
}

// Reprendre quand l'onglet redevient visible
document.addEventListener('visibilitychange', () => {
  if (!document.hidden && hqWatchTimer) _hqWatchTick();
});

// Démarrer au chargement
document.addEventListener('DOMContentLoaded', () => {
  startHQWatcher(7000); // 7 s est un bon compromis; mets 5000 si tu veux plus vif
});


// Détecte et enregistre le QG depuis la position jeu (si rien n’est stocké)
window.ensureHQFromData = function(data){
  if (!data) return false;
  if (localStorage.getItem('atselog.hq_city') || localStorage.getItem('atselog.htz.raw_city')) return true;
  if (!Number.isFinite(data.pos_x) || !Number.isFinite(data.pos_y)) return false;
  if (typeof nearestCity !== 'function' || !window.citiesReady) return false;

  const c = nearestCity(Number(data.pos_x), Number(data.pos_y));
  if (!c) return false;

  // On prend le NOM de la ville comme base (et plus l’ID numérique 1755, etc.)
  const baseName = c.realName || c.name || c._id || '';
  const slug = _slugifyCityName(baseName);
  if (!slug) return false;

  localStorage.setItem('atselog.hq_city', slug);
  if (window.refreshHQLabel) window.refreshHQLabel();
  if (window.lastGameData)   updateDisplayedTime(window.lastGameData);
  return true;
};


const detectBtn = document.getElementById('detectHQBtn');
if (detectBtn) detectBtn.addEventListener('click', () => window.ensureHQFromData(window.lastGameData));


// --- Mapping texte -> clé TZ interne (pac/mtn/cen/est/ak) ---
function tzKeyForState(state) {
  const raw = String(state || '').trim();
  if (!raw) return 'mtn';

  const lower = raw.toLowerCase();

  // Provinces canadiennes : on accepte plusieurs formats
  if (/colombie[- ]britannique|british columbia|\(bc\)|^bc$/.test(lower)) return 'pac';
  if (/yukon|\(yt\)|^yt$/.test(lower))                                      return 'pac';

  if (/alberta|\(ab\)|^ab$/.test(lower))                                    return 'mtn';
  if (/northwest territories|territoires du nord[- ]ouest|\(nt\)|^nt$/.test(lower)) return 'mtn';

  if (/saskatchewan|\(sk\)|^sk$/.test(lower))                               return 'cen';
  if (/manitoba|\(mb\)|^mb$/.test(lower))                                   return 'cen';

  if (/ontario|\(on\)|^on$/.test(lower))                                    return 'est';
  if (/qu[eé]bec|\(qc\)|^qc$/.test(lower))                                  return 'est';

  // Version "pays (code)" en majuscules (comme dans ton JSON villes)
  const s = raw.toUpperCase();

  if ([
    "USA (CA)","USA (OR)","USA (WA)","USA (NV)",
    "CANADA (BC)","CANADA (YT)","MEXICO (BC)"
  ].includes(s)) return 'pac';

  if ([
    "USA (MT)","USA (WY)","USA (UT)","USA (CO)",
    "USA (AZ)","USA (NM)",
    "CANADA (AB)","CANADA (NT)"
  ].includes(s)) return 'mtn';

  if ([
    "USA (ND)","USA (SD)","USA (NE)","USA (KS)","USA (OK)","USA (TX)",
    "USA (MN)","USA (IA)","USA (MO)","USA (AR)","USA (LA)",
    "USA (WI)","USA (IL)","USA (MS)","USA (AL)",
    "CANADA (SK)","CANADA (MB)"
  ].includes(s)) return 'cen';

  if ([
    "USA (MI)","USA (IN)","USA (KY)","USA (TN)","USA (GA)","USA (FL)",
    "USA (SC)","USA (NC)","USA (VA)","USA (WV)","USA (OH)",
    "USA (PA)","USA (NY)","USA (VT)","USA (NH)","USA (ME)",
    "CANADA (ON)","CANADA (QC)"
  ].includes(s)) return 'est';

  if (["USA (AK)"].includes(s)) return (TZ.ak ? 'ak' : 'pac');

  // défaut : MDT comme ATS vanilla
  return 'mtn';
}


// Trouver une ville depuis le stockage villes (pour HTZ)
function _findCityBySlugOrName(s){
  const list = Array.isArray(window.citiesFinal) ? window.citiesFinal : [];
  if (!list.length) return null;
  const q = _slugifyCityName(s);
  for (const c of list){
    const slug = _slugifyCityName(c.realName||c.name||'');
    const id   = _slugifyCityName(c._id||'');
    if (q===slug || q===id) return c;
  }
  // tolérant (ex: "salt lake" → "salt lake city")
  for (const c of list){
    const nm = String(c.realName||c.name||'').toLowerCase();
    if (nm.startsWith(s.toLowerCase()) || nm.includes(s.toLowerCase())) return c;
  }
  return null;
}

// Offset/abbr communs (en minutes / abbr), selon mode + data
// Offset/abbr communs (en minutes / abbr), selon mode + data
window.getTzOffsetMin = function (data) {
  const mode = getTzMode();
  let key = null, abbr = '', off = 0; // off en HEURES (relatif MDT)

  function keyFromCity(c) {
    if (!c) return null;
    if (typeof c.tzKey === 'string' && c.tzKey) return c.tzKey;
    return tzKeyForState(c.state || c.country || '');
  }

  if (mode === 'auto') {
    const c = (window.citiesReady && Number.isFinite(data?.pos_x))
      ? nearestCity(Number(data.pos_x), Number(data.pos_y))
      : null;
    key = keyFromCity(c);
	
  }else if (mode === 'htz') {
    // 1) Priorité : on réutilise la même API HQ que pour le label 🏠 et les Logs
    if (typeof getCurrentHQ === 'function') {
      const hq = getCurrentHQ();
      if (hq && hq.tzKey && TZ[hq.tzKey]) {
        key  = hq.tzKey;
        abbr = TZ[hq.tzKey].abbr;
        off  = TZ[hq.tzKey].off;
      }
    }

    // 2) Fallback : ancien comportement si jamais getCurrentHQ ne renvoie rien
  if (!key) {
      const slug =
        localStorage.getItem('atselog.hq_city') ||
        localStorage.getItem('atselog.htz.raw_city') ||
        '';
      const c = slug ? _findCityBySlugOrName(slug) : null;
      key = keyFromCity(c);
    }
  }

  // Au démarrage, les listes de villes arrivent de façon asynchrone. Pour le
  // mode HTZ, garder le dernier fuseau QG validé évite un bref retour à MDT
  // et permet la lecture sans connexion à ATS.
  if (!key && mode === 'htz') {
    try {
      const cached = JSON.parse(
        localStorage.getItem('atselog.cache.tz') ||
        localStorage.getItem('atselog.tz') ||
        '{}'
      );
      if (cached?.key && TZ[cached.key]) {
        key = cached.key;
      } else if (Number.isFinite(cached?.offFinal)) {
        key = Object.keys(TZ).find(k => TZ[k].off === cached.offFinal) || null;
      }
    } catch {}
  }

  if (key && TZ[key]) {
    off  = TZ[key].off;
    abbr = TZ[key].abbr;
  }

  // Globals + caches
  window.timeZoneOffset = off;
  window.timeZoneAbbr   = abbr;
  try {
    // on stocke maintenant aussi la clé "key" pour la page Logs
    localStorage.setItem('atselog.tz', JSON.stringify({ key, offFinal: off, abbr }));
    localStorage.setItem(
      'atselog.cache.tz',
      JSON.stringify({ mode, key, abbr, offFinal: off, t: Date.now() })
    );
  } catch {}

  return { offMin: off * 60, abbr };
};



// ==== HOS_OVERRUN_V2 — drive+work en négatif + somme sur primary (persistance) ====
(function(){
  const LSKEY = 'atselog.overrun.v2';

  function HHMM_to_sec(s) {
    if (!s) return NaN;
    const m = String(s).trim().replace(/^[-−]/,'').match(/^(\d{1,2}):(\d{2})$/);
    if (!m) return NaN;
    const sec = (+m[1])*3600 + (+m[2])*60;
    return /^[-−]/.test(String(s)) ? -sec : sec;
  }
  function sec_to_HHMM(sec){
    sec = Math.max(0, sec|0);
    const h = String(Math.floor(sec/3600)).padStart(2,'0');
    const m = String(Math.floor((sec%3600)/60)).padStart(2,'0');
    return `${h}:${m}`;
  }
  function normDayMin(min){ return ((min|0)%1440 + 1440) % 1440; }

  const S = (function load(){
    try { return JSON.parse(localStorage.getItem(LSKEY) || '{}'); } catch{ return {}; }
  })();
  if (!Number.isFinite(S.driveAccumMin)) S.driveAccumMin = 0;
  if (!Number.isFinite(S.workAccumMin))  S.workAccumMin  = 0;
  if (!Number.isFinite(S.lastGameMin))   S.lastGameMin   = null;
  if (typeof S.driveActive !== 'boolean') S.driveActive = false;
  if (typeof S.workActive  !== 'boolean') S.workActive  = false;

  function save(){ try{ localStorage.setItem(LSKEY, JSON.stringify(S)); }catch{} }

  window.HOS_OVERRUN_V2 = {
    update(data) {
      const elP = document.getElementById('primary-timer');
      const elD = document.getElementById('driveTimer');
      const elW = document.getElementById('workdayTimer');
      if (!elP || !elD || !elW) return;

      const gameMin   = normDayMin(data.game_time||0);
      const statusNum = data.status|0; // 0 OFF,1 SB,2 D,3 ON

      // Entrées en infraction (le plugin renvoie souvent 00:00 au plancher → on prend <=0)
      const driveRemSec = HHMM_to_sec(data.drive_rem);
      const workRemSec  = HHMM_to_sec(data.workday_rem || data.rest_rem);
      if (!S.driveActive && Number.isFinite(driveRemSec) && driveRemSec <= 0) S.driveActive = true;
      if (!S.workActive  && Number.isFinite(workRemSec)  && workRemSec  <= 0) S.workActive  = true;

      // Delta minute jeu depuis le dernier tick (wrap minuit OK)
      if (S.lastGameMin == null) S.lastGameMin = gameMin;
      let dMin = gameMin - S.lastGameMin;
      if (dMin < 0) dMin += 1440;
      S.lastGameMin = gameMin;

      // Accumuler uniquement pendant le bon statut
      if (statusNum === 2 && S.driveActive) S.driveAccumMin += dMin; // DRIVING
      if (statusNum === 3 && S.workActive)  S.workAccumMin  += dMin; // ON

      // Reset complet uniquement après repos (quand les DEUX timers redeviennent > 00:01)
      if ((S.driveActive || S.workActive) &&
          Number.isFinite(driveRemSec) && driveRemSec > 60 &&
          Number.isFinite(workRemSec)  && workRemSec  > 60) {
        S.driveActive = S.workActive = false;
        S.driveAccumMin = S.workAccumMin = 0;
        elP.dataset.isOverrun = elD.dataset.isOverrun = elW.dataset.isOverrun = '';
        elP.classList.remove('timer-violation','hos-pulse');
        elD.classList.remove('timer-violation');
        elW.classList.remove('timer-violation');
        save();
        return;
      }

      // Rendu: mettre négatif (au moins -00:01 dès l’entrée)
      const driveNegSec = S.driveActive ? Math.max(60, S.driveAccumMin*60) : 0;
      const workNegSec  = S.workActive  ? Math.max(60, S.workAccumMin*60)  : 0;

      // DRIVE
      if (S.driveActive) {
        elD.textContent = '-' + sec_to_HHMM(driveNegSec);
        elD.classList.add('timer-violation');
        elD.dataset.isOverrun = '1';
      } else if (elD.dataset.isOverrun === '1') {
        elD.dataset.isOverrun = '';
        elD.classList.remove('timer-violation');
        if (elD.dataset.rawTimer) elD.textContent = elD.dataset.rawTimer;
      }

      // WORKDAY
      if (S.workActive) {
        elW.textContent = '-' + sec_to_HHMM(workNegSec);
        elW.classList.add('timer-violation');
        elW.dataset.isOverrun = '1';
      } else if (elW.dataset.isOverrun === '1') {
        elW.dataset.isOverrun = '';
        elW.classList.remove('timer-violation');
        if (elW.dataset.rawTimer) elW.textContent = elW.dataset.rawTimer;
      }

      // PRIMARY = somme des deux négatifs
      const sumNegSec = driveNegSec + workNegSec;
        if (sumNegSec > 0) {
		  elP.textContent = '-' + sec_to_HHMM(sumNegSec);
		  elP.classList.add('timer-violation');   // pas de pulse
		  elP.dataset.isOverrun = '1';
		} else if (elP.dataset.isOverrun === '1') {
		  elP.dataset.isOverrun = '';
		  elP.classList.remove('timer-violation'); // pas de pulse
		  if (elP.dataset.rawTimer) elP.textContent = elP.dataset.rawTimer;
		}

      save();
    }
  };
})();


function warnAboutMissingTrailerPlate(data) {
  // Conservé pour compatibilité avec les anciens appels. L'alerte est gérée
  // plus bas par checkTrailerPlatesOnD(), sous forme d'overlay ELD plutôt que
  // par confirm(), afin de ne jamais afficher « localhost:8080 indique ».
}

function updateUI(data) {
	// console.log("Coords ATS :", data.pos_x, data.pos_y, "type:", typeof data.pos_x, typeof data.pos_y);
	// console.log("[ATS-Plugin] Données reçues:", data);

  window.lastGameData = data;
  try { warnAboutMissingTrailerPlate(data); } catch (_) {}
  const isArcade = data.Auto === 1;
  
// Le calcul du fuseau est centralisé dans getTzOffsetMin(). L'ancien bloc
// réécrivait systématiquement le choix HTZ avec la position courante ; il
// pouvait donc envoyer PDT au plugin alors que l'écran indiquait Chicago/CDT.
syncSelectedTimezoneWithPlugin(data);

// La ville courante reste nécessaire à l'affichage et à /api/set_location.
// Elle ne décide plus du fuseau quand le mode HTZ est sélectionné.
const city = window.citiesReady
  ? nearestCity(Number(data.pos_x), Number(data.pos_y))
  : null;


// ----- Ville + fuseau -----
const elVille = document.getElementById("villeActuelle");
const elEtat  = document.getElementById("etatActuel");

if (window.citiesReady && city?.realName) {
  // Les sources de villes se chargent successivement (local, Sheet, Trucky).
  // Une localisation doit donc être confirmée deux fois avant de remplacer
  // l'affichage, ce qui supprime le clignotement temporaire au rafraîchissement.
  const candidateKey = `${city.realName}|${city.country || ''}`;
  const stableKey = stableCity ? `${stableCity.realName}|${stableCity.country || ''}` : '';
  if (candidateKey === stableKey) {
    pendingCityKey = '';
    pendingCityHits = 0;
  } else if (candidateKey === pendingCityKey) {
    if (++pendingCityHits >= 2) {
      stableCity = city;
      pendingCityKey = '';
      pendingCityHits = 0;
    }
  } else {
    pendingCityKey = candidateKey;
    pendingCityHits = 1;
    // Au tout premier affichage, la télémétrie du plugin est plus fiable que
    // la première base de villes chargée. On la garde donc jusqu'à la seconde
    // confirmation de nearestCity(), ce qui évite les sauts de ville/État.
    if (!stableCity && data.city) {
      stableCity = { realName: data.city, country: data.state || '' };
    } else if (!stableCity) {
      stableCity = city;
    }
  }
}

const displayedCity = stableCity || (data.city ? {
  realName: data.city,
  country: data.state || ''
} : null);

if (displayedCity) {
  if (elVille) elVille.textContent = displayedCity.realName || "—";
  if (elEtat)  elEtat.textContent  = displayedCity.country || "";

  // On n'envoie au plugin que la localisation confirmée, jamais une valeur
  // transitoire fournie par une base de villes encore en cours de chargement.
  const cityToSend = stableCity;

  // Envoi au plugin une seule fois quand la ville change
  if (cityToSend && cityToSend.realName && cityToSend.country &&
      (cityToSend.realName !== lastCitySent || cityToSend.country !== lastStateSent)) {
    fetch('/api/set_location', {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ city: cityToSend.realName, state: cityToSend.country })
    }).catch(() => {});
    lastCitySent = cityToSend.realName;
    lastStateSent = cityToSend.country;
  }
}

// -------------------------------- Info Truck Trailer --------------------------------
const chaineTypeRaw = (data.trailer_ChainType || "").toLowerCase();
// on normalise pour matcher "road train", "train routier", "bi-train", etc.
const chaineType = chaineTypeRaw.replace(/[\s\-_]/g, "");

// 👉 Viser le CONTENEUR .form-field (ou #tf2/#tf3) pour tout cacher/afficher (label + input)
const group2 =
  document.getElementById("input_trailer_immat_2")?.closest(".form-field") ||
  document.getElementById("tf2") ||
  document.getElementById("input_trailer_immat_2")?.parentElement;

const group3 =
  document.getElementById("input_trailer_immat_3")?.closest(".form-field") ||
  document.getElementById("tf3") ||
  document.getElementById("input_trailer_immat_3")?.parentElement;

const manualTrailer1 = document.getElementById("manualTrailer1");
const trailerIsConnected = data.trailer_connected === true;
const trailerHasNativePlate = data.trailer_has_native_plate === true;
const needsManualTrailerPlate = trailerIsConnected && !trailerHasNativePlate;
if (manualTrailer1) manualTrailer1.style.display = needsManualTrailerPlate ? "" : "none";

// Par défaut, on cache Trailer 2 et 3
if (group2) group2.style.display = "none";
if (group3) group3.style.display = "none";

// Double / bi-train  → afficher Trailer 2
if (/double|bitrain/.test(chaineType)) {
  if (group2) group2.style.display = "";
}

// Triple / road train / train routier → afficher Trailer 2 et Trailer 3
if (/triple|roadtrain|trainroutier/.test(chaineType)) {
  if (group2) group2.style.display = "";
  if (group3) group3.style.display = "";
}

// --- Masquer ou afficher le bouton "Enregistrer plaques secondaires" ---
const saveBtn = document.getElementById("saveTrailerPlatesBtn"); // adapte l'id exact
if (saveBtn) {
  // Par défaut, cacher le bouton
  saveBtn.style.display = "none";

  // Afficher s'il faut renseigner une plaque manuelle ou un attelage multiple.
  if (needsManualTrailerPlate || /double|bitrain|triple|roadtrain|trainroutier/.test(chaineType)) {
    saveBtn.style.display = "";
  }
  if (/triple|roadtrain|trainroutier/.test(chaineType)) {
  if (group2) group2.style.display = "";
  if (group3) group3.style.display = "";
  }
}



// (le reste de ton remplissage d’infos…)
const eltrailer_name = document.getElementById('trailer_name');
if (eltrailer_name) eltrailer_name.textContent = data.trailer_name || 'N/A';

const eltrailer_immat = document.getElementById('trailer_immat');
if (eltrailer_immat) eltrailer_immat.textContent = data.trailer_immat || 'N/A';

const eltrailer_immat_country = document.getElementById('trailer_immat_country');
if (eltrailer_immat_country) eltrailer_immat_country.textContent = data.trailer_immat_country || 'N/A';

// Le rafraîchissement télémétrie ne doit jamais effacer ce que le chauffeur
// vient de saisir en cliquant hors d'un champ. On conserve donc un brouillon
// local jusqu'à l'enregistrement explicite.
function syncTrailerDraftInput(id, serverValue) {
  const input = document.getElementById(id);
  if (!input) return;
  const key = `atselog.trailerDraft.${id}`;
  if (!input.dataset.draftBound) {
    input.dataset.draftBound = '1';
    input.addEventListener('input', () => {
      input.dataset.dirty = '1';
      sessionStorage.setItem(key, input.value);
    });
  }
  const draft = sessionStorage.getItem(key);
  if (input.dataset.dirty === '1' || draft !== null) {
    input.value = draft ?? input.value;
    return;
  }
  input.value = serverValue || '';
}
syncTrailerDraftInput("input_trailer_immat_manual", data.trailer_immat_manual);
syncTrailerDraftInput("input_trailer_immat_country_manual", data.trailer_immat_country_manual);

// Placeholders facultatifs
const eltrailer_immat_2 = document.getElementById("input_trailer_immat_2");
if (eltrailer_immat_2) eltrailer_immat_2.placeholder = data.trailer_immat_2 || "";
const eltrailer_immat_3 = document.getElementById("input_trailer_immat_3");
if (eltrailer_immat_3) eltrailer_immat_3.placeholder = data.trailer_immat_3 || "";

	
//-----------------------------------------------------------------------------------


// --- PRIMARY (toujours stocker la valeur reçue, mais n'afficher que si pas en overrun)
{
	const el = document.getElementById('primary-timer');
	if (el) {
	  const incoming = data.drive_rem || '--:--';
	  el.dataset.rawTimer = incoming;
	  if (el.dataset.isOverrun !== '1') {
		el.textContent = incoming;
		// NE PAS toucher aux classes ici : applyClasses() gère l'habillage
	  }
	}
}

// --- DRIVE
{
  const el = document.getElementById('driveTimer');
  if (el) {
    const incoming = data.drive_rem || '--:--';
    el.dataset.rawTimer = incoming;
    if (el.dataset.isOverrun !== '1') el.textContent = incoming;
  }
}

// --- WORKDAY
{
  const el = document.getElementById('workdayTimer');
  if (el) {
    const incoming = (data.workday_rem || data.rest_rem || '--:--').trim();
    el.dataset.rawTimer = incoming;
    if (el.dataset.isOverrun !== '1') el.textContent = incoming;
  }
}


// --- Normaliser le temps jeu (sert aux ticks overrun)
window._lastGameMin = ((data.game_time|0) % 1440 + 1440) % 1440;
window.lastGameData = data; // accessible par le tick overrun

// Auto QG une fois que pos & citiesReady sont dispo
// ⚠ Ancienne logique : on détectait automatiquement le QG à partir
// de la position dès qu'aucun HQ n'était stocké.
// Résultat : si la save_game n'était pas lisible, la ville actuelle devenait QG.
// ➜ On désactive complètement cette auto-détection. Le QG reste
//    "non défini" tant qu'il ne vient pas du save_game / API
//    ou d'un clic manuel sur "Détecter mon QG".
if (!localStorage.getItem('atselog.hq_city') && !localStorage.getItem('atselog.htz.raw_city')) {
  // Ne rien faire ici.
}


// === OVERRUN v2: somme Drive+Work et persistance
HOS_OVERRUN_V2.update(data);

// -- Stabiliser le primary pendant un overrun (verrou rouge fixe) --
{
  const elP = document.getElementById('primary-timer');
  if (elP && elP.dataset.isOverrun === '1') {
    elP.classList.add('timer-violation');
    elP.classList.remove('timer-warning','hos-pulse'); // aucune animation ni retour au bleu
  }
}


// === TRIGGER OVERRUN — entrée unique quand on passe ≤ 00:00 =================
(function () {
  const elP = document.getElementById('primary-timer');
  if (!elP || elP.dataset.isOverrun === '1') return; // si déjà en overrun, ne rien faire

  // Statut courant (numérique + texte pour robustesse)
  const stNum = data.status; // 0=OFF,1=SB,2=D,3=ON
  const stTxt = (data.status_name || '').toUpperCase();
  const isDriving = (stNum === 2) || (stTxt === 'D' || stTxt === 'DRIVING');
  const isOn      = (stNum === 3) || (stTxt === 'ON');

  // Parse "HH:MM" -> secondes (gère signe éventuel)
  const toSec = (s) => {
    s = String(s || '').trim();
    const neg = /^[-−]/.test(s);
    const m = s.replace(/^[-−]/,'').match(/^(\d{1,2}):(\d{2})$/);
    if (!m) return NaN;
    const sec = (+m[1])*3600 + (+m[2])*60;
    return neg ? -sec : sec;
  };

  const driveSec = toSec(data.drive_rem);
  const workSec  = toSec(data.workday_rem || data.rest_rem);

  // Déclenchement: en D on surveille "conduite restante", en ON "service restant"
  if ((isDriving && Number.isFinite(driveSec) && driveSec <= 0) ||
      (isOn      && Number.isFinite(workSec)  && workSec  <= 0)) {
    window.hosEnterOverrunIfNeeded(elP.textContent || '');
  }
})();


const elRest = document.getElementById('restTimer');
if (elRest) elRest.textContent = formatHMM(parseHHMMtoSec(data.rest_timer || "0:00"));

const elCycle = document.getElementById('cycleTimer');
if (elCycle) {
  const raw = (data.cycle_rem || "--:--").trim();
  const m = (function parseHMFlexible(s){
    const str = String(s).trim();
    const neg = /^[-−]/.test(str);
    const [H,M] = str.replace(/^[-−]/,'').split(':').map(x => parseInt(x || '0', 10));
    if (Number.isNaN(H) || Number.isNaN(M)) return NaN;
    return (neg ? -1 : 1) * (H*60 + M);
  })(raw);
  if (Number.isFinite(m)) {
    const sign = m < 0 ? "-" : "";
    const a = Math.abs(m);
    const H = String(Math.floor(a/60)).padStart(2,'0');
    const M = String(a % 60).padStart(2,'0');
    elCycle.textContent = `${sign}${H}:${M}`;
  } else {
    elCycle.textContent = raw;
  }
}

const elelog_day = document.getElementById('elog-day');
	if (elelog_day) elelog_day.textContent   = data.dayName   || 'Jour';

const elelog_week = document.getElementById('elog-week')
	if (elelog_week) elelog_week.textContent  = data.weekNum||'--';
  
const eltruck_model = document.getElementById('truck_model')
	if (eltruck_model) eltruck_model.textContent  = data.truck_model||'--';  

const eltruck_marque = document.getElementById('truckMake')
	if (eltruck_marque) eltruck_marque.textContent  = data.truck_marque||'--';  
	
const eltruck_immat = document.getElementById('truckPlate')
	if (eltruck_immat) eltruck_immat.textContent  = data.truck_immat||'--';  
	
 const eltruck_immat_country = document.getElementById('truckPlateCountry')
	if (eltruck_immat_country) eltruck_immat_country.textContent  = data.truck_immat_country||'--';  
	
 const eltrailer_ChainType = document.getElementById('trailer_ChainType')
	if (eltrailer_ChainType) eltrailer_ChainType.textContent  = data.trailer_ChainType||'--'; 

 const eltrailer_body_type = document.getElementById('trailer_body_type')
	if (eltrailer_body_type) eltrailer_body_type.textContent  = data.trailer_body_type||'--'; 	
	
 const elGpsX = document.getElementById('gps_x');
	if (elGpsX) elGpsX.textContent = (data.pos_x ?? '--');

const elGpsZ = document.getElementById('gps_z');
	if (elGpsZ) elGpsZ.textContent = (data.pos_y ?? '--'); // ton Z = pos_y
	

	
//Timer central Timeline
const elelog_timer = document.getElementById('elog-timer')
	if (elelog_timer) elelog_timer.textContent = formatHMM((data.current_state_time||0));
	
//Heure Total Timeline
// Met à jour les totaux (OFF, SB, D, ON) colonne droite
function safeSetText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;	
}

if (data.total_OFF !== undefined) safeSetText('total-OFF', formatMinutesToHM(data.total_OFF));
if (data.total_SB  !== undefined) safeSetText('total-SB',  formatMinutesToHM(data.total_SB));
if (data.total_D   !== undefined) safeSetText('total-D',   formatMinutesToHM(data.total_D));
if (data.total_ON  !== undefined) safeSetText('total-ON',  formatMinutesToHM(data.total_ON));




  // 1) Mise à jour de l’état & désactivation des boutons
['OFF','SB','D','ON'].forEach((s,i) => {
  const b = document.getElementById('btn-'+s);
  if (!b) return;
  // active selon le statut
  b.classList.toggle('active', data.status === i);
  // en mode arcade, tous désactivés ; sinon seul D reste grisé
  b.disabled = isArcade || (s === 'D');

  // 2) On bind l’override manuel **uniquement** si non-arcade et bouton cliquable
  if (!isArcade && s !== 'D') {
    b.onclick = () => {
      fetch(`/api/eld/override?mode=manuel&status=${s}`);
      console.log(`[HOS] Override manuel : ${s}`);
    };
  } else {
    // en mode arcade ou D, on supprime tout handler
    b.onclick = null;
  }
});

  const versionTags = document.querySelectorAll('[data-version]');
  versionTags.forEach(tag => tag.textContent = data.version || "v1.1.15");
  
  // Affichage heure jeu/fuseau
  updateDisplayedTime(data);

  // La grille suit exactement le mode choisi dans Réglages. En particulier,
  // « Désactivé » signifie heure de base ATS et offset 0 — jamais HTZ.
  let timelineOffsetMin = 0;
  try {
    const mode = getTzMode();
    if (mode !== 'off' && typeof window.getTzOffsetMin === 'function') {
      timelineOffsetMin = Number(window.getTzOffsetMin(data)?.offMin) || 0;
    }
  } catch (e) {
    console.warn("[Timeline] offset par défaut 0", e);
  }

  // 2) On prépare la grille une seule fois
  if (!window.timelineReady) {
    buildHourRow();
    window.timelineReady = true;
  }

  // 3) Copie locale de l'historique des statuts (base = minute jeu)
  const hist = Array.isArray(data.status_history)
    ? data.status_history.map(s => ({ ...s }))
    : [];

  // Le plugin fournit déjà un segment "live" fermé à l'instant courant.
  // Ne jamais le recalculer ici : start_time_min/end_time_min sont des minutes
  // absolues depuis le début de la sauvegarde, et non des minutes 0..1439.

  // 4) On (re)dessine dans le référentiel explicitement choisi.
  renderTimelineGridAndSegments(hist, timelineOffsetMin);






// Reset des plaques secondaires et du flag popup si dételage (bobtail)
if (!data.trailer_connected || !data.trailer_ChainType || data.trailer_ChainType.trim() === "") {
  localStorage.removeItem("trailer_immat_2");
  localStorage.removeItem("trailer_immat_3");
  sessionStorage.removeItem("alertPlaquesD");
}
function toTruckyCityFormat(str) {
  return str
    .toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "") // retire les accents
    .replace(/[\s\-]+/g, "_"); // espaces et tirets → underscore
}
if (city && city.realName && city.country &&
    (city.realName !== lastCitySent || city.country !== lastStateSent)) {
  fetch('/api/set_location', {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ city: city.realName, state: city.country })
  }).catch(() => {});
  lastCitySent = city.realName;
  lastStateSent = city.country;
}
if (
  city && city.realName && city.country &&
  (city.realName !== lastCitySent || city.country !== lastStateSent)
) {
  fetch('/api/set_location', {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ city: city.realName, state: city.country })
  }).catch(() => {});

  lastCitySent = city.realName;
  lastStateSent = city.country;
}
const DAYS = {
  fr: ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"],
  en: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
  es: ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"],
  de: ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"]
};
const lang = LANG || "fr";
let dayLabel = "--";
if (typeof data.dayIndex !== "undefined") {
  dayLabel = DAYS[lang][data.dayIndex];
} else if (data.dayName) {
  const idx = DAYS["fr"].indexOf(data.dayName);
  if (idx !== -1) dayLabel = DAYS[lang][idx];
}
const elDay = document.getElementById("elog-day");
if (elDay) elDay.textContent = dayLabel;

// Semaine (formatée)
const weekLabel = translations[lang].elog_week + " " + (data.weekNum || "--");
const elWeek = document.getElementById("elog-week");
if (elWeek) elWeek.textContent = weekLabel;

// console.log("Statut reçu :", data.status, "| ChainType :", data.trailer_ChainType);

checkTrailerPlatesOnD(data);
autoReturnToIndex(data);
/*
// ▸ 3) Remettre les totaux à zéro lorsqu’on passe 00 h (optionnel)
if (minuteCourante < 2) {
  ["OFF","SB","D","ON"].forEach(s => {
    document.getElementById("total-"+s).textContent = "00h00";
  });
}*/
// La synchronisation est déjà faite au début de updateUI(), après résolution
// du mode HTZ/auto/désactivé. Ne pas renvoyer ici un ancien offset en cache.

if (langSel) {
  langSel.value = currentLang;
  langSel.addEventListener('change', (e) => {
    currentLang = e.target.value || 'fr';
    localStorage.setItem('lang', currentLang);

    // Retraduire toute la page
    applyI18n(document);

    // Si la modale de mise à jour est ouverte, retraduis-la aussi
    const modal = document.getElementById('update-modal');
    if (modal && modal.classList.contains('show')) applyI18n(modal);
  });
}

  

}
function getGameMinuteWithTZ(data) {
    // g_gameTimeMin = minutes depuis le point zéro du jeu (UTC base)
    let min = data.game_time || 0;
    // Si fuseau horaire activé, appliquer l’offset
    if (data.tz_active) { // ou vérifie si la case est cochée
        min += (data.usetz_offset || 0) * 60;
    }
    // Toujours ramener dans la journée 0..1439
    return ((min % 1440) + 1440) % 1440;
}




// Génère la bande des heures toutes les 3h (00h, 03h, ..., 21h, 00h)
function buildHourRow() {
  const hoursDiv = document.getElementById('elog-hours');
  if (!hoursDiv) return;
  hoursDiv.innerHTML = '';
  for(let h=0; h<=24; h+=3){
    let span = document.createElement('span');
    span.textContent = String(h%24).padStart(2,"0")+'h';
    hoursDiv.appendChild(span);
  }
}

// -------------------------------------------------Page Vehicules ----------------------------------------------
function saveTrailerPlates() {
  const manualPlate = document.getElementById("input_trailer_immat_manual")?.value.trim();
  const manualCountry = document.getElementById("input_trailer_immat_country_manual")?.value.trim();
  const v2 = document.getElementById("input_trailer_immat_2")?.value.trim();
  const v3 = document.getElementById("input_trailer_immat_3")?.value.trim();
  const body = {};
  if (document.getElementById("manualTrailer1")?.style.display !== "none") {
    body.trailer_immat_manual = manualPlate || "";
    body.trailer_immat_country_manual = manualCountry || "";
  }
  if (v2) body.trailer_immat_2 = v2;
  if (v3) body.trailer_immat_3 = v3;
  fetch('/save-plaques', {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  })
    .then(r => r.json())
    .then(data => {
      if (data.ok) {
        ["input_trailer_immat_manual", "input_trailer_immat_country_manual",
         "input_trailer_immat_2", "input_trailer_immat_3"].forEach(id => {
          const input = document.getElementById(id);
          if (input) input.dataset.dirty = '';
          sessionStorage.removeItem(`atselog.trailerDraft.${id}`);
        });
        showToast("Plaques enregistrées !");
      }
      else showToast("Erreur d’enregistrement", 2000);
    })
    .catch(() => showToast("Erreur d’enregistrement", 2000));
}

// -----------------------------------------------------------------------------
// Timeline HOS sur la page Index : 100% en fuseau HTZ (fuseau du QG / RODS)
// -----------------------------------------------------------------------------
function renderTimelineGridAndSegments(statusHistory, htzOffsetMin) {
  const svg = document.getElementById('elog-svg');
  if (!svg) return;

  const WIDTH = 1440;
  const HEIGHT = 100;
  const ROW_HEIGHT = HEIGHT / 4;
  const ROW_BY_STATUS = { OFF: 0, SB: 1, D: 2, ON: 3 };

  svg.innerHTML = '';

  // 1) Grille verticale (0 → 24h, trait plus fort toutes les 3h)
  for (let h = 0; h <= 24; h++) {
    const x = (h / 24) * WIDTH;
    const isMajor = (h % 3 === 0);
    const line = document.createElementNS(svg.namespaceURI, 'line');
    line.setAttribute('x1', x);
    line.setAttribute('y1', 0);
    line.setAttribute('x2', x);
    line.setAttribute('y2', HEIGHT);
    line.setAttribute('stroke', document.documentElement.dataset.theme === 'dark' ? '#d9e1e8' : '#AAA');
    line.setAttribute('stroke-width', isMajor ? '2' : '1');
    svg.appendChild(line);
  }

  // 2) Séparateurs horizontaux entre OFF / SB / D / ON
  for (let i = 1; i < 4; i++) {
    const y = i * ROW_HEIGHT;
    const line = document.createElementNS(svg.namespaceURI, 'line');
    line.setAttribute('x1', 0);
    line.setAttribute('y1', y);
    line.setAttribute('x2', WIDTH);
    line.setAttribute('y2', y);
    line.setAttribute('stroke', document.documentElement.dataset.theme === 'dark' ? '#d9e1e8' : '#CCC');
    line.setAttribute('stroke-width', '1');
    svg.appendChild(line);
  }

  const DAY_MIN = 1440;
  const normDayMin = (m) => ((m % DAY_MIN) + DAY_MIN) % DAY_MIN;

  // 3) Offset HTZ global (en minutes) passé par updateUI
  let offsetMin = 0;
  if (typeof htzOffsetMin === 'number' && Number.isFinite(htzOffsetMin)) {
    offsetMin = htzOffsetMin;
  }

  if (!Array.isArray(statusHistory)) return;

  // 4) Dessin des segments
  statusHistory.forEach(seg => {
    if (!seg) return;

    const status = String(seg.status || '').toUpperCase();
    const rowIdx = ROW_BY_STATUS[status];
    if (typeof rowIdx !== 'number') return;

    const y = rowIdx * ROW_HEIGHT + 2;
    const h = ROW_HEIGHT - 4;

    const drawRect = (a, b) => {
      const x1 = (a / DAY_MIN) * WIDTH;
      const x2 = (b / DAY_MIN) * WIDTH;
      if (x2 <= x1) return;
      const rect = document.createElementNS(svg.namespaceURI, 'rect');
      rect.setAttribute('x', x1);
      rect.setAttribute('y', y);
      rect.setAttribute('width', x2 - x1);
      rect.setAttribute('height', h);
      rect.setAttribute('fill', '#AECBA6');
      rect.setAttribute('rx', '2');
      rect.setAttribute('ry', '2');
      svg.appendChild(rect);
    };

    const drawDuration = (start, duration) => {
      let cursor = normDayMin(start);
      let remaining = duration;
      while (remaining > 0) {
        const chunk = Math.min(remaining, DAY_MIN - cursor);
        drawRect(cursor, cursor + chunk);
        remaining -= chunk;
        cursor = 0;
      }
    };

    // Les valeurs *_time_min sont absolues (elles peuvent valoir 215706).
    // La durée doit donc être calculée AVANT le modulo 1440. Cela distingue
    // correctement un passage de minuit d'un évènement invalide ou nul.
    if ('start_time_min' in seg || 'start_min' in seg) {
      const sKey = ('start_time_min' in seg) ? 'start_time_min' : 'start_min';
      const eKey = ('end_time_min'   in seg) ? 'end_time_min'   : 'end_min';
      const rawStart = Number(seg[sKey]);
      const rawEnd = Number(seg[eKey]);
      const duration = rawEnd - rawStart;

      // Les données du jour sont déjà coupées par le plugin à 24 h. Un
      // intervalle négatif, nul ou supérieur à une journée est corrompu :
      // on le masque au lieu de dessiner une journée entière par erreur.
      if (!Number.isFinite(rawStart) || !Number.isFinite(rawEnd) ||
          duration <= 0 || duration > DAY_MIN) return;

      drawDuration(rawStart + offsetMin, duration);
      return;
    }

    // Compatibilité avec les anciennes sauvegardes qui ne contiennent que HH:MM.
    const parseBase = (value) => {
      const [hours, minutes] = String(value || '00:00').split(':').map(Number);
      return normDayMin((hours * 60) + (minutes || 0));
    };
    const startMin = parseBase(seg.start_time || seg.start);
    const endMin = parseBase(seg.end_time || seg.end);
    const duration = (endMin - startMin + DAY_MIN) % DAY_MIN;
    if (duration > 0) drawDuration(startMin + offsetMin, duration);

  });
}

// Première peinture hors-ligne : les dernières données restent lisibles dès
// l'ouverture de la page. La requête live, si ATS tourne, les remplacera.
document.addEventListener('DOMContentLoaded', () => {
  try {
    const cached = JSON.parse(localStorage.getItem('lastValidData') || 'null');
    if (cached && typeof cached === 'object' && cached.clock) updateUI(cached);
  } catch {}
}, { once: true });



function renderTimeline(data){
  const events = Array.isArray(data?.status_events) ? data.status_events : [];
  // Si tu veux appliquer un offset local ou HTZ ici, fais-le avant l’appel suivant
  renderTimelineGridAndSegments(events);
}

//---------------------------------------------en dessous a verif ???????--------------------↓↓↓

// Timeline format HH:mm
// Prend un nombre de minutes du jeu (ex: 286948) et retourne hh:mm du jour en jeu
function displayTimelineHour(hhmm, useTimeZone, offset) {
    const min = parseHHMMtoMinutes(hhmm);
    let finalMin = min;
    if (useTimeZone) finalMin = (min + offset + 1440) % 1440;
    const h = String(Math.floor(finalMin / 60) % 24).padStart(2, "0");
    const m = String(finalMin % 60).padStart(2, "0");
    return `${h}:${m}`;
}
//------------------------------------------------------------------------------------------↑↑↑
function parseHHMMtoMinutes(str) {
    if (!str || !str.includes(":")) return 0;
    const [h, m] = str.split(":").map(Number);
    if (isNaN(h) || isNaN(m)) return 0;
    return h * 60 + m;
}
function parseHHMM(str) {
    if (!str || typeof str !== "string") return 0;
    const [h, m] = str.split(":").map(Number);
    return h * 60 + m;
}

function initELDOverride() {
  // Ne rien faire si le bouton principal n’est pas là (donc page settings)
  if (!document.getElementById('btn-OFF')) return;
  const statuses = ['OFF', 'SB', 'D', 'ON'];
  statuses.forEach(s => {
    const btn = document.getElementById(`btn-${s}`);
    if (!btn) return;
    const newBtn = btn.cloneNode(true);
    btn.parentNode.replaceChild(newBtn, btn);
  });
}

function showToast(msg, duration = 1000) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = msg;
  toast.style.display = 'block';
  clearTimeout(showToast._timeout);
  showToast._timeout = setTimeout(() => {
    toast.style.display = 'none';
  }, duration);
}

// Précharge les archives pendant qu'ATS est connecté. Ainsi LogBooks reste
// complet hors ligne même si l'utilisateur n'a jamais ouvert cette page
// pendant la session. Le cache est limité aux fichiers exposés par le plugin.
let logsOfflineCacheAt = 0;
let logsOfflineCacheInFlight = false;
async function cacheLogBooksForOffline() {
  const now = Date.now();
  if (logsOfflineCacheInFlight || now - logsOfflineCacheAt < 30000) return;
  logsOfflineCacheInFlight = true;
  try {
    const listRes = await fetch('/logs-list', {cache: 'no-cache'});
    if (!listRes.ok) return;
    const archived = await listRes.json();
    const files = [...new Set([...(Array.isArray(archived) ? archived : []), 'hos_today.json'])];
    await Promise.all(files.map(async file => {
      try { await fetch(`/${file}`, {cache: 'no-cache'}); } catch (_) {}
    }));
    localStorage.setItem('atselog.logs.list.v1', JSON.stringify(archived));
    logsOfflineCacheAt = now;
  } catch (_) {
    // ATS arrêté : le service worker et le dernier inventaire restent le repli.
  } finally {
    logsOfflineCacheInFlight = false;
  }
}

async function update() {
  try {
    const res = await fetch(`${endpoint}?t=${Date.now()}`);
    if (!res.ok) throw new Error("fetch failed");
    const data = await res.json();
    if (!data.clock) throw new Error("données invalides");

    const conn = document.getElementById('conn-icon');
    if (conn) {
      conn.src = 'textures/icon-conv.png';
      conn.alt = 'Plugin actif';
      conn.className = 'connected';
    }

    updateUI(data);
    localStorage.setItem("lastValidData", JSON.stringify(data));
    cacheLogBooksForOffline();
  } catch (e) {
    console.error("[update()] erreur de connexion :", e);
    const conn = document.getElementById('conn-icon');
    if (conn) {
      conn.src = 'textures/icon-conr.png';
      conn.alt = 'Plugin inactif ou ATS fermé';
      conn.className = 'disconnected';
    }

    const cached = localStorage.getItem("lastValidData");
    if (cached) {
      try {
        const data = JSON.parse(cached);
        updateUI(data);
      } catch (parseError) {
        console.warn("⚠️ JSON localStorage corrompu", parseError);
        localStorage.removeItem("lastValidData");
      }
    }
  } finally {
    setTimeout(update, refreshMs);
  }
}

// L'icône doit renseigner immédiatement l'état hors connexion, avant que la
// première requête réseau ne se termine (ou échoue si ATS est fermé).
function showPluginDisconnected() {
  const conn = document.getElementById('conn-icon');
  if (!conn) return;
  conn.src = 'textures/icon-conr.png';
  conn.alt = 'Plugin inactif ou ATS fermé';
  conn.className = 'disconnected';
}

// Applique une traduction dans title/data-tooltip sans toucher à l'icône (innerHTML)
function setTooltipFromI18n(el, key){
  if (!el) return;
  const txt = (typeof t === 'function') ? t(key) : String(key);
  el.setAttribute('title', txt);
  el.setAttribute('data-tooltip', txt);
}


window.addEventListener("DOMContentLoaded", () => {
	applyTranslations();
	showPluginDisconnected();
	
  const langSel = document.getElementById("lang");
  if (langSel) {
    langSel.value = LANG;
    langSel.addEventListener("change", () => {
      localStorage.setItem("lang", langSel.value);
      location.reload();
    });
  }

// au chargement des réglages
const convoyEl = document.getElementById('convoyMode');
if (convoyEl) convoyEl.checked = localStorage.getItem('convoy_mode') === '1';

const nameInput = document.getElementById('editChauffeur');
if (nameInput) {
  nameInput.value = localStorage.getItem('nomChauffeur') || '';
}
// Afficher le nom dans le header (index & settings)
const nameDisplay = document.getElementById('affichageChauffeur');
const raw = localStorage.getItem('nomChauffeur') || '';
const nom = normalizeNomChauffeur(raw);
localStorage.setItem('nomChauffeur', nom);

if (nameInput)   nameInput.value = nom;
if (nameDisplay) nameDisplay.textContent = nom;
if (nameDisplay) {
  nameDisplay.textContent = localStorage.getItem('nomChauffeur') || '';
}
  const saveBtn = document.getElementById("saveBtn");
if (saveBtn) {
  saveBtn.addEventListener("click", () => {
    if (langSel) localStorage.setItem("lang", langSel.value);
	if (nameInput) {
      const nom = normalizeNomChauffeur(nameInput.value.trim()); 
      localStorage.setItem('nomChauffeur', nom);
	  const nameDisplay = document.getElementById('affichageChauffeur');
    if (nameDisplay) nameDisplay.textContent = nom;
    }
    showToast(translations[LANG]?.saved || "Sauvegardé !");
    setTimeout(() => {
      window.location.href = "index.html";
    }, 1000);
	// dans le handler de saveBtn (tu l’as déjà)
if (convoyEl) localStorage.setItem('convoy_mode', convoyEl.checked ? '1' : '0');
  });
}
	
// ... à l'intérieur de ton window.addEventListener("DOMContentLoaded", () => { ... });

// --- URL du DERNIER déploiement webapp ---
/*
const GAS_URL = 'https://script.google.com/macros/s/AKfycbxraUXnnhHVusEgeT6DnX3gI5v21WHh643y74GAyf8WJxx3Ejt__n9UMiSvbQx_D7TM/exec';

window.GAS_URL = GAS_URL; // pratique dans la console
*/

console.log('GAS_URL utilisé =>', window.GAS_URL);

// ----- Envoi du formulaire -----
const devForm = document.getElementById('devForm');
if (devForm) {
  devForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Champs saisis
    const ville = document.getElementById('ville').value.trim();
    const etat  = document.getElementById('etat').value.trim();
    const pays  = document.getElementById('pays').value.trim();

    // Valeurs affichées (spans)
    const gpsXEl = document.getElementById('gps_x');
    const gpsZEl = document.getElementById('gps_z');

    // Fallback télémétrie
    const pos_x = gpsXEl && gpsXEl.textContent !== '--'
      ? gpsXEl.textContent.trim()
      : (window.lastGameData?.pos_x ?? '');
    const pos_z = gpsZEl && gpsZEl.textContent !== '--'
      ? gpsZEl.textContent.trim()
      : (window.lastGameData?.pos_y ?? '');

    // Hidden (vérif propre)
    const hx = document.getElementById('pos_x_field');
    const hz = document.getElementById('pos_z_field');
    if (hx) hx.value = pos_x;
    if (hz) hz.value = pos_z;

    const chauffeur = (localStorage.getItem('nomChauffeur') || '')
      .replace(/^🪪\s*/, '')
      .trim();

    try {
      // FormData pour éviter le préflight
      const fd = new FormData();
      fd.append('ville',  ville);
      fd.append('etat',   etat);
      fd.append('pays',   pays);
      fd.append('pos_x',  pos_x);
      fd.append('pos_z',  pos_z);
      fd.append('chauffeur', chauffeur);

      const btn = document.getElementById('boutondev');
      const msg = document.getElementById('formResult');
      if (btn) btn.disabled = true;
      if (msg) msg.textContent = 'Envoi...';

      await fetch(GAS_URL, { method: 'POST', body: fd, mode: 'no-cors' });

      if (msg) msg.textContent = 'Envoi effectué ✔';
      setTimeout(() => { window.location.href = 'index.html'; }, 1000);
    } catch (err) {
      console.error(err);
      const msg = document.getElementById('formResult');
      if (msg) msg.textContent = "Échec d'envoi (réseau).";
      const btn = document.getElementById('boutondev');
      if (btn) btn.disabled = false;
    }
  });
}

// ----- Lecture depuis le Sheet via JSONP (pas de CORS) ----- //
/*
function jsonp(urlWithParams) {
  return new Promise((resolve, reject) => {
    const cb = 'gascb_' + Math.random().toString(36).slice(2);
    const s = document.createElement('script');
    window[cb] = (payload) => { delete window[cb]; s.remove(); resolve(payload); };
    s.onerror = () => { delete window[cb]; s.remove(); reject(new Error('JSONP échoué')); };
    // on force list=1 + callback
    s.src = `${GAS_URL}?list=1&callback=${cb}`;
    document.body.appendChild(s);
  });
}

async function fetchSheetCities() {
  const payload = await jsonp(`${GAS_URL}?list=1`);
  // payload attendu : { ok:true, rows:[...] }
  return Array.isArray(payload?.rows) ? payload.rows : [];
}
*/

// ----- Fusion avec priorité aux données du Sheet -----
function mergeCities(...lists) {
  const map = new Map();
  for (const list of lists) {
    for (const c of list) {
      const key = [
        (c.realName || '').toLowerCase().trim(),
        (c.country  || '').toLowerCase().trim(),
        Math.round(Number(c.x) || 0),
        Math.round(Number(c.z) || 0)
      ].join('|');
      // priorité au dernier => on écrase systématiquement
      map.set(key, c);
    }
  }
  return [...map.values()];
}

// ----- Au démarrage : on charge et on fusionne -----
(async () => {
  try {
    const sheetCities = await fetchSheetCities();     // vient du Google Sheet
    const baseLocal   = (window.cities || []);        // cities-ats.js
    const baseTrucky  = (window.truckyCities || []);  // si tu as déjà un tableau Trucky

    // ordre = local, trucky, sheet ; comme on écrase, le Sheet l’emporte
    const merged = mergeCities(sheetCities, baseLocal, baseTrucky, );

    // remplace la source utilisée par l’UI
    window.cities = merged;
	window.citiesATS = merged;
	if (window.lastGameData) updateUI(window.lastGameData);


    // debug rapide pour vérifier que ça lit bien le Sheet :
    console.log('Villes du Sheet chargées :', sheetCities.length, sheetCities[0]);
    console.log('Total fusionné =', merged.length);

    // si tu as une fonction qui redessine l’UI (liste/recherche/mini-carte)
    if (typeof refreshCityUI === 'function') refreshCityUI(merged);
  } catch (err) {
    console.error('Lecture Sheet échouée :', err);
  }
  
})();

	

  const tz = document.getElementById('atsTimezone');
  if (tz) {
    tz.checked = localStorage.getItem('ats_timezone') === '1';
    tz.addEventListener('change', () => {
      localStorage.setItem('ats_timezone', tz.checked ? '1' : '0');
      // Rafraîchir direct l'affichage
      updateDisplayedTime(window.lastGameData || {});
    });
  }

  function fetchVersionAndInject() {
    fetch(`${endpoint}?t=${Date.now()}`)
      .then(r => r.json())
      .then(d => {
        document.querySelectorAll('.ui-version')
          .forEach(el => {
            el.textContent = d.version ? ` v${d.version}` : '';
          });
      })
      .catch(console.error);
  }

	const eltrailer_immat_2 = document.getElementById("input_trailer_immat_2")
	if (eltrailer_immat_2) eltrailer_immat_2.value = localStorage.getItem("trailer_immat_2") || "";

	const eltrailer_immat_3 = document.getElementById("input_trailer_immat_3")
	if (eltrailer_immat_3) eltrailer_immat_3.value = localStorage.getItem("trailer_immat_3") || "";
	
	fetchVersionAndInject();
	initELDOverride();
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js');
  
  // Une seule boucle de télémétrie. La seconde boucle lancée après le
  // chargement des villes provoquait deux rendus concurrents et des sauts de TZ.
  update();



  // 2) charge les villes en arrière-plan (priorité Sheet > Trucky > Local)
  initCitiesPriority().then(() => {
    // quand dispo, on rafraîchit UNIQUEMENT l’affichage dépendant des villes
    if (window.lastGameData) updateUI(window.lastGameData);
	});
	  // --- Vérifier s'il existe une nouvelle version sur le Sheet ---
checkVersionAgainstSheet();
checkAndroidUpdate();
});



// -- Constantes
const EMOJI_ID = "🪪";
const EMOJI_PREFIX = EMOJI_ID + " ";

// Normalise le nom: supprime tous les "🪪 " au début puis remet un seul
function normalizeNomChauffeur(raw) {
  if (!raw) return EMOJI_PREFIX;              // au pire, juste l’émoji + espace
  let s = String(raw).trim();

  // Retire tous les émojis "🪪" et espaces superflus en tête
  s = s.replace(/^(\uD83E\uDDDAs?|\ud83e\udddA)?\s*/i, ""); // robustesse
  s = s.replace(/^🪪\s*/g, "");
  // Si l’utilisateur a déjà mis l’émoji plus loin, on ne le garde pas
  s = s.replace(/🪪/g, "").trim();

  return EMOJI_PREFIX + s;
}

// Applique le préfixe et garde le curseur juste après l’émoji
function enforceEmojiPrefixOnInput(input) {
  const start = input.selectionStart;
  const hadPrefix = input.value.startsWith(EMOJI_PREFIX);
  if (!hadPrefix) {
    input.value = normalizeNomChauffeur(input.value);
  } else {
    // Empêche de casser le préfixe (si on le supprime au clavier)
    if (!input.value.startsWith(EMOJI_PREFIX)) {
      input.value = normalizeNomChauffeur(input.value);
    }
  }
  // Place le caret minimum après le préfixe
  const minPos = EMOJI_PREFIX.length;
  const newPos = Math.max(start, minPos);
  requestAnimationFrame(() => {
    input.setSelectionRange(newPos, newPos);
  });
}

// ----- Application PC -----
document.addEventListener("DOMContentLoaded", () => {
	// ----- Initialisation au chargement -----

  const btn = document.getElementById('install-app-btn');


	
  // ===== PWA install (prompt programmable) =====
  let deferredPrompt = null;

  
  const tip = document.getElementById("pwa-install-tip");
  if (!btn || !tip) return;

  // Helper
  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
  const isStandalone = window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone;
  const isSecure = window.isSecureContext || location.hostname === "localhost";

  // Cas 1: déjà installée
  if (isStandalone) {
    btn.style.display = "none";
    tip.style.display = "none";
    return;
  }

  // Cas 2: iOS → pas de prompt, on montre l’astuce
  if (isIOS) {
    btn.style.display = "none";
    tip.style.display = "";
    return;
  }

  // Cas 3: pas HTTPS / localhost → pas de prompt
  if (!isSecure) {
    btn.style.display = "none";
    tip.style.display = "";
    return;
  }

  // Cas 4: Chrome/Edge/Brave en HTTPS/localhost
  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    deferredPrompt = e;
    btn.style.display = "";
    tip.style.display = "none";
  });

  btn.addEventListener("click", async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      try { await deferredPrompt.userChoice; } catch {}
      deferredPrompt = null;
    } else {
      tip.style.display = "";
    }
  });

  window.addEventListener("appinstalled", () => {
    btn.textContent = "Application installée";
    btn.disabled = true;
    tip.style.display = "none";
  });

  // Enregistrement du service worker
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("sw.js").catch(console.error);
  }

  const input = document.getElementById("inputChauffeur");
  const affichage = document.getElementById("affichageChauffeur");

  // 1) Charger valeur existante (localStorage ou valeur actuelle de l’input)
  let saved = localStorage.getItem("nomChauffeur");
  if (!saved) saved = input.value || "";

  // 2) Normaliser + afficher dans l’input
  const normalized = normalizeNomChauffeur(saved);
  input.value = normalized;

  // 3) Optionnel: maj de l’affichage si présent
  if (affichage) affichage.innerText = normalized;

  // 4) Verrouiller le préfixe à chaque saisie
  input.addEventListener("input", () => enforceEmojiPrefixOnInput(input));

  // 5) Sécuriser aussi Backspace/Delete juste au début
  input.addEventListener("keydown", (e) => {
    const pos = input.selectionStart;
    const sel = input.selectionEnd;
    if (
      // Empêche de supprimer le préfixe
      (e.key === "Backspace" && pos <= EMOJI_PREFIX.length && pos === sel) ||
      (e.key === "Delete" && pos < EMOJI_PREFIX.length)
    ) {
      e.preventDefault();
      // repositionne le curseur juste après le préfixe
      input.setSelectionRange(EMOJI_PREFIX.length, EMOJI_PREFIX.length);
    }
  
  
  setupConvoyResetButtons();
});

// Affiche/masque les boutons selon le réglage et branche les clics
function setupConvoyResetButtons() {
  const isConvoy = localStorage.getItem('convoy_mode') === '1';
  const btnDay   = document.getElementById('resetDayBtn');
  const btnCycle = document.getElementById('resetCycleBtn');
  if (!btnDay || !btnCycle) return;      // pas sur cette page

  btnDay.hidden   = !isConvoy;
  btnCycle.hidden = !isConvoy;

  if (isConvoy) {
    btnDay.onclick = () => {
      if (confirm("Réinitialiser les heures journalières ?")) {
        if (typeof resetDailyHOS === 'function') resetDailyHOS(); // ou ta fonction existante
        showToast("Jour réinitialisé");
        if (window.lastGameData) updateUI(window.lastGameData);
      }
    };
    btnCycle.onclick = () => {
      if (confirm("Réinitialiser les heures du cycle ?")) {
        if (typeof resetCycleHOS === 'function') resetCycleHOS(); // ou ta fonction existante
        showToast("Cycle réinitialisé");
        if (window.lastGameData) updateUI(window.lastGameData);
      }
    };
  } else {
    btnDay.onclick = btnCycle.onclick = null;
  }
}

// Appel automatique sur toutes les pages (ne fait quelque chose que si les boutons existent)
document.addEventListener('DOMContentLoaded', setupConvoyResetButtons);

// --- Réinitialisations (robustes) ---
function resetDailyHOS() {
  // Si ton moteur HOS expose une API dédiée, on l’utilise :
  if (window.hos && typeof hos.resetDay === 'function') {
    hos.resetDay();
  } else {
    // Fallback générique : on repart à "maintenant"
    localStorage.setItem('hos_day_start', Date.now().toString());
    // On efface toutes les données "jour" connues
    for (const k of Object.keys(localStorage)) {
      if (/^hos_day_/i.test(k) || /^hos_today_/i.test(k)) localStorage.removeItem(k);
    }
  }
  refreshHosUI();
}

function resetCycleHOS() {
  if (window.hos && typeof hos.resetCycle === 'function') {
    hos.resetCycle();
  } else {
    localStorage.setItem('hos_cycle_start', Date.now().toString());
    for (const k of Object.keys(localStorage)) {
      if (/^hos_cycle_/i.test(k)) localStorage.removeItem(k);
    }
  }
  refreshHosUI();
}

// Rafraîchit l’affichage HOS proprement
function refreshHosUI() {
  if (typeof refreshHos === 'function') { refreshHos(); return; }
  if (typeof updateUI === 'function' && window.lastGameData) { updateUI(window.lastGameData); return; }
  // dernier recours :
  location.reload();
}

// Bouton "Détecter le QG"
    const btnHQ = document.getElementById('detectHQBtn');
    if (btnHQ) {
      btnHQ.addEventListener('click', async () => {
        try {
          const r = await fetch('/api/profile/hq', { cache: 'no-store' });
          const js = await r.json();
          if (js && js.ok && js.hq_city) {
            localStorage.setItem('atselog.hq_city', js.hq_city);
            if (typeof window.refreshHQLabel === 'function') window.refreshHQLabel();
            alert((window.t?.('hq_saved_ok')) || 'QG enregistré : ' + js.hq_city);
          } else {
            alert((window.t?.('hq_not_found')) || 'QG introuvable dans la dernière sauvegarde. Fais une sauvegarde rapide dans ATS puis réessaie.');
          }
        } catch (e) {
          console.error(e);
          alert('Erreur pendant la détection du QG.');
        }
      });
    }
});

// ----- Ta fonction d’enregistrement (mise à jour) -----
function validerChauffeur() {
  const input = document.getElementById('inputChauffeur');
  const affichage = document.getElementById('affichageChauffeur');

  let nom = input.value.trim();
  if (nom.length < 2) {
    showToast("Merci d'entrer un nom valide.");
    return;
  }

  nom = normalizeNomChauffeur(nom);

  // Met à jour l’input + un éventuel affichage
  input.value = nom;
  if (affichage) affichage.innerText = nom;

  // Persistance
  localStorage.setItem('nomChauffeur', nom);

  // Ferme le popup si présent
  const popup = document.getElementById('popupChauffeur');
  if (popup) popup.style.display = 'none';

  // Si tu as déjà une fonction d’UI :
  if (typeof afficherChauffeur === "function") {
    afficherChauffeur();
  }
  // Vérifie si le mode convoi est activé
  const isConvoy = localStorage.getItem('convoy_mode') === '1';
  const resetDayBtn = document.getElementById('resetDayBtn');
  const resetCycleBtn = document.getElementById('resetCycleBtn');

  if (isConvoy) {
    // Affiche les boutons reset
    if (resetDayBtn) resetDayBtn.hidden = false;
    if (resetCycleBtn) resetCycleBtn.hidden = false;

    // Action du bouton "Réinitialiser journée"
    if (resetDayBtn) {
      resetDayBtn.addEventListener('click', () => {
        if (confirm("Réinitialiser les heures de service de la journée ?")) {
          fetch('/api/eld/reset_day')
            .then(r => r.text())
            .then(() => showToast("Heures de service réinitialisées !"))
            .catch(() => showToast("Erreur de réinitialisation"));
        }
      });
    }

    // Action du bouton "Réinitialiser cycle"
    if (resetCycleBtn) {
      resetCycleBtn.addEventListener('click', () => {
        if (confirm("Réinitialiser le cycle de 70 h / 8 jours ?")) {
          fetch('/api/eld/reset_cycle')
            .then(r => r.text())
            .then(() => showToast("Cycle réinitialisé !"))
            .catch(() => showToast("Erreur de réinitialisation"));
        }
      });
    }
  } else {
    // Cache les boutons si mode convoi désactivé
    if (resetDayBtn) resetDayBtn.hidden = true;
    if (resetCycleBtn) resetCycleBtn.hidden = true;
  }
}



// À la toute fin de DOMContentLoaded (pour toutes pages !)
window.addEventListener("DOMContentLoaded", () => {
  // Popup nom chauffeur au premier accès
  const pop = document.getElementById('popupChauffeur');
const aff = document.getElementById('affichageChauffeur');
if (pop && aff) {
  const stored = localStorage.getItem('nomChauffeur') || '';
  const hasRealName = stored.replace(/^🪪\s*/, '').trim().length >= 2;
  if (!hasRealName) {
    pop.style.display = 'flex';
    setTimeout(() => document.getElementById('inputChauffeur').focus(), 150);
  }
}
});

function sauverChauffeur() {
  const nom = document.getElementById('editChauffeur').value.trim();
  if (nom.length < 2) { showToast("Merci d'entrer un nom valide."); return; }
  localStorage.setItem('nomChauffeur', nom);
  // showToast("Nom du conducteur mis à jour !");
}

//IP pour Application


// Outils

function formatMinutesToHM(mins) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (!h && !m) return "00h00";
  return `${String(h).padStart(2, '0')}h${String(m).padStart(2, '0')}`;
}


// === DEBUG : affichage/branchements des boutons reset en Mode Convoi ===
function setupConvoyResetButtonsDebug() {
  const TAG = "[ATS-Elog Convoy]";
 // console.groupCollapsed(`${TAG} init on ${location.pathname}`);

  // 1) Lire l'état stocké
  const convoyVal = localStorage.getItem('convoy_mode');
  const isConvoy = convoyVal === '1';
 // console.log(TAG, "localStorage.convoy_mode =", convoyVal, "→ isConvoy =", isConvoy);

  // 2) Récupérer les éléments
  const resetDayBtn   = document.getElementById('resetDayBtn');
  const resetCycleBtn = document.getElementById('resetCycleBtn');
  const driveTimer    = document.getElementById('driveTimer');
  const cycleTimer    = document.getElementById('cycleTimer');

 /* console.log(TAG, "DOM:",
    { hasResetDayBtn: !!resetDayBtn, hasResetCycleBtn: !!resetCycleBtn, hasDriveTimer: !!driveTimer, hasCycleTimer: !!cycleTimer }
  );
*/

  // Aide visuelle si le HTML n’a pas été corrigé (boutons pas trouvés)
  if (!resetDayBtn || !resetCycleBtn) {
   // console.warn(TAG, "Bouton(s) introuvable(s). Vérifie le HTML (IDs uniques, bouton dans le même <td> que le timer).");
    // On essaie de retrouver une mauvaise 2e occurrence de resetDayBtn (HTML ancien)
    const dups = Array.from(document.querySelectorAll('#resetDayBtn'));
    if (dups.length > 1) {
    //  console.warn(TAG, "⚠️ ID #resetDayBtn en double:", dups);
    }
  }

  // 3) Appliquer visibilité selon le mode
  const applyVisibility = (btn, name) => {
    if (!btn) return;
    if (isConvoy) {
      btn.hidden = false;             // retire l'attribut hidden
      btn.style.display = 'inline-block'; // force l’affichage
      btn.style.visibility = 'visible';
    //  console.log(TAG, `Bouton ${name}: rendu visible`);
    } else {
      btn.hidden = true;
      btn.style.display = '';
      btn.style.visibility = '';
    //  console.log(TAG, `Bouton ${name}: caché (mode convoi OFF)`);
    }
  };

  applyVisibility(resetDayBtn,   "resetDayBtn");
  applyVisibility(resetCycleBtn, "resetCycleBtn");

  // 4) Binder les événements (une seule fois)
  if (!window._convoyResetBound) {
    if (resetDayBtn) {
      resetDayBtn.addEventListener('click', () => {
        console.log(TAG, "Click resetDayBtn → /api/eld/reset_day");
        if (!confirm("Réinitialiser les heures de service de la journée ?")) {
          console.log(TAG, "Action annulée par l’utilisateur.");
          return;
        }
        fetch('/api/eld/reset_day')
          .then(r => r.text())
          .then(txt => {
            console.log(TAG, "Réponse /reset_day:", txt);
            if (typeof showToast === "function") showToast("Heures de service réinitialisées !");
          })
          .catch(err => {
            console.error(TAG, "Erreur /reset_day:", err);
            if (typeof showToast === "function") showToast("Erreur de réinitialisation");
          });
      });
   //   console.log(TAG, "Handler attaché → resetDayBtn");
    }

    if (resetCycleBtn) {
      resetCycleBtn.addEventListener('click', () => {
        console.log(TAG, "Click resetCycleBtn → /api/eld/reset_cycle");
        if (!confirm("Réinitialiser le cycle de 70 h / 8 jours ?")) {
          console.log(TAG, "Action annulée par l’utilisateur.");
          return;
        }
        fetch('/api/eld/reset_cycle')
          .then(r => r.text())
          .then(txt => {
            console.log(TAG, "Réponse /reset_cycle:", txt);
            if (typeof showToast === "function") showToast("Cycle réinitialisé !");
          })
          .catch(err => {
            console.error(TAG, "Erreur /reset_cycle:", err);
            if (typeof showToast === "function") showToast("Erreur de réinitialisation");
          });
      });
   //   console.log(TAG, "Handler attaché → resetCycleBtn");
    }

    window._convoyResetBound = true;
  } else {
 //   console.log(TAG, "Handlers déjà attachés (skip).");
  }

 // console.groupEnd();
}

// 5) Lancer au chargement du DOM
document.addEventListener('DOMContentLoaded', setupConvoyResetButtonsDebug);

// 6) Et relancer une fois après la 1re trame de données jeu (si updateUI existe)
(function hookAfterFirstUpdate(){
  if (typeof updateUI !== "function") return; // rien à faire
  if (window._updateUI_hooked) return;
  window._updateUI_hooked = true;

  const _oldUpdateUI = updateUI;
  window.updateUI = function(data) {
    const r = _oldUpdateUI.call(this, data);
    // ré-applique la visibilité au cas où la page a bougé/état changé entre-temps
    try { setupConvoyResetButtonsDebug(); } catch(e) { console.error("[ATS-Elog Convoy] hook error:", e); }
    return r;
  };
})();

// === About.html : Remplir + CACHER la liste des contributeurs (col. B = "Chauffeur") ===
// === About.html : Contributeurs (col. B = "Chauffeur") avec spinner et cache ===
(function contributorsAutoFillCached() {
  const target = document.getElementById('contributorsList');
  if (!target) return; // pas sur About.html

  const spinEl = document.getElementById('contributorsSpinner');
  const spin = {
    show() { if (spinEl) { spinEl.classList.remove('is-hidden'); spinEl.style.display = 'inline-block'; } },
    hide() { if (spinEl) { spinEl.classList.add('is-hidden');   spinEl.style.display = 'none'; } }
  };

  // Spinner ON dès l'arrivée sur la page
  spin.show();

  // Cache (6h). Change 6 -> 24 si tu veux 24h.
  const CACHE_KEY = 'atselog.contributors.list.v1';
  const CACHE_TS  = 'atselog.contributors.ts.v1';
  const CACHE_TTL_MS = 6 * 60 * 60 * 1000;

  const render = (list) => { target.textContent = list?.length ? list.join(', ') : '—'; };
  const sameList = (a, b) => JSON.stringify(a || []) === JSON.stringify(b || []);

  const loadCache = () => {
    try {
      const ts = parseInt(localStorage.getItem(CACHE_TS) || '0', 10);
      const raw = localStorage.getItem(CACHE_KEY);
      if (!raw) return null;
      const list = JSON.parse(raw);
      if (!Array.isArray(list)) return null;
      const expired = (Date.now() - ts) > CACHE_TTL_MS;
      return { list, expired };
    } catch { return null; }
  };

  const saveCache = (list) => {
    try {
      localStorage.setItem(CACHE_KEY, JSON.stringify(list || []));
      localStorage.setItem(CACHE_TS, String(Date.now()));
    } catch {}
  };

  const buildList = (rows) => {
    const seen = new Map(); // dédoublonnage insensible à la casse
    for (const r of rows || []) {
      let name = (r.Chauffeur ?? r.chauffeur ?? '').toString().trim();
      if (!name) continue;
      name = name.replace(/^🪪\s*/, '').replace(/\s+/g, ' ').trim();
      if (!name) continue;
      const norm = name.toLocaleLowerCase('fr-CA');
      if (!seen.has(norm)) seen.set(norm, name);
    }
    return Array.from(seen.values())
      .sort((a, b) => a.localeCompare(b, 'fr', { sensitivity: 'base' }));
  };

  // 1) Affiche le cache immédiatement si dispo (mais laisse le spinner jusqu'au réseau)
  const cached = loadCache();
  if (cached?.list?.length) render(cached.list);
  else target.textContent = '…';

  // Sécurité : si rien ne répond, on coupe le spinner au bout de 10 s
  let timeoutId = setTimeout(() => spin.hide(), 10000);

  const useRows = (rows) => {
    const list = buildList(rows);
    if (list.length) {
      if (!cached || !sameList(list, cached.list)) {
        render(list);
        saveCache(list);
      } else if (cached?.expired) {
        // Identique mais cache expiré → rafraîchir juste le timestamp
        saveCache(list);
      }
    }
    if (timeoutId) { clearTimeout(timeoutId); timeoutId = null; }
    spin.hide(); // ✅ base de données chargée → couper le spinner
  };

  // 2) Déjà en mémoire ?
  if (Array.isArray(window._sheetRawRows)) { useRows(window._sheetRawRows); return; }

  // 3) Sinon, JSONP réseau
  if (typeof jsonp === 'function' && window.GAS_URL) {
    jsonp(`${window.GAS_URL}?list=1`)
      .then(payload => {
        const rows = Array.isArray(payload?.rows) ? payload.rows : [];
        window._sheetRawRows = rows;
        useRows(rows);
      })
      .catch(() => {
        if (timeoutId) { clearTimeout(timeoutId); timeoutId = null; }
        spin.hide(); // en cas d’erreur, on coupe quand même pour ne pas tourner à vide
      });
  } else {
    if (timeoutId) { clearTimeout(timeoutId); timeoutId = null; }
    spin.hide(); // pas de jsonp dispo
  }
})();




// Hauteur visible fiable (iOS/Android/Desktop)
(function fixVh() {
  const setVh = () => {
    const vh = window.innerHeight * 0.01; // 1% de la hauteur visible
    document.documentElement.style.setProperty('--vh', `${vh}px`);
  };
  setVh();
  window.addEventListener('resize', setVh);
  window.addEventListener('orientationchange', setVh);
})();

// Optionnel : helper pour vider le cache depuis la console
window.clearContributorsCache = function () {
  localStorage.removeItem('atselog.contributors.list.v1');
  localStorage.removeItem('atselog.contributors.ts.v1');
  console.log('Contributors cache cleared.');
};


// Optionnel : helper pour vider le cache depuis la console ou un bouton
window.clearContributorsCache = function () {
  localStorage.removeItem('atselog.contributors.list.v1');
  localStorage.removeItem('atselog.contributors.ts.v1');
  console.log('Contributors cache cleared.');
};

// Spinner Recherche Vile Etat Pays
function showInlineSpinner(el){
  if (!el) return;
  el.innerHTML = '<span class="inline-spinner" aria-label="Chargement…"></span>';
}
function setInlineText(el, txt){
  if (!el) return;
  el.textContent = txt ?? '';
}
// === Enregistrement du Service Worker pour PWA ===
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js")
    .then(() => console.log("✅ Service Worker enregistré"))
    .catch(err => console.warn("❌ Erreur Service Worker :", err));
}

// vider le cache

// === Réinitialisation complète du cache + redirection vers index ===
document.addEventListener('DOMContentLoaded', () => {
  const cachedHQ = localStorage.getItem('atselog.cache.hqLabelText');
  const hqEl = document.getElementById('hqLabel');
  if (hqEl && cachedHQ) hqEl.textContent = cachedHQ;
   // 2) Mais on recalcul systématiquement le QG avec la logique actuelle
  if (typeof refreshHQLabel === 'function') {
    try {
      refreshHQLabel(); // va aussi réécrire atselog.cache.hqLabelText
    } catch (e) {
      console.error('Erreur refreshHQLabel au chargement', e);
    }
  }
  const resetBtn = document.getElementById('reset-cache-app');
  if (!resetBtn) return;

  resetBtn.addEventListener('click', async () => {
    const confirmReset = confirm("Voulez-vous vraiment vider le cache de l'application ?\n\nToutes les données locales seront effacées et vous serez redirigé vers la page d'accueil.");
    if (!confirmReset) return;

    try {
      // Effacer les caches (PWA)
      if ('caches' in window) {
        const names = await caches.keys();
        for (let name of names) await caches.delete(name);
      }

      // Effacer le stockage local et de session
      localStorage.clear();
      sessionStorage.clear();

      // Supprimer les Service Workers (pour éviter les anciens caches)
      if ('serviceWorker' in navigator) {
        const regs = await navigator.serviceWorker.getRegistrations();
        for (let reg of regs) await reg.unregister();
      }

      // Message rapide avant redirection
      alert("Cache vidé avec succès.\nRedirection vers la page principale...");
      window.location.href = "index.html"; // 🔁 redirection vers la page d'accueil

    } catch (err) {
      console.error("Erreur lors du reset du cache :", err);
      alert("Une erreur est survenue lors de la réinitialisation du cache.");
    }
	
  });
  // Detection QG demarrage
  try { initCitiesPriority(); } catch {}

  // On ne force plus la détection auto du QG depuis la position.
  // Si le QG n'est pas trouvé dans save_game / API, on laisse
  // "QG et fuseau horaire non défini" tant que le chauffeur
  // n'a pas cliqué sur le bouton "Détecter mon QG".
  if (window.refreshHQLabel) window.refreshHQLabel();
});

// Rafraîchit le label QG + met à jour le fuseau HQ (atselog.tz)


// Alerte Plaque Immat Vierge Trailer 2-3
// Alerte plaques remorque quand on passe en D (fatigue désactivée)
// ====== ALERTE SONORE / VIBRATION – plus fort + répétitif ======
let _rwAudioCtx = null;
function playWarnBeepLoud() {
  try {
    _rwAudioCtx = _rwAudioCtx || new (window.AudioContext || window.webkitAudioContext)();
    const ctx = _rwAudioCtx;

    // Envelope commune
    const mkBeep = (freq, startTime) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = "square";                 // plus perçant qu’un sine
      o.frequency.setValueAtTime(freq, startTime);
      g.gain.setValueAtTime(0.0001, startTime);
      g.gain.exponentialRampToValueAtTime(0.5, startTime + 0.02);  // attaque rapide
      g.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.25);
      o.connect(g); g.connect(ctx.destination);
      o.start(startTime); o.stop(startTime + 0.26);
    };

    const t0 = ctx.currentTime;
    // Petit motif triton (2 kHz -> 3 kHz -> 2.4 kHz), très audible dans un moteur
    mkBeep(2000, t0 + 0.00);
    mkBeep(3000, t0 + 0.18);
    mkBeep(2400, t0 + 0.36);
  } catch (e) {
    // silencieux si bloqué par l’OS/navigateur
  }
}

// Répétition jusqu’à acquittement
let _rwAlertTimer = null;
function startWarnLoop() {
  if (_rwAlertTimer) return;
  const doAlert = () => {
    playWarnBeepLoud();
    if (navigator.vibrate) {
      // motif de vibration (fonctionne même en silencieux si vibrations activées par l’utilisateur)
      navigator.vibrate([300, 150, 300]);
    }
  };
  doAlert();                              // lance tout de suite
  _rwAlertTimer = setInterval(doAlert, 3000); // répète toutes les 3 s
}
function stopWarnLoop() {
  if (_rwAlertTimer) { clearInterval(_rwAlertTimer); _rwAlertTimer = null; }
}

function setSharedTrailerWarning(action) {
  fetch(`/api/ui/trailer-warning/${action}`, { method: 'POST' }).catch(() => {});
}

// ====== OVERLAY TRIANGLE (identique à avant, avec latch) ======
function ensurePlatesWarningNode() {
  let node = document.getElementById('plates-warning');
  if (node) return node;

  node = document.createElement('div');
  node.id = 'plates-warning';
  node.className = 'road-warning';
  node.innerHTML = `
    <div class="rw-card" id="rw-card">
      <svg class="rw-tri" viewBox="0 0 100 90" aria-hidden="true">
        <path d="M50 5 L95 85 H5 Z" fill="#fff" stroke="#e53935" stroke-width="6"/>
        <rect x="47" y="32" width="6" height="28" rx="3" fill="#e53935"/>
        <circle cx="50" cy="70" r="4" fill="#e53935"/>
      </svg>
      <div class="rw-title">Risque d’infraction ELD</div>
      <div class="rw-text" id="rw-message">
        Cette remorque doit avoir une immatriculation avant de poursuivre.
      </div>
      <button type="button" class="rw-btn">Saisir l’immatriculation</button>
    </div>
  `;
  document.body.appendChild(node);

  // Clic = acquittement partagé + stop répétition + redirection
  const openVehicles = () => {
    sessionStorage.removeItem('warnedMissingPlatesLatched');
    setSharedTrailerWarning('ack');
    hidePlatesWarning();
    stopWarnLoop();
    window.location.href = 'vehicules.html';
  };
  node.querySelector('#rw-card').addEventListener('click', openVehicles);
  node.querySelector('.rw-btn').addEventListener('click', event => {
    event.stopPropagation();
    openVehicles();
  });

  return node;
}

function showPlatesWarning(message) {
  const node = ensurePlatesWarningNode();
  const text = node.querySelector('#rw-message');
  if (text && message) text.textContent = message;
  node.style.display = 'flex';
  startWarnLoop();                // ▶️ lance répétition
}
function hidePlatesWarning() {
  const node = ensurePlatesWarningNode();
  node.style.display = 'none';
  stopWarnLoop();                 // ⏹️ stop si jamais on masque
}

// ====== Contrôle avec LATCH (ne disparaît plus tout seul) ======
function checkTrailerPlatesOnD(data) {
  try {
    const isDrivingMotion = data.driving_motion === true;
    const trailerConnected = data.trailer_connected === true;
    const nativePlateMissing = trailerConnected &&
      data.trailer_has_native_plate === false &&
      !(data.trailer_immat_manual || '').trim();

    const chain = String(data.trailer_ChainType || '').toLowerCase();
    const multiTrailers = chain.includes('double') || chain.includes('bi-train')
                       || chain.includes('triple') || chain.includes('road');

    const t2 = (data.trailer_immat_2 || '').trim();
    const t3 = (data.trailer_immat_3 || '').trim();
    const need2 = (chain.includes('double') || chain.includes('bi-train')) && !t2;
    const need3 = (chain.includes('triple') || chain.includes('road'))     && !t3;
    const secondaryPlateMissing = multiTrailers && (need2 || need3);
    const missing = nativePlateMissing || secondaryPlateMissing;

    const sharedActive = data.trailer_warning_active === true;
    const sharedAcknowledged = data.trailer_warning_acknowledged === true;

    // Même seuil que le statut D (>5 mph), ce qui évite l'alerte pendant les
    // manœuvres lentes d'attelage. L'état actif est servi par le plugin pour
    // synchroniser l'alerte et son acquittement entre PC et mobile.
    if (missing && isDrivingMotion && !sharedAcknowledged && !sharedActive) {
      setSharedTrailerWarning('activate');
    }
    if (missing && (sharedActive || (isDrivingMotion && !sharedAcknowledged))) {
      sessionStorage.setItem('warnedMissingPlatesLatched', '1');
      const message = nativePlateMissing
        ? 'Cette remorque ne transmet aucune plaque à ATS Elog. Renseigne plaque et État/province : sans cela, le LogBook contiendra des données incomplètes et une infraction ELD pourra être enregistrée.'
        : 'Les plaques des remorques supplémentaires sont requises pour ce convoi. Renseigne-les avant de poursuivre afin d’éviter une infraction ELD dans le LogBook.';
      showPlatesWarning(message);
    } else if (!missing) {
      sessionStorage.removeItem('warnedMissingPlatesLatched');
      setSharedTrailerWarning('reset');
      hidePlatesWarning();
    } else {
      // Après acquittement, l'alerte est réarmée seulement lorsque le camion
      // est repassé sous le seuil de conduite, puis redémarre vraiment.
      if (!isDrivingMotion && sharedAcknowledged) setSharedTrailerWarning('reset');
      hidePlatesWarning();
    }
  } catch (e) {
    console.error('checkTrailerPlatesOnD error:', e);
  }
}

// === Retour automatique vers la page index quand D actif ======================
function autoReturnToIndex(data) {
  try {
    // Statut de conduite actif (D = 2)
    const isDriving = Number(data.status) === 2;
    // Mode manuel uniquement (fatigue OFF = Auto=0)
    const fatigueOff = Number(data.Auto) === 0;

    if (isDriving && fatigueOff) {
      // URL actuelle
      const current = window.location.pathname.toLowerCase();

      // Si on n’est PAS déjà sur index, on redirige
      if (!current.endsWith("index.html") && !current.endsWith("/")) {
        console.log("🚚 Statut D actif → retour automatique sur index.html");
        window.location.href = "index.html";
      }
    }
  } catch (e) {
    console.error("autoReturnToIndex error:", e);
  }
}

// ==== ÉTAT HOS — Step 1.1 (fix couleur + bips) ==============================
// - Rouge dès <= 02:00 (spécificité CSS forte)
// - 2 bips (une fois) au passage sous 02:00
// - 3 bips (une fois) au passage sous 01:00
// - Boucle de bips (toutes 20s) < 00:00 (violation)
// - Silence si OFF ou SB (pas de bip dans ces statuts)

(function HOS_Alerts_Step11(){
  // === CSS à forte spécificité (couleur rouge garantie) ===
  (function injectHosAlertStyles() {
    if (document.getElementById('hos-alert-styles')) return;
    const style = document.createElement('style');
    style.id = 'hos-alert-styles';
    style.textContent = `
      #primary-timer.timer-warning,
      #primaryTimer.timer-warning { color:#C62828 !important; font-weight:700 !important; }
      #primary-timer.timer-violation,
      #primaryTimer.timer-violation { color:#C62828 !important; font-weight:800 !important; text-shadow:0 0 0.6px #C62828; }
    `;
    document.head.appendChild(style);
  })();

  // === Helpers DOM / parse ===
  function $(s){ return document.querySelector(s); }
  function getPrimaryEl(){ return $('#primary-timer') || $('#primaryTimer') || null; }

  // Parse "HH:MM" (éventuellement préfixé par - ou −) -> secondes (peut être négatif)
  function parseHHMMToSeconds(txt){
    if (!txt) return NaN;
    const cleaned = String(txt).trim().replace(/[^\d:\-−]/g,'');
    const isNeg = cleaned.startsWith('-') || cleaned.startsWith('−');
    const core = cleaned.replace(/^[-−]/,'');
    const [hS,mS] = core.split(':');
    const h = parseInt(hS,10), m = parseInt(mS,10);
    if (Number.isNaN(h) || Number.isNaN(m)) return NaN;
    const s = h*3600 + m*60;
    return isNeg ? -s : s;
  }

  // Statut courant via les boutons (fallbacks possibles plus tard si besoin)
  function getCurrentStatus(){
    const off = $('#btn-OFF')?.classList.contains('active');
    const sb  = $('#btn-SB') ?.classList.contains('active');
    const d   = $('#btn-D')  ?.classList.contains('active');
    const on  = $('#btn-ON') ?.classList.contains('active');
    if (off) return 'OFF';
    if (sb)  return 'SB';
    if (d)   return 'DRIVING';
    if (on)  return 'ON';
    return 'UNKNOWN';
  }
  function isDrivingOrOn(){ const s = getCurrentStatus(); return s === 'DRIVING' || s === 'ON'; }

// === Moteur audio (bips nets, non “batterie faible”) ===
const audio = {
  ctx: null,
  ensure() {
    try { this.ctx ||= new (window.AudioContext || window.webkitAudioContext)(); }
    catch { /* navigateur peut bloquer → on reste silencieux */ }
    return this.ctx;
  },
  // Bip court, clair, “net”
  bip({ freq = 1350, dur = 110, gain = 0.10, type = 'square' } = {}) {
    const ctx = this.ensure(); if (!ctx) return;
    const osc = ctx.createOscillator();
    const g   = ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    g.gain.value = gain;
    osc.connect(g); g.connect(ctx.destination);
    const t0 = ctx.currentTime;

    // petite enveloppe pour éviter les clics
    g.gain.setValueAtTime(gain, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur/1000);

    osc.start(t0);
    osc.stop(t0 + dur/1000 + 0.005);
  },
  // Enchaînement “n bips” (170 ms de gap). Muet si OFF/SB.
  burst(n, gapMs = 170) {
    if (!isDrivingOrOn()) return;
    let i = 0;
    const tick = () => {
      if (!isDrivingOrOn()) return;
      this.bip();                      // bip net
      if (++i < n) setTimeout(tick, gapMs);
    };
    tick();
  },
  alert2h() { this.burst(2, 170); },   // “bip bip”
  alert1h() { this.burst(3, 170); },   // “bip bip bip”
  violationTick() { this.burst(3, 160); } // utilisé par la boucle < 00:00
};


  // === État interne des seuils ===
  const S2H = 2*3600, S1H = 1*3600;   // secondes
  const RESET_BAND = 7800;            // > 2h10 => on réarme les seuils
  let lastSec = null;
  let fired2h = false;
  let fired1h = false;
  let violationLoop = null;

	function applyVisual(el, secs){
  if (!el) return;
	  // Ne JAMAIS toucher au primary si déjà en overrun
	  if (el.id === 'primary-timer' && el.dataset.isOverrun === '1') return;

	  const warn = (secs <= S2H && secs > 0); // ≤ 2h et > 0 → rouge fixe
	  const viol = (secs <= 0);               // ≤ 00:00 → rouge (géré aussi par overrun)

	  el.classList.toggle('timer-warning',   warn);
	  el.classList.toggle('timer-violation', viol);
	  el.classList.remove('hos-pulse');      // on bannit le pulse avant 00:00
	}


  function startViolationLoop(){
    stopViolationLoop();
    violationLoop = setInterval(()=>{
      if (!isDrivingOrOn()) return;   // pas de bip en OFF/SB
      audio.violationTick();         // 3 bips rapides toutes les 20s
    }, 20000);
  }
  function stopViolationLoop(){
    if (violationLoop) { clearInterval(violationLoop); violationLoop = null; }
  }

  // === Boucle d’observation (1 Hz) ===
  const el = getPrimaryEl();
  if (!el){
    console.warn('[HOS] #primary-timer introuvable → Step 1.1 inactif');
    return;
  }

  setInterval(()=>{
    const txt = (el.textContent||'').trim();
    const secs = parseHHMMToSeconds(txt);
    if (!Number.isFinite(secs)) return;

    applyVisual(el, secs);

    if (lastSec != null){
      // Passage sous 02:00 → 2 bips une seule fois
      if (!fired2h && lastSec > S2H && secs <= S2H) {
        if (isDrivingOrOn()) audio.alert2h();
        fired2h = true;
      }
      // Passage sous 01:00 → 3 bips une seule fois
      if (!fired1h && lastSec > S1H && secs <= S1H) {
        if (isDrivingOrOn()) audio.alert1h();
        fired1h = true;
      }
      // Début violation (<= 00:00) → boucle régulière
      if (lastSec > 0 && secs <= 0) {
        startViolationLoop();
      }
      // Si on remonte au-dessus de 02:10 (reset naturel) → réarmement
      if (secs > RESET_BAND) {
        fired2h = false; fired1h = false;
      }
      // Si on repasse clairement > 00:01 → on stoppe la boucle violation
      if (secs > 60 && violationLoop) {
        stopViolationLoop();
      }
    }
    lastSec = secs;
  }, 1000);
})();

// ==== ÉTAT HOS — Step 2 : négatif continu + propagation ====================
// ==== HOS_OVERRUN_FINAL — affichage négatif après 00:00, sans conflit UI ====
(function () {
  function $(s){ return document.querySelector(s); }
  function getPrimaryEl(){ return $('#primary-timer') || $('#primaryTimer') || null; }

  // Parse "HH:MM" (éventuellement avec un signe) -> secondes (peut être négatif)
  function parseHHMMToSeconds(txt){
    if (!txt) return NaN;
    const cleaned = String(txt).trim().replace(/[^\d:\-−]/g,'');
    const neg = cleaned.startsWith('-') || cleaned.startsWith('−');
    const core = cleaned.replace(/^[-−]/,'');
    const [hS,mS] = core.split(':');
    const h = parseInt(hS,10), m = parseInt(mS,10);
    if (Number.isNaN(h) || Number.isNaN(m)) return NaN;
    const s = h*3600 + m*60;
    return neg ? -s : s;
  }
  function toHHMM(sec){
    sec = Math.max(0, sec|0);
    const h = String(Math.floor(sec/3600)).padStart(2,'0');
    const m = String(Math.floor((sec%3600)/60)).padStart(2,'0');
    return `${h}:${m}`;
  }
  function getCurrentStatus(){
    const off = $('#btn-OFF')?.classList.contains('active');
    const sb  = $('#btn-SB') ?.classList.contains('active');
    const d   = $('#btn-D')  ?.classList.contains('active');
    const on  = $('#btn-ON') ?.classList.contains('active');
    if (off) return 'OFF';
    if (sb)  return 'SB';
    if (d)   return 'DRIVING';
    if (on)  return 'ON';
    return 'UNKNOWN';
  }

  const primaryEl = getPrimaryEl();
  if (!primaryEl) return;

  let overrun = { active:false, startGameMin:0 };

  setInterval(() => {
    const status = getCurrentStatus();

    // OFF/SB : on fige le compteur, mais on GARDE le visuel négatif
	if (status === 'OFF' || status === 'SB') {
	  overrun.active = true;                 // on laisse actif pour conserver l'affichage
	  // ⚠️ ne pas retirer les classes, ne pas remettre isOverrun à 0
	  return;
	}


    // source "propre" du plugin
    const raw = (primaryEl.dataset.rawTimer || primaryEl.textContent || '').trim();
    const sec = parseHHMMToSeconds(raw);

    // Tant que > 0 : JAMAIS on ne modifie le texte (l’UI reste maître)
    if (Number.isFinite(sec) && sec > 0) {
      overrun.active = false;
      return;
    }

    // À partir de 00:00 en D/ON : on affiche le négatif basé sur l’heure de jeu
    if ((status === 'DRIVING' || status === 'ON')) {
      // À chaque tick, on récupère la minute du jour actuelle
	const gameMin = window._lastGameMin | 0;
      if (!overrun.active) {
        overrun.active = true;
        overrun.startMin = window._lastGameMin | 0; // minute de départ dans la journée (0..1439)
		primaryEl.dataset.isOverrun = "1";
      }
	  
	
	
	
	// Écart en minutes en gérant le passage de minuit
	let elapsedMin = gameMin - overrun.startMin;
	if (elapsedMin < 0) elapsedMin += 1440;

// ==== HOS_OVERRUN_PERSIST — conserve/restaure le négatif au refresh =====
(function(){
  const elP = document.getElementById('primary-timer');
  const elD = document.getElementById('driveTimer');
  const elW = document.getElementById('workdayTimer');
  if (!elP) return;

  const LSKEY = 'atselog.overrun'; // { day, startMin }
  let tick = null;

  // Utilitaire: HH:MM pour secondes (négatives possibles)
  function fmtHMM(totalSec){
    const neg = totalSec < 0;
    let s = Math.abs(totalSec)|0;
    const h = Math.floor(s/3600);
    const m = Math.floor((s%3600)/60);
    const txt = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;
    return neg ? `-${txt}` : txt;
  }

  function saveOverrun(startMin) {
    const day = new Date().toDateString(); // journée réelle affichée
    localStorage.setItem(LSKEY, JSON.stringify({ day, startMin }));
    elP.dataset.isOverrun = '1';
  }
  function clearOverrun() {
    localStorage.removeItem(LSKEY);
    elP.dataset.isOverrun = '';
    // Restaure le texte reçu
    if (elP.dataset.rawTimer) elP.textContent = elP.dataset.rawTimer;
    if (elD?.dataset.rawTimer) elD.textContent = elD.dataset.rawTimer;
    if (elW?.dataset.rawTimer) elW.textContent = elW.dataset.rawTimer;
    elP.classList.remove('timer-violation','hos-pulse');
    elD?.classList.remove('timer-violation');
    elW?.classList.remove('timer-violation');
    if (tick) { clearInterval(tick); tick = null; }
  }

  // Restaure si besoin à l'ouverture
  try {
    const raw = localStorage.getItem(LSKEY);
    if (raw) {
      const { day, startMin } = JSON.parse(raw);
      if (day === new Date().toDateString()) {
        startOverrun(startMin|0, /*resume*/true);
      } else {
        localStorage.removeItem(LSKEY);
      }
    }
  } catch {}

  function startOverrun(startMin, resume=false){
    // Marque visuelle immédiate
    elP.classList.add('timer-violation','hos-pulse');
    elP.dataset.isOverrun = '1';
    if (!resume) saveOverrun(startMin);

    if (tick) clearInterval(tick);
    tick = setInterval(() => {
      const gd = window.lastGameData || {};
      // minute en jeu actuelle normalisée 0..1439
      const nowMin = ((gd.game_time|0) % 1440 + 1440) % 1440;
      // minutes écoulées depuis l’entrée en négatif (gère le wrap minuit)
      const diffMin = (nowMin - startMin + 1440) % 1440;
      const negSec = -diffMin * 60;

      // PRIMARY: toujours en négatif
      elP.textContent = fmtHMM(negSec);
      elP.dataset.isOverrun = '1';

      // Choix du timer actif selon statut courant (DRIVING vs ON)
      const status = (gd.statusText || '').toUpperCase() || (window.getCurrentStatus?.() || '');
      if (status === 'DRIVING' && elD) {
        elD.textContent = fmtHMM(negSec);
        elD.classList.add('timer-violation');
      } else if (status === 'ON' && elW) {
        elW.textContent = fmtHMM(negSec);
        elW.classList.add('timer-violation');
      }

      // Silence si OFF/SB (tu le fais déjà côté bips), ici on ne touche rien.

      // TODO (quand prêt) : détecter 10h de OFF/SB → clearOverrun()
      // if (gd.rest10hDone === true) clearOverrun();
    }, 1000);
  }

  // Détection du passage sous 00:00 : à appeler quand tu détectes la bascule.
  // Exemple: juste après avoir parsé data.*rem → si <= "00:00", on "latch"
  window.hosEnterOverrunIfNeeded = function(currentPrimaryText){
    // Appelle cette fonction là où tu sais que primary vient d’atteindre 00:00.
    if (elP.dataset.isOverrun === '1') return;
    // Utilise window._lastGameMin mis à jour par updateUI
    const startMin = (window._lastGameMin|0);
    startOverrun(startMin);
	
  };



})();



    
    }
  });
})();
