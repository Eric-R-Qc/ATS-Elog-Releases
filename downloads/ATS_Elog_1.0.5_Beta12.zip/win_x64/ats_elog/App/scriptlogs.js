// Logs.html est volontairement autonome : appliquer aussi le thème ici.
(function applyLogBooksTheme() {
  document.documentElement.dataset.theme =
    localStorage.getItem('atselog.theme') === 'dark' ? 'dark' : 'light';
  window.addEventListener('storage', event => {
    if (event.key === 'atselog.theme') {
      document.documentElement.dataset.theme = event.newValue === 'dark' ? 'dark' : 'light';
    }
  });
})();

 //---------------------------↓↓↓↓  TRADUCITON  ↓↓↓↓-------------------------------------

const translations = {
  fr: {
    hos: "HOS",
    home: "Accueil",
    settings: "Réglages",
    logs: "LogBooks",
    about: "À propos",
	titre_about: "ATS Elog — A propos", 
    rest_in: "Repos",
    drive_rem: "Conduite restante",
    rest_Rem: "Service restant",
    cycle_rem: "Cycle 70h/8 jours",
    language: "Langue",
    ats_timezone: "Fuseau Horaire ATS",
    endpoint: "Endpoint données",
    save: "Enregistrer",
    saved: "Sauvegardé !",
    editChauffeur: "Nom du Conducteur",
	// ↓↓ mise a jours a faire dans les autres langues ↓↓
	vehicules_btn: "🗂️ Vehicules",		
	elog_day: "Jour",
	elog_week: "Semaine",
	villeActuelle: "Ville",
	elEtat: "Etats",
	immat_non_def: "⚠️ Merci de renseigner les plaques des remorques secondaires dans la page VEHICULES pour respecter la réglementation de ce convoi !", //plaque supp a informer
	trailer: "Remorque",
	trailer1: "Trailer 1",
	trailer2: "Trailer 2",
	trailer3: "Trailer 3",
	plate_placeholder: "Mettre plaque d’immatriculation",
	saveTrailerPlates: "Enregistrer plaques secondaires",
	vehicules: "Véhicules",
	copyright: "©2025 ATS Elog développé par Eric R",
	version: "",
	overlay_move: "Deplacer l'Overlay",
	pdf: "🖨️",
	dev: "Ajouter une ville",
	
},
  en: {
    hos: "HOS",
    home: "Home",
    settings: "Settings",
    logs: "LogBooks",
    about: "About",
	titre_about: "ATS Elog — About",
    rest_in: "Rest",
    drive_rem: "Drive remaining",
    rest_Rem: "Service remaining",
    cycle_rem: "70h/8 days cycle",
    language: "Language",
    ats_timezone: "ATS Timezone",
    endpoint: "Data endpoint",
    save: "Save",
    saved: "Saved!",
    editChauffeur: "Driver name",
	vehicules_btn: "🗂️ Vehcicle",
	elog_day: "Day",
	elog_week: "Week",
	villeActuelle: "City",
	elEtat: "State",
	immat_non_def: "⚠️ Please fill in the secondary trailer license plates on the VEHICLES page to comply with regulations for this convoy!",	//plaque supp a informer
	trailer: "Trailer",
	trailer1: "Trailer 1",
	trailer2: "Trailer 2",
	trailer3: "Trailer 3",
	plate_placeholder: "Enter license plate",
	saveTrailerPlates: "Save secondary plates",
	vehicules: "Vehicles",
    copyright: "©2025 ATS Elog developed by Eric R",
    version: "",
	overlay_move: "Move the overlay",
	pdf: "🖨️",
	dev: "Add a city",
},
  es: {
    hos: "HOS",                             // HOS (Horas de Servicio) utilisé partout en Espagne/Amérique Latine
    home: "Inicio",
    settings: "Configuración",
    logs: "Registros",
    about: "Acerca de",
	titre_about: "ATS Elog — Acerca de",
    rest_in: "Descanso",
    drive_rem: "Conducción restante",
    rest_Rem: "Servicio restante",
    cycle_rem: "Ciclo de 70h/8 días",
    language: "Idioma",
    ats_timezone: "Zona horaria ATS",
    endpoint: "Endpoint de datos",
    save: "Guardar",
    saved: "¡Guardado!",
    editChauffeur: "Nombre del conductor",
	vehicules_btn: "🗂️ Vehículos",
	elog_day: "Día",
	elog_week: "Semana",
	villeActuelle: "Ciudad",
	elEtat: "Estado",
	immat_non_def: "⚠️ ¡Por favor, rellene las matrículas de los remolques secundarios en la página VEHICULOS para cumplir con la normativa de este convoy!",	//plaque supp a informer
    trailer: "Remolque",
	trailer1: "Remolque 1",
	trailer2: "Remolque 2",
	trailer3: "Remolque 3",
	plate_placeholder: "Introducir matrícula",
	saveTrailerPlates: "Guardar placas secundarias",
	vehicules: "Vehículos",
	copyright: "©2025 ATS Elog desarrollado por Eric R",
    version: "",
	overlay_move: "Mover la superposición",
	pdf: "🖨️",
	dev: "Agregar ciudad",
},
  de: {
    hos: "LZV",                        // HOS = Lenk- und Ruhezeiten (abrégé LZV)
    home: "Startseite",
    settings: "Einstellungen",
    logs: "Protokolle",
    about: "Über",
	titre_about: "ATS Elog — Über",
    rest_in: "Pause",                   // "Repos" (pause, repos, etc.)
    drive_rem: "Restfahrzeit",          // "Conduite restante"
    rest_Rem: "Restdienstzeit",         // "Service restant"
    cycle_rem: "70-Stunden-Zyklus / 8 Tage",
    language: "Sprache",
    ats_timezone: "ATS-Zeitzone",
    endpoint: "Daten-Endpunkt",
    save: "Speichern",                  // "Enregistrer"
    saved: "Gespeichert!",              // "Sauvegardé !"
    editChauffeur: "Fahrername",        // "Nom du Conducteur"
	vehicules_btn: "🗂️ Fahrzeuge",
	elog_day: "Tag",
	elog_week: "Woche",
	villeActuelle: "Stadt",
	elEtat: "Bundesland",
	immat_non_def: "⚠️ Bitte geben Sie die Kennzeichen der zusätzlichen Anhänger auf der FAHRZEUGE-Seite ein, um die Vorschriften für diesen Konvoi einzuhalten!", //plaque supp a informer
    trailer: "Anhänger",
	trailer1: "Anhänger 1",
	trailer2: "Anhänger 2",
	trailer3: "Anhänger 3",
	plate_placeholder: "Kennzeichen eingeben",
	saveTrailerPlates: "Sekundäre Kennzeichen speichern",
	vehicules: "Fahrzeuge",
	copyright: "©2025 ATS Elog entwickelt von Eric R",
    version: "",
	overlay_move: "Overlay verschieben",
	pdf: "🖨️",
	dev: "Stadt hinzufügen",
}
};

const langSel = document.getElementById("lang");
const LANG = localStorage.getItem('lang') || 'fr';


function applyTranslations() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n;
    const txt = translations[LANG]?.[key];
    if (txt != null) el.textContent = txt;
  });
 };

// Vérification de mise à jour autonome : Logs.html ne charge volontairement
// pas script.js, mais doit afficher la même alerte de plugin que l'accueil.
const LOGBOOKS_UPDATE_MANIFEST = 'https://raw.githubusercontent.com/Eric-R-Qc/ATS-Elog-Releases/main/release-manifest.json';
const LOGBOOKS_UPDATE_TEXT = {
  fr: { title: 'Nouvelle version disponible', current: 'Version installée', latest: 'Version disponible', official: 'Source officielle : GitHub Eric-R-Qc/ATS-Elog-Releases', instructions: 'Mise à jour du plugin disponible. Sur le PC où ATS est installé, ouvre http://localhost:8080/index.html : le bouton Télécharger ouvrira le ZIP officiel GitHub.', ok: 'OK', banner: '⚠ Mise à jour du plugin disponible — Voir les instructions' },
  en: { title: 'New version available', current: 'Installed version', latest: 'Available version', official: 'Official source: GitHub Eric-R-Qc/ATS-Elog-Releases', instructions: 'A plugin update is available. On the PC where ATS is installed, open http://localhost:8080/index.html: the Download button will open the official GitHub ZIP.', ok: 'OK', banner: '⚠ Plugin update available — View instructions' },
  es: { title: 'Nueva versión disponible', current: 'Versión instalada', latest: 'Versión disponible', official: 'Fuente oficial: GitHub Eric-R-Qc/ATS-Elog-Releases', instructions: 'Hay una actualización del plugin disponible. En el PC donde está instalado ATS, abre http://localhost:8080/index.html: el botón Descargar abrirá el ZIP oficial de GitHub.', ok: 'Aceptar', banner: '⚠ Actualización del plugin disponible — Ver instrucciones' },
  de: { title: 'Neue Version verfügbar', current: 'Installierte Version', latest: 'Verfügbare Version', official: 'Offizielle Quelle: GitHub Eric-R-Qc/ATS-Elog-Releases', instructions: 'Ein Plugin-Update ist verfügbar. Öffne auf dem PC mit ATS http://localhost:8080/index.html: Die Schaltfläche Herunterladen öffnet die offizielle GitHub-ZIP-Datei.', ok: 'OK', banner: '⚠ Plugin-Update verfügbar — Anleitung anzeigen' }
};

function logbooksUpdateText() { return LOGBOOKS_UPDATE_TEXT[LANG] || LOGBOOKS_UPDATE_TEXT.fr; }
function normalizeLogbooksVersion(value) { return String(value || '').toLowerCase().replace(/^v/, '').replace(/[ _-]+/g, '.').replace(/[^0-9a-z.]/g, ''); }
function compareLogbooksVersions(left, right) {
  const parse = value => ({ numbers: (String(value).match(/\d+/g) || []).map(Number), prerelease: /(alpha|beta|rc|dev|test)/.test(String(value)) });
  const a = parse(left), b = parse(right), length = Math.max(a.numbers.length, b.numbers.length);
  for (let index = 0; index < length; index += 1) { const diff = (a.numbers[index] || 0) - (b.numbers[index] || 0); if (diff) return diff; }
  return a.prerelease === b.prerelease ? 0 : (a.prerelease ? -1 : 1);
}

function showLogbooksUpdateBanner(currentVer, latestVer) {
  let banner = document.getElementById('plugin-update-banner');
  if (!banner) {
    banner = document.createElement('div');
    banner.id = 'plugin-update-banner';
    banner.className = 'plugin-update-banner';
    document.body.appendChild(banner);
  }
  banner.innerHTML = `<button type="button" class="plugin-update-banner-button">${logbooksUpdateText().banner}</button>`;
  banner.onclick = () => showLogbooksUpdateModal(currentVer, latestVer);
  banner.classList.add('show');
}

function showLogbooksUpdateModal(currentVer, latestVer) {
  const copy = logbooksUpdateText();
  let modal = document.getElementById('update-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'update-modal';
    modal.className = 'update-modal';
    document.body.appendChild(modal);
  }
  modal.innerHTML = `<div class="update-card"><h3>${copy.title}</h3><div class="update-versions"><p><span>${copy.current}</span><strong>${currentVer || '—'}</strong></p><p><span>${copy.latest}</span><strong>${latestVer || '—'}</strong></p></div><p class="caption">${copy.official}</p><p class="caption">${copy.instructions}</p><div class="update-actions"><button class="btn btn-primary" type="button">${copy.ok}</button></div></div>`;
  modal.querySelector('button').onclick = () => {
    localStorage.setItem('atselog.pluginUpdateAcknowledged', latestVer);
    modal.classList.remove('show');
    showLogbooksUpdateBanner(currentVer, latestVer);
  };
  modal.classList.add('show');
}

async function checkLogbooksPluginUpdate() {
  try {
    const currentResponse = await fetch('/data91', { cache: 'no-store' });
    if (!currentResponse.ok) return;
    const currentData = await currentResponse.json();
    const current = normalizeLogbooksVersion(currentData.version);
    if (!current) return;
    const manifestResponse = await fetch(LOGBOOKS_UPDATE_MANIFEST, { cache: 'no-store' });
    if (!manifestResponse.ok) return;
    const releases = await manifestResponse.json();
    const latest = (Array.isArray(releases) ? releases : []).map(release => ({ version: normalizeLogbooksVersion(release.tag_name || release.name), assets: release.assets || [] })).filter(release => release.assets.some(asset => /\.zip$/i.test(asset.name || '') && String(asset.browser_download_url || '').startsWith('https://github.com/Eric-R-Qc/ATS-Elog-Releases/raw/'))).reduce((best, release) => !best || compareLogbooksVersions(release.version, best.version) > 0 ? release : best, null);
    if (!latest) return;
    if (compareLogbooksVersions(latest.version, current) > 0) {
      showLogbooksUpdateBanner(current, latest.version);
      if (localStorage.getItem('atselog.pluginUpdateAcknowledged') !== latest.version) showLogbooksUpdateModal(current, latest.version);
    } else {
      localStorage.removeItem('atselog.pluginUpdateAcknowledged');
      document.getElementById('plugin-update-banner')?.remove();
    }
  } catch (_) { /* Logs restent disponibles hors ligne. */ }
}
 
 // --- Mapping texte -> clé TZ interne (pac/mtn/cen/est/ak) ---
function tzKeyForState(state) {
  const raw = String(state || '').trim();
  if (!raw) return 'mtn';

  const lower = raw.toLowerCase();

  // Provinces canadiennes : on accepte plusieurs formats
  if (/colombie[- ]britannique|british columbia|\(bc\)|^bc$/.test(lower)) return 'pac';
  if (/yukon|\(yt\)|^yt$/.test(lower))                                      return 'pac';

  if (/alberta|\(ab\)|^ab$/.test(lower))                                    return 'mtn';
  if (/northwest territories|territoires du nord[- ]ouest|\(nt\)|^nt$/.test(lower)) return 'mtn';

  if (/saskatchewan|\(sk\)|^sk$/.test(lower))                               return 'cen';
  if (/manitoba|\(mb\)|^mb$/.test(lower))                                   return 'cen';

  if (/ontario|\(on\)|^on$/.test(lower))                                    return 'est';
  if (/qu[eé]bec|\(qc\)|^qc$/.test(lower))                                  return 'est';

  // Version "pays (code)" en majuscules (comme dans ton JSON villes)
  const s = raw.toUpperCase();

  if ([
    "USA (CA)","USA (OR)","USA (WA)","USA (NV)",
    "CANADA (BC)","CANADA (YT)","MEXICO (BC)"
  ].includes(s)) return 'pac';

  if ([
    "USA (MT)","USA (WY)","USA (UT)","USA (CO)",
    "USA (AZ)","USA (NM)",
    "CANADA (AB)","CANADA (NT)"
  ].includes(s)) return 'mtn';

  if ([
    "USA (ND)","USA (SD)","USA (NE)","USA (KS)","USA (OK)","USA (TX)",
    "USA (MN)","USA (IA)","USA (MO)","USA (AR)","USA (LA)",
    "USA (WI)","USA (IL)","USA (MS)","USA (AL)",
    "CANADA (SK)","CANADA (MB)"
  ].includes(s)) return 'cen';

  if ([
    "USA (MI)","USA (IN)","USA (KY)","USA (TN)","USA (GA)","USA (FL)",
    "USA (SC)","USA (NC)","USA (VA)","USA (WV)","USA (OH)",
    "USA (PA)","USA (NY)","USA (VT)","USA (NH)","USA (ME)",
    "CANADA (ON)","CANADA (QC)"
  ].includes(s)) return 'est';

  if (["USA (AK)"].includes(s)) return (TZ.ak ? 'ak' : 'pac');

  // défaut : MDT comme ATS vanilla
  return 'mtn';
}

 
function _tzObj() {
  // Logs.html peut être consultée hors ligne : conserver une table locale
  // évite d'afficher UTC si script.js n'est pas encore chargé.
  const fallback = {
    pac: { off: -1, abbr: 'PDT' },
    mtn: { off:  0, abbr: 'MDT' },
    cen: { off:  1, abbr: 'CDT' },
    est: { off:  2, abbr: 'EDT' }
  };
  return (typeof TZ !== 'undefined') ? TZ : (window.TZ || fallback);
}

function tzOffMin(key) {
  const tz = _tzObj();
  return (key && tz[key] && typeof tz[key].off === 'number')
    ? tz[key].off * 60
    : 0;
}

function tzAbbr(key) {
  const tz = _tzObj();
  return (key && tz[key] && typeof tz[key].abbr === 'string')
    ? tz[key].abbr
    : 'UTC';
}

// Normalisation pour comparer les noms/slug de villes
function _normCityKey(v) {
  return (v || "")
    .toString()
    .toLowerCase()
    .replace(/\s+/g, "")      // espaces
    .replace(/[_-]/g, "")     // underscore et tirets
    .replace(/city$/g, "");   // suffixe "city"
}

// Cherche une ville (Trucky / Sheet / local) à partir d'un slug
function getCityBySlugSmart(slug) {
  if (!slug) return null;

  const q = _normCityKey(slug);
  const sources = [
    window.citiesFinal,
    window.citiesSheet,
    window.citiesLocal,
    window.citiesTrucky,
    // Logs.html charge cities-ats.js directement : c'est sa source locale.
    window.cities
  ];

  for (const arr of sources) {
    if (!Array.isArray(arr)) continue;

    // 1) Match exact (_id, realName ou name)
    for (const c of arr) {
      const keys = [
        c._id,
        c.realName,
        c.name
      ].map(_normCityKey);
      if (keys.some(v => v === q)) return c;
    }

    // 2) Match "large" / partiel :
    //    - "coquitlam_bc" doit matcher "coquitlam"
    //    - ou l'inverse
    for (const c of arr) {
      const keys = [
        c._id,
        c.realName,
        c.name
      ].map(_normCityKey);
      if (keys.some(v => v && (v.includes(q) || q.includes(v)))) {
        return c;
      }
    }
  }

  return null;
}


// --- HTZ courant (fuseau HQ basé sur le QG / cache index) ---
// --- HTZ courant (fuseau HQ basé sur le QG / cache index) ---
function getCurrentHTZKey() {
  // 1) Essaye de lire le cache atselog.tz écrit par index.html
  try {
    const cache = JSON.parse(localStorage.getItem('atselog.tz') || 'null');
    if (cache && typeof cache.key === 'string' && cache.key) {
      // ex: "pac", "mtn", "cen", "est"
      return cache.key;
    }
  } catch (_) {}

  // 2) Fallback basé sur la ville du QG si dispo
  try {
    const slug =
      localStorage.getItem('atselog.hq_city') ||
      localStorage.getItem('atselog.htz.raw_city') ||
      '';
    if (slug && typeof getCityBySlugSmart === 'function') {
      const city = getCityBySlugSmart(slug);
      if (city) {
        if (typeof city.tzKey === 'string' && city.tzKey) return city.tzKey;
        const key = tzKeyForState(city.state || city.country || '');
        if (key) return key;
      }
    }
  } catch (_) {}

  // 3) Fallback ultime : Pacific (Seattle, WA) si on n’a rien
  return 'pac';
}





// Lecture du tzKey RODS pour un jour donné
// ⚠️ Version simplifiée: on utilise toujours le HTZ courant (QG).
function getRodsTzKeyForDay(rodDayId) {
  return getCurrentHTZKey();
}


// Calcule un identifiant de "jour RODS" (rodDayId)
// à partir du jour / minute de jeu et du fuseau HTZ.
function getRodDayId(baseDay, baseMin, htzKey) {
  const day = Number.isFinite(baseDay) ? baseDay : 0;
  const min = Number.isFinite(baseMin) ? baseMin : 0;
  const key = htzKey || getCurrentHTZKey();
  const offset = tzOffMin(key); // minutes
  const totalMin = day * 1440 + min + offset;
  return Math.floor(totalMin / 1440);
}


// Programmer le nouveau tz "à partir de demain RODS"
function scheduleRodsTzChangeForTomorrow(baseDay, baseMin, oldKey, newKey){
  if (!newKey || newKey===oldKey) return false;
  const todayId  = getRodDayId(baseDay, baseMin, oldKey);
  const tomorrow = todayId + 1;
 
  plan[tomorrow] = {
    key: newKey, 
    abbr: tzAbbr(newKey), 
    hq: (localStorage.getItem('atselog.hq_city')||''), 
	ts: Date.now()
  };
  
  return true;
}

 
 //---------------------------↑↑↑↑  TRADUCITON  ↑↑↑↑-------------------------------------
 //------------------------↓↓↓↓  FUSEAU HORAIRE  ↓↓↓↓------------------------------------
 // Récupérer la préférence et l’offset
const useTz = localStorage.useTz === '1';
const offset = useTz ? (parseInt(localStorage.timeZoneOffset) || 0) : 0;

// Fonction pour convertir minute jeu → heure locale string
function formatHMWithTz(min) {
  let localMin = min + offset;
  while (localMin < 0) localMin += 1440;
  while (localMin >= 1440) localMin -= 1440;
  const h = Math.floor(localMin/60);
  const m = localMin % 60;
  return `${h.toString().padStart(2,"0")}:${m.toString().padStart(2,"0")}`;
}
 //------------------------↑↑↑↑  FUSEAU HORAIRE  ↑↑↑↑------------------------------------
 //---------------------------↓↓↓↓  PAGE LOGS  ↓↓↓↓--------------------------------------



document.addEventListener('DOMContentLoaded', async () => {
	 applyTranslations()
  checkLogbooksPluginUpdate();
  // Références DOM
  const btnLeft   = document.getElementById('left-arrow');
  const btnRight  = document.getElementById('right-arrow');
  const dayTitle  = document.getElementById('day-title');
  const hoursDiv  = document.getElementById('elog-hours');
  const svg       = document.getElementById('elog-svg');
  const listDiv   = document.getElementById('segments-list');
  const totalsIds = ['OFF','SB','D','ON'].map(st => `total-${st}`);
  const statuses  = ['OFF','SB','D','ON'];

  let logFiles = [];
  let current  = 0;
  let lastTodayGameTime = null;
  let refreshInFlight = false;

  // Quand ATS est fermé, certains navigateurs attendent plusieurs secondes
  // avant de déclarer l'hôte local indisponible. Un délai court laisse le
  // service worker / localStorage prendre le relais sans ralentir la lecture
  // des journaux déjà synchronisés.
  async function fetchWithTimeout(url, options = {}, timeoutMs = 1200) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await fetch(url, { ...options, signal: controller.signal });
    } finally {
      clearTimeout(timer);
    }
  }

  // Logs.html ne charge pas script.js : récupérer le QG ici aussi et le
  // mémoriser sur chaque appareil, notamment pour la consultation hors ligne.
  async function ensureLogBooksHQ() {
    try {
      const before = localStorage.getItem('atselog.hq_city') ||
        localStorage.getItem('atselog.htz.raw_city') || '';
      const res = await fetchWithTimeout('/api/profile/hq', {cache:'no-store'});
      if (!res.ok) return false;
      const data = await res.json();
      if (!data?.ok || !data.hq_city) return false;
      localStorage.setItem('atselog.hq_city', String(data.hq_city));
      return String(data.hq_city) !== String(before);
    } catch (_) { return false; }
  }

  function getStatusColor(s){ return { OFF:'#c3e1c3', SB:'#c3e1c3', D:'#c3e1c3', ON:'#c3e1c3' }[s]||'#eee'; }
  function formatHM(m){ const h=Math.floor(m/60), mm=m%60; return `${h}h${mm.toString().padStart(2,'0')}`; }
  function formatSecToHM(sec) { const m = Math.floor(sec/60); const h = Math.floor(m/60); const mm = m % 60; return `${h}h${mm.toString().padStart(2,'0')}`;}
  
  function clearAll(){
    hoursDiv.innerHTML = '';
    svg.innerHTML      = '';
    listDiv.innerHTML  = '';
    totalsIds.forEach(id => {
      const el = document.getElementById(id);
      if(el) el.textContent = '--h--';
    });
  }

  function buildHourRow(){
    for(let h=0; h<24; h+=3){
      const sp = document.createElement('span');
      sp.textContent = String(h).padStart(2,'0') + 'h';
      hoursDiv.appendChild(sp);
    }
    const sp0 = document.createElement('span');
    sp0.textContent = '00h';
    hoursDiv.appendChild(sp0);
  }

function drawTimeline(events = [], htzOffsetMin = 0) {
  const W = 1440, H = 100, RH = H / 4;

  // 👉 Les logs sont TOUJOURS affichés en fuseau HQ (HTZ).
  // On ne dépend plus de ats_timezone ici.
	const offMinGlobal = Number.isFinite(htzOffsetMin) ? htzOffsetMin : 0;
	
  // grille verticale + lignes de rows (inchangé)
  for (let h = 0; h <= 24; h++) {
    const x = (h / 24) * W;
    const ln = document.createElementNS(svg.namespaceURI, 'line');
    ln.setAttribute('x1', x); ln.setAttribute('y1', 0);
    ln.setAttribute('x2', x); ln.setAttribute('y2', H);
    ln.setAttribute('stroke', document.documentElement.dataset.theme === 'dark' ? '#d9e1e8' : '#ccc'); ln.setAttribute('stroke-width', '1');
    svg.appendChild(ln);
  }
  for (let i = 1; i < 4; i++) {
    const y = i * RH;
    const ln = document.createElementNS(svg.namespaceURI, 'line');
    ln.setAttribute('x1', 0); ln.setAttribute('y1', y);
    ln.setAttribute('x2', W); ln.setAttribute('y2', y);
    ln.setAttribute('stroke', document.documentElement.dataset.theme === 'dark' ? '#d9e1e8' : '#bbb'); ln.setAttribute('stroke-width', '1');
    svg.appendChild(ln);
  }

  // --- Segments de statut (OFF / SB / D / ON)
  events.forEach(seg => {
    // Ligne correspondante au statut
    const row = { OFF:0, SB:1, D:2, ON:3 }[seg.status];
    if (typeof row !== "number") return;

    const y = row * RH + 2;
    const height = RH - 4;

    const draw = (a, b) => {
      const x1 = (a / 1440) * W;
      const x2 = (b / 1440) * W;
      const rect = document.createElementNS(svg.namespaceURI, 'rect');
      rect.setAttribute('x', x1);
      rect.setAttribute('y', y);
      rect.setAttribute('width', x2 - x1);
      rect.setAttribute('height', height);
      rect.setAttribute('fill', '#AECBA6');
      rect.setAttribute('rx', 2);
      rect.setAttribute('ry', 2);
      svg.appendChild(rect);
    };

    const drawDuration = (start, duration) => {
      let cursor = ((start % 1440) + 1440) % 1440;
      let remaining = duration;
      while (remaining > 0) {
        const chunk = Math.min(remaining, 1440 - cursor);
        draw(cursor, cursor + chunk);
        remaining -= chunk;
        cursor = 0;
      }
    };

    // Les minutes brutes sont absolues. La soustraction doit avoir lieu avant
    // le modulo, sinon un segment nul est pris à tort pour un passage minuit.
    if ('start_time_min' in seg || 'start_min' in seg) {
      const sKey = ('start_time_min' in seg) ? 'start_time_min' : 'start_min';
      const eKey = ('end_time_min' in seg) ? 'end_time_min' : 'end_min';
      const rawStart = Number(seg[sKey]);
      const rawEnd = Number(seg[eKey]);
      const duration = rawEnd - rawStart;
      if (!Number.isFinite(rawStart) || !Number.isFinite(rawEnd) ||
          duration <= 0 || duration > 1440) return;
      drawDuration(rawStart + offMinGlobal, duration);
      return;
    }

    const parseHHMM = (value) => {
      const [hours, minutes] = String(value || "00:00").split(":").map(Number);
      return (((hours * 60) + (minutes || 0)) % 1440 + 1440) % 1440;
    };
    const startMin = parseHHMM(seg.start_time || seg.start);
    const endMin = parseHHMM(seg.end_time || seg.end);
    const duration = (endMin - startMin + 1440) % 1440;
    if (duration > 0) drawDuration(startMin + offMinGlobal, duration);
  });
}

// Les pages LogBooks sont des archives : le fuseau affiché doit rester celui
// enregistré avec la journée, même si le joueur modifie ensuite son HTZ.
function tzKeyForOffsetMin(offsetMin, fallbackKey) {
  const tz = _tzObj();
  const found = Object.keys(tz).find(key => tzOffMin(key) === offsetMin);
  return found || fallbackKey || 'mtn';
}


  function calcTotals(events=[]){
    const t={OFF:0,SB:0,D:0,ON:0};
    events.forEach(ev=>{
      let d=(ev.end_time_min>=0?ev.end_time_min:ev.start_time_min+1)-ev.start_time_min;
      if(d<0)d=0;
      if(typeof t[ev.status]==='number') t[ev.status]+=d;
    });
    return t;
  }

function cropEventsToDay(events, dayStartMin, dayEndMin, openEventEndMin = dayEndMin) {
  return (events || [])
    .map(ev => {
      const startRaw = Number(ev.start_time_min);
      const start = Number.isFinite(startRaw) ? Math.max(startRaw, dayStartMin) : dayStartMin;

      // 0 ou non num. => segment ouvert : sur le jour courant, on le borne
      // à l'heure ATS live ; pour une archive, à minuit.
      const endRaw = Number(ev.end_time_min);
      const evEnd = (Number.isFinite(endRaw) && endRaw > 0) ? endRaw : openEventEndMin;

      const end = Math.min(evEnd, dayEndMin);
      if (start >= end) return null;
      return { ...ev, start_time_min: start, end_time_min: end };
    })
    .filter(Boolean);
}


function renderList(events = [], opts = {}) {
  listDiv.innerHTML = '';

  // 👉 Les heures des logs sont TOUJOURS en fuseau HQ (HTZ),
  // indépendamment de ats_timezone (réservé à l’horloge en haut à droite).
  const useLocalTz = true;

  const htzKey = opts.htzKey || null;
  // Abréviation unique pour la journée : fuseau HQ de ce jour (RODS)
  // Le référentiel de la journée est transmis par renderLogDay. S'il manque
  // (vieux journal), l'UTC reste le repli honnête, jamais le choix actuel.
  const abbr = htzKey ? tzAbbr(htzKey) : "UTC";

  // Offset HQ en minutes pour cette journée
  const htzOffsetMin = Number.isFinite(opts.htzOffsetMin) ? opts.htzOffsetMin : 0;
  const distanceUnit = String(opts.distanceUnit || 'km').toLowerCase() === 'mi' ? 'mi' : 'km';


  const dayEndMinFromData = opts._dayEndMin ?? null;

  // le JSON du jour est passé sous opts.data
  const log = opts.data || {};
  const header = document.createElement('div');
  header.className = 'list-header';

  // Total de service de LA journée affichée. Les compteurs du plugin sont
  // ceux de la session en cours et ne doivent pas être réutilisés pour une
  // archive précédente.
  const totalServiceMin = (events || []).reduce((sum, ev) => {
    const status = String(ev.status || '').toUpperCase();
    if (status !== 'ON' && status !== 'D') return sum;
    const start = Number(ev.start_time_min);
    const end = Number(ev.end_time_min);
    return Number.isFinite(start) && Number.isFinite(end) && end > start
      ? sum + (end - start)
      : sum;
  }, 0);

  // Total Km de la journée (somme des segments)
  const totalKm = (events || []).reduce((sum, ev) => {
    const d = Number(ev.distance);
    return sum + (Number.isFinite(d) ? d : 0);
  }, 0);
  const totalKmText = totalKm > 0 ? `${totalKm.toFixed(0)} ${distanceUnit}` : `— ${distanceUnit}`;

  header.innerHTML = `
    <div><strong>🛣️ :</strong> ${totalKmText}</div>
    <div><strong>🕒 :</strong> ${formatHM(totalServiceMin) || '—'}</div>
    <div><strong>🏠 :</strong> <span id="logsTzBadge" class="tz-badge"></span></div>
  `;
  listDiv.appendChild(header);

  // Maintenant que le header existe, on peut remplir le badge 🏠
  const badge = document.getElementById('logsTzBadge');
  if (!badge) return;

  const savedSlug = localStorage.getItem('atselog.hq_city') ||
    localStorage.getItem('atselog.htz.raw_city') || '';
  // Même si la base des villes n'est pas encore chargée, afficher au minimum
  // le nom connu plutôt que « QG inconnu ».
  let label = savedSlug
    ? String(savedSlug).replace(/[_-]+/g, ' ').replace(/\b\w/g, c => c.toUpperCase())
    : 'QG inconnu';
  try {
    const slug = savedSlug;
    if (slug && typeof getCityBySlugSmart === 'function') {
      const city = getCityBySlugSmart(slug);
      if (city) {
        const name   = (city.realName || city.name || '').trim();
        const region = (city.state || city.region || '').trim();
        const countryInfo = (city.country || '').trim();

        let countryLabel = /^usa\b/i.test(countryInfo) ? 'USA' :
          /^canada\b/i.test(countryInfo) ? 'Canada' : '';
        let stateLabel   = region;

        // Ex: "Canada (BC)" → code "BC"
        const m = countryInfo.match(/\(([^)]+)\)/);
        if (m) stateLabel = m[1].toUpperCase();
		// Si le champ "country" vient de Trucky ("British Columbia", "Alberta", etc.)
		if (!stateLabel) {
		  const lc = countryInfo.toLowerCase();
		  if (lc === "british columbia") stateLabel = "BC";
		  else if (lc === "alberta") stateLabel = "AB";
		  else if (lc === "saskatchewan") stateLabel = "SK";
		  else if (lc === "manitoba") stateLabel = "MB";
		  else if (lc === "ontario") stateLabel = "ON";
		  else if (lc === "quebec") stateLabel = "QC";
		  else if (lc === "yukon") stateLabel = "YT";
		  else if (lc === "northwest territories" || lc === "territoires du nord-ouest") stateLabel = "NT";
		}


        const key  = (typeof city.tzKey === 'string' && city.tzKey)
          ? city.tzKey
          : tzKeyForState(city.state || city.country || '');
        const abbr = tzAbbr(key);

        const parts = [];
        if (name)       parts.push(name);
        if (stateLabel) parts.push(stateLabel);
        if (countryLabel) parts.push(countryLabel);
        if (abbr)       parts.push(abbr);

        label = parts.join(', ');
      }
    }
  } catch (_) {}

  badge.textContent = label;

  function formatLogHour(min) {
    let displayMin = useLocalTz ? (min + htzOffsetMin) : min;
    while (displayMin < 0) displayMin += 1440;
    while (displayMin >= 1440) displayMin -= 1440;
    const h = Math.floor(displayMin / 60);
    const m = displayMin % 60;
    const hh = h.toString().padStart(2,"0");
    const mm = m.toString().padStart(2,"0");
    return useLocalTz ? `${hh}:${mm} ${abbr}` : `${hh}:${mm} UTC`;
  }

  events.forEach(ev => {
    const d = document.createElement('div');
    d.className = 'segment-item';

    // RESET visuel
    if (typeof ev.status === "string" && ev.status.startsWith("RESET_")) {
      const isCycle = ev.status === "RESET_CYCLE";
      const label   = isCycle ? "Reset cycle (manuel)" : "Reset journée (manuel)";
      const when    = formatLogHour(ev.start_time_min, ev.tz_offset || 0, abbr);

      d.innerHTML = `
        <div><strong>🛠️ ${label}</strong> — ${when}</div>
        <div>🗺 : ${ev.city || "—"} ${ev.state ? `(${ev.state})` : ""}</div>
      `;
      listDiv.appendChild(d);
      return;
    }

    // ✅ calculer endLabel ICI (dans la boucle), quand "ev" existe
    const endLabel =
      (Number.isFinite(ev.end_time_min) && dayEndMinFromData != null && ev.end_time_min >= dayEndMinFromData)
        ? (useLocalTz ? `24:00 ${abbr}` : "24:00 UTC")
        : formatLogHour(ev.end_time_min);

    d.innerHTML = `
      <div><strong>${ev.status}</strong>:
        ${formatLogHour(ev.start_time_min)}
        → ${endLabel}
        (${formatHM(ev.end_time_min - ev.start_time_min)})
      </div>
      <div>🗺 : ${ev.city || "—"} ${ev.state ? `(${ev.state})` : ""}</div>
      <div>🛣️ : ${ev.distance ?? 0} ${distanceUnit}</div>
      <div>🚚 : ${(ev.truckMake||"")} ${(ev.truckModel||"")} ${ev.truckPlate ? `(${ev.truckPlate}, ${ev.truckPlateCountry||""})` : ""}</div>
      <div>🚛 : ${ev.trailer_body_type||""} ${ev.trailer_ChainType||""}
           ${ev.trailer_immat ? `(${ev.trailer_immat}${ev.trailer_immat_2?`, ${ev.trailer_immat_2}`:""}${ev.trailer_immat_3?`, ${ev.trailer_immat_3}`:""}${ev.trailer_license_plate_country?`, ${ev.trailer_license_plate_country}`:""})` : ""}</div>
    `;
    listDiv.appendChild(d);
  });
}

  // Regroupe l'affichage d'une journée (timeline + totaux + liste)
function renderLogDay(data, bounds, htzKey, htzOffsetMin){

  const allEvents = [
    ...(data.status_events || []),
    ...(data.current_event ? [data.current_event] : [])
  ];
  const gameTime = Number(data.game_time);
  const openEventEnd = Number.isFinite(gameTime) &&
    gameTime >= bounds.startMin && gameTime <= bounds.endMin
      ? gameTime
      : bounds.endMin;
  const dayEvents = cropEventsToDay(
    allEvents,
    bounds.startMin,
    bounds.endMin,
    openEventEnd
  );

  // Timeline en fuseau HQ (HTZ) pour cette journée
  drawTimeline(dayEvents, htzOffsetMin);

  const tot = calcTotals(dayEvents);
  ['OFF','SB','D','ON'].forEach(st => {
    const el = document.getElementById('total-'+st);
    if (el) el.textContent = formatHM(tot[st]);
  });

  // Liste détaillée en fuseau HQ
  renderList(dayEvents, {
    data,
    _dayEndMin: bounds.endMin,
    htzKey,
    htzOffsetMin,
    distanceUnit: data.distance_unit
  });
}



	// ---- Pivot RODS: associe chaque index UI à un rodDayId ----
// ---- Pivot RODS: associe chaque index UI à un rodDayId ----
window._rodPivot = window._rodPivot || {};
(function initRodPivot(){
  const data = window.lastGameData || {};

  // Tz "HQ" utilisé pour calculer le jour RODS courant.
  // On essaie d'utiliser getCurrentHTZKey si elle existe, sinon fallback "pac".
  let todayKey = 'pac';
  try {
    if (typeof getCurrentHTZKey === 'function') {
      todayKey = getCurrentHTZKey();
    }
  } catch (e) {
    console.warn('[ATS Elog] getCurrentHTZKey indisponible sur logs.html, fallback pac', e);
  }

  const rodToday = getRodDayId(data.game_day||0, data.game_time||0, todayKey);

  // Trouve l'index UI "aujourd'hui" (adapte si ton var s'appelle autrement)
  const todayIdx = (typeof currentIndex === 'number') ? currentIndex
                      : (typeof idxToday    === 'number') ? idxToday
                      : 0;

  window._rodPivot.todayIdx  = todayIdx;
  window._rodPivot.rodToday  = rodToday;
  window._rodPivot.map = {}; // idx -> rodDayId

  // Suppose que la liste UI est contiguë autour de todayIdx
  // (si tu as N jours à gauche/droite, ça marche pareil)
  const MAX = 60; // sécurité
  for (let i = todayIdx - MAX; i <= todayIdx + MAX; i++){
    window._rodPivot.map[i] = rodToday + (i - todayIdx);
  }
})();




  // Fonction PRINCIPALE : charge et affiche le jour idx, sans jamais cumuler !
  async function afficherJour(idx) {
    const file = logFiles[idx];
	const isTodayFile = file === 'hos_today.json';
	// --- HTZ RODS pour CE jour ---
    const rodDayId = (window._rodPivot?.map?.[idx] ?? (window._rodPivot?.rodToday ?? 0));
    const htzKey    = getRodsTzKeyForDay(rodDayId);
    const offMinHTZ = tzOffMin(htzKey);
	
    dayTitle.textContent = file.replace(/^hos_/,'').replace('.json','').replace(/_/g,' ');

    try{
      const res = await fetchWithTimeout(`/${file}`, {cache:'no-cache'});
      if(!res.ok) throw new Error(res.status);
      const data = await res.json();

      // Le journal courant est enrichi avec la télémétrie en direct : cela
      // permet à la timeline et au détail du segment ouvert d'évoluer sans
      // attendre la clôture de la journée.
      if (isTodayFile) {
        try {
          const liveRes = await fetchWithTimeout('/data91', {cache:'no-cache'});
          if (liveRes.ok) {
            const live = await liveRes.json();
            const liveTime = Number(live.game_time ?? live.Game_Time);
            if (Number.isFinite(liveTime)) data.game_time = liveTime;
            if (!data.dayName && live.dayName) data.dayName = live.dayName;
            if (!Number.isFinite(Number(data.weekNum)) && live.weekNum != null) data.weekNum = live.weekNum;
            if (live.distance_unit) data.distance_unit = live.distance_unit;
          }
        } catch (_) { /* mode hors ligne : garder le dernier instant sauvegardé */ }

        // Si ATS est fermé, récupérer l'instant final mémorisé par HOS.
        // Cela permet encore de dessiner le dernier segment ouvert du jour.
        if (!Number.isFinite(Number(data.game_time))) {
          try {
            const cached = JSON.parse(localStorage.getItem('lastValidData') || 'null');
            const cachedTime = Number(cached?.game_time ?? cached?.Game_Time);
            if (Number.isFinite(cachedTime)) data.game_time = cachedTime;
          } catch (_) {}
        }
      }

      // Ne vider l'affichage qu'une fois les nouvelles données disponibles.
      // Cela évite le flash blanc visible entre deux rafraîchissements.
      clearAll();
      buildHourRow();

      // Depuis v1.0.4, le plugin enregistre le référentiel exact de la
      // journée. C'est la seule source fiable pour les anciens jours.
      const savedStart = Number(data.timeline_day_start_min);
      const savedEnd = Number(data.timeline_day_end_min);
      const savedOffset = Number(data.timeline_offset_min);
      const hasSavedBounds = Number.isFinite(savedStart) &&
        Number.isFinite(savedEnd) && savedEnd - savedStart === 1440;
      const effectiveOffsetMin = Number.isFinite(savedOffset)
        ? savedOffset
        : offMinHTZ;
      const effectiveTzKey = tzKeyForOffsetMin(effectiveOffsetMin, htzKey);

		  // --- CALCULER les bornes de la journée affichée ---
		// Check si le nom est bien formé et parsable
		if (!file) {
		  dayTitle.textContent = "Erreur nom fichier";
		  return;
		}
      const base = file.replace(/^hos_/, '').replace('.json', '');
      const parts = base.split('_'); // Ex: ["Vendredi","Semaine1750"]
      if (parts.length < 2 && !isTodayFile) {
        dayTitle.textContent = "Fichier log non reconnu";
        return;
      }
      if (isTodayFile) {
        const rawDay = Number(data.day);
        const names = ["Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi","Dimanche"];
        const dayName = String(data.dayName || (Number.isFinite(rawDay) ? names[rawDay % 7] : "Aujourd’hui"));
        const weekNum = Number.isFinite(Number(data.weekNum))
          ? Number(data.weekNum)
          : (Number.isFinite(rawDay) ? Math.floor(rawDay / 7) + 1 : NaN);
        dayTitle.textContent = Number.isFinite(weekNum)
          ? `${dayName} Semaine ${String(weekNum).padStart(2, '0')}`
          : dayName;
      }
		// hos_today.json n'a pas le format hos_<jour>_SemaineNN.json.
		// Ses bornes et son titre viennent directement de son JSON.

		// Anciennes sauvegardes : fallback déterministe, sans supposer le fuseau
		// depuis le nom de fichier. Les nouvelles utilisent toujours les bornes
		// explicitement envoyées par le plugin.
      const rawEvents = [
        ...(data.status_events || []),
        ...(data.current_event ? [data.current_event] : [])
      ];
      const overlapsSavedBounds = hasSavedBounds && rawEvents.some(ev => {
        const start = Number(ev.start_time_min);
        const end = Number(ev.end_time_min);
        return Number.isFinite(start) && Number.isFinite(end) &&
          end > start && start < savedEnd && end > savedStart;
      });

      // Certains journaux créés au moment d'un sommeil ont reçu les bornes
      // du nouveau jour alors que leurs événements appartiennent à la veille.
      // Dans ce cas, on déduit la journée du dernier événement fermé, au lieu
      // d'afficher une page vide. Les nouvelles sauvegardes valides conservent
      // naturellement leurs bornes explicites.
      const rawEnds = rawEvents
        .map(ev => Number(ev.end_time_min))
        .filter(Number.isFinite)
        .filter(end => end > 0);
      const fallbackEnd = rawEnds.length ? Math.max(...rawEnds) : 0;
      const fallbackDay = fallbackEnd > 0
        ? Math.floor((fallbackEnd - 1 + effectiveOffsetMin) / 1440)
        : 0;
      const fallbackStart = fallbackDay * 1440 - effectiveOffsetMin;
      const liveGameTime = Number(data.game_time);
      if (isTodayFile && Number.isFinite(liveGameTime)) {
        lastTodayGameTime = liveGameTime;
      }
      const liveStart = Number.isFinite(liveGameTime)
        ? Math.floor((liveGameTime + effectiveOffsetMin) / 1440) * 1440 - effectiveOffsetMin
        : 0;
      const bounds = isTodayFile && Number.isFinite(liveGameTime)
        ? { startMin: liveStart, endMin: liveStart + 1440 }
        : isTodayFile && hasSavedBounds
          ? { startMin: savedStart, endMin: savedEnd }
        : (hasSavedBounds && overlapsSavedBounds)
          ? { startMin: savedStart, endMin: savedEnd }
          : { startMin: fallbackStart, endMin: fallbackStart + 1440 };

		// Affiche la journée via la fonction dédiée
		  renderLogDay(
			data,
			bounds,
			effectiveTzKey,
			effectiveOffsetMin
		  );

    }catch(e){
      console.error('Erreur lecture', file, e);
      dayTitle.textContent = 'Erreur lecture log';
    }

    btnLeft.disabled  = (idx===0);
    btnRight.disabled = (idx===logFiles.length-1);
  }

  async function refreshLogFiles(keepFile = null) {
    try {
    const resp = await fetchWithTimeout('/logs-list', {cache:'no-cache'});
    if(!resp.ok) throw new Error(resp.status);
    const archived = await resp.json(); // serveur : plus récent vers plus ancien
    // Navigation logique : gauche = jours précédents, droite = jours suivants.
    // Le journal courant est toujours le dernier, donc affiché à droite.
    logFiles = archived.reverse();
    logFiles = logFiles.filter(name => name !== 'hos_today.json');
    logFiles.push('hos_today.json');
    if (keepFile) {
      const preservedIndex = logFiles.indexOf(keepFile);
      if (preservedIndex >= 0) current = preservedIndex;
    }
    return true;
  } catch(e) {
    // Hors ligne, reprendre l'inventaire préchargé depuis n'importe quelle
    // page ATS Elog pendant la dernière session connectée.
    try {
      const archived = JSON.parse(localStorage.getItem('atselog.logs.list.v1') || '[]');
      if (Array.isArray(archived)) {
        logFiles = archived.slice().reverse().filter(name => name !== 'hos_today.json');
        logFiles.push('hos_today.json');
        if (keepFile) {
          const preservedIndex = logFiles.indexOf(keepFile);
          if (preservedIndex >= 0) current = preservedIndex;
        }
        return logFiles.length > 0;
      }
    } catch (_) {}
    console.warn('Impossible de rafraîchir logs-list', e);
    return false;
  }
  }

  // --- Initialisation ---
  await ensureLogBooksHQ();
  await refreshLogFiles();
  current = logFiles.length - 1;

  btnLeft.addEventListener('click', async () => {
    const viewedFile = logFiles[current];
    await refreshLogFiles(viewedFile);
    if (current > 0) {
      current--;
      afficherJour(current);
    }
  });
  btnRight.addEventListener('click', async () => {
    const viewedFile = logFiles[current];
    await refreshLogFiles(viewedFile);
    if (current < logFiles.length - 1) {
      current++;
      afficherJour(current);
    }
  });

  // Affiche le dernier jour au départ
  await afficherJour(current);

  // Si la page est restée ouverte au passage de minuit, récupérer les
  // archives créées entre-temps dès que l'utilisateur revient dessus.
  window.addEventListener('focus', async () => {
    const hqChanged = await ensureLogBooksHQ();
    await refreshLogFiles(logFiles[current]);
    if (hqChanged) afficherJour(current);
  });
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) refreshLogFiles(logFiles[current]);
  });

  // Le jour courant reste vivant, sans recharger la page en continu : on ne
  // redessine que lorsqu'une minute ATS a réellement changé.
  window.setInterval(async () => {
    if (refreshInFlight || logFiles[current] !== 'hos_today.json') return;
    refreshInFlight = true;
    try {
      const res = await fetch('/data91', {cache:'no-cache'});
      if (!res.ok) return;
      const live = await res.json();
      const minute = Number(live.game_time ?? live.Game_Time);
      if (Number.isFinite(minute) && minute !== lastTodayGameTime) {
        await afficherJour(current);
      }
    } catch (_) { /* hors ligne : conserver l'instant affiché */ }
    finally { refreshInFlight = false; }
  }, 750);
});

// === Export PDF (print) ===
(function setupExportPDF(){
  const btn = document.getElementById('btn-export-pdf');
  if (!btn) return;

  btn.addEventListener('click', () => {
    // Essayer d’avoir un titre de document utile pour le nom du PDF
    const day = (document.getElementById('day-title')?.textContent || '').trim();
    const now = new Date();
    const stamp = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
    const oldTitle = document.title;
    document.title = day ? `ATS_Elog_${day}_${stamp}` : `ATS_Elog_${stamp}`;

    window.print();

    // Restaure le titre après impression
    setTimeout(() => { document.title = oldTitle; }, 500);
  });
})();

// === Impression : forcer le dépliage des zones scrollables ===
window.addEventListener('beforeprint', () => {
  document.body.classList.add('print-mode');
});
window.addEventListener('afterprint', () => {
  document.body.classList.remove('print-mode');
});


/* =========================
   HEADER-ONLY FOR logs.html
   ========================= */
   
(function headerOnlyForLogs(){
  const nameEl   = document.getElementById('affichageChauffeur');
  const iconEl   = document.getElementById('conn-icon');
  const timeEl   = document.getElementById('header-game-time');

  function setHeaderDisconnected() {
    if (!iconEl) return;
    iconEl.classList.remove('connected');
    iconEl.classList.add('disconnected');
    iconEl.src = 'textures/icon-conr.png';
    iconEl.alt = 'Connexion ATS Elog : OFF';
  }

  // État de départ : il ne devient vert qu'après une réponse JSON valide.
  setHeaderDisconnected();

  // 1) Nom du conducteur (avec 🪪)
  function renderDriverName() {
    if (!nameEl) return;
    let nom = (localStorage.getItem('nomChauffeur') || '').trim();
    if (nom && !nom.startsWith('🪪')) nom = '🪪 ' + nom;
    nameEl.textContent = nom || '';
  }
  renderDriverName();
  window.addEventListener('storage', (e) => { 
  if (e.key === 'nomChauffeur') renderDriverName(); 
  if (e.key === 'ats_timezone' || e.key === 'atselog.tz') {
  try { afficherJour(current); } catch(_) {}
   }
  });

  // 2) Fuseau: récupérer le cache (si présent) sauvegardé par l’index
  // --- Lecture TZ depuis le cache ---
let tzCache = null;
try { tzCache = JSON.parse(localStorage.getItem('atselog.tz') || 'null'); } catch {}
// Heures "finales" prêtes à l'emploi : priorité au nouveau champ, sinon compat ancien
const offHours = (tzCache && Number.isFinite(tzCache.offFinal))
  ? tzCache.offFinal
  : (tzCache && Number.isFinite(tzCache.off) ? tzCache.off : null);

function selectedTzMode() {
  return localStorage.getItem('tz_mode') ||
    (localStorage.getItem('ats_timezone') === '1' ? 'auto' : 'off');
}

function formatHMMStr(hhmm){ return (hhmm || '--:--').replace(':','h'); }
function showUtc(hhmm){ timeEl && (timeEl.textContent = formatHMMStr(hhmm)); }
function showLocal(hhmm, fallbackOffset, fallbackAbbr){
  if (!timeEl) return;
  const effectiveOffset = Number.isFinite(fallbackOffset) ? fallbackOffset : offHours;
  if (effectiveOffset == null) { timeEl.textContent = formatHMMStr(hhmm); return; }
  const [H,M] = (hhmm || '00:00').split(':').map(Number);
  const utcMin  = H*60 + M;
  let localMin  = (utcMin + effectiveOffset*60) % 1440;
  if (localMin < 0) localMin += 1440;
  const hh = String(Math.floor(localMin/60)).padStart(2,'0');
  const mm = String(localMin%60).padStart(2,'0');
  const ab = fallbackAbbr || ((tzCache && tzCache.abbr) ? tzCache.abbr : '');
  timeEl.textContent = `${hh}h${mm} ${ab}`.trim();
}


  // 3) Poll léger /data91 pour l’icône + l’heure
  let lastOk = false;
  async function pollHeader(){
    try{
      const ctrl = new AbortController();
	  const t = setTimeout(()=>ctrl.abort(), 4000); // 1500 -> 4000ms
	  const r = await fetch('/data91', {cache:'no-cache', signal: ctrl.signal});
	  clearTimeout(t);
	  const ok = r.ok;
	  iconEl && iconEl.classList.toggle('connected', ok);
	  iconEl && iconEl.classList.toggle('disconnected', !ok);
	  
	if (iconEl) {
	iconEl.src = ok ? 'textures/icon-conv.png' : 'textures/icon-conr.png';
	iconEl.alt = ok ? 'Connexion ATS Elog : OK' : 'Connexion ATS Elog : OFF';
	}

	if (ok){
	  const data = await r.json();
	  const mode = selectedTzMode();
	  if (mode === 'off') {
	    showUtc(data.clock || '--:--');
	  } else {
	    const offsets = { '-1':'PDT', '0':'MDT', '1':'CDT', '2':'EDT', '3':'ADT' };
	    const offset = Number(data.usetz_offset);
	    const abbr = (tzCache && tzCache.abbr) || offsets[String(offset)] || '';
	    // clock_local is already calculated by the plugin with the selected
	    // time-zone setting. Fall back to the base clock only when unavailable.
	    if (data.clock_local) timeEl.textContent = `${formatHMMStr(data.clock_local)}${abbr ? ' ' + abbr : ''}`;
	    else showLocal(data.clock || '--:--', offset, abbr);
	  }
	}
	else {
        // pas de data → on garde l’affichage courant
      }
    }catch(e){
      setHeaderDisconnected();
    }finally{
      setTimeout(pollHeader, 1000);
    }
  }
// === Retour auto vers index quand D actif (depuis logs.html) ===
async function autoReturnFromLogs() {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 4000);
    const r = await fetch("/data91", { cache: "no-cache", signal: ctrl.signal });
    clearTimeout(t);

    if (!r.ok) return;

    const data = await r.json();
    const isDriving  = Number(data.status) === 2; // D = 2
    const fatigueOff = Number(data.Auto)   === 0; // fatigue OFF (mode manuel)

    if (isDriving && fatigueOff) {
      // évite boucle si déjà sur index
      const current = window.location.pathname.toLowerCase();
      if (!current.endsWith("index.html") && !current.endsWith("/")) {
        console.log("🚛 Statut D actif → retour auto sur index.html");
        window.location.href = "index.html";
        return;
      }
    }
  } catch (e) {
    // ignorer erreurs réseau
  } finally {
    setTimeout(autoReturnFromLogs, 4000); // vérifie toutes les 4 s
  }
}

// Lancer le cycle
autoReturnFromLogs();

  pollHeader();
})();
// === Footer impression : injecter la version ===
(function syncPrintFooter(){
  // 1) lire depuis la meta <meta name="app-version" content="...">
  let v = document.querySelector('meta[name="app-version"]')?.content?.trim();

  // 2) fallback possible si tu stockes déjà la version quelque part
  if (!v) v = localStorage.getItem('atselog.version') || window.APP_VERSION || '';

  const pf = document.querySelector('#print-footer .ui-version');
  if (pf && v) pf.textContent = v;
})();

