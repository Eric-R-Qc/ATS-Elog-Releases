var cities = [
    {
        "realName": "Winterland",
        "country": "christmas",
        "x": "-159808",
        "z": "124170"
    },
    {
        "realName": "Aberdeen",
        "country": "USA (WA)",
        "x": "-106953",
        "z": "-61418.6"
    },
    {
        "realName": "Abilene",
        "country": "USA (TX)",
        "x": "-17366.2",
        "z": "36430.9"
    },
    {
        "realName": "Alamogordo",
        "country": "USA (NM)",
        "x": "-46644.1",
        "z": "31604"
    },
    {
        "realName": "Alamosa",
        "country": "USA (CO)",
        "x": "-44120.3",
        "z": "6136.21"
    },
    {
        "realName": "Albuquerque",
        "country": "USA (NM)",
        "x": "-49593.2",
        "z": "17534.7"
    },
    {
        "realName": "Albuquerque",
        "country": "USA (NM)",
        "x": "-49704.4",
        "z": "21583.7"
    },
    {
        "realName": "Algona",
        "country": "USA (IA)",
        "x": "6982.42",
        "z": "-23316.8"
    },
    {
        "realName": "Alliance",
        "country": "USA (NE)",
        "x": "-28456.6",
        "z": "-19081.8"
    },
    {
        "realName": "Alliance",
        "country": "USA (NE)",
        "x": "-28456.6",
        "z": "-19081.8"
    },
    {
        "realName": "Alma",
        "country": "USA (NE)",
        "x": "-14586",
        "z": "-6918.97"
    },
    {
        "realName": "Amarillo",
        "country": "USA (TX)",
        "x": "-26731.8",
        "z": "20312.9"
    },
    {
        "realName": "Ansley",
        "country": "USA (NE)",
        "x": "-14790.9",
        "z": "-13779.6"
    },
    {
        "realName": "Ansley",
        "country": "USA (NE)",
        "x": "-14790.9",
        "z": "-13779.6"
    },
    {
        "realName": "Ardmore",
        "country": "USA (OK)",
        "x": "-5273.01",
        "z": "24862.9"
    },
    {
        "realName": "Astoria",
        "country": "USA (OR)",
        "x": "-109480",
        "z": "-56823.9"
    },
    {
        "realName": "Auburn",
        "country": "USA (NE)",
        "x": "613.006",
        "y": "53.4135",
        "z": "-7988.69"
    },
    {
        "gameName": "audubon",
        "realName": "Audubon",
        "country": "USA (IA)",
        "x": "4568.95",
        "z": "-16273"
    },
    {
        "realName": "Austin",
        "country": "USA (TX)",
        "x": "-8521.76",
        "z": "48694"
    },
    {
        "realName": "Baker City",
        "country": "USA (OR)",
        "x": "-86680.9",
        "z": "-43232.3"
    },
    {
        "realName": "Baggs",
        "country": "USA (WY)",
        "x": "-49498.6",
        "z": "-15309.5"
    },
    {
        "realName": "Baker",
        "country": "USA (NV)",
        "x": "-89919.7",
        "z": "10180.3"
    },
    {
        "realName": "Bakersfield",
        "country": "USA (CA)",
        "x": "-104572",
        "z": "6987.57"
    },
    {
        "realName": "Barstow",
        "country": "USA (CA)",
        "x": "-95069.8",
        "z": "12704.5"
    },
    {
        "realName": "Barstow",
        "country": "USA (CA)",
        "x": "-92359",
        "z": "11976.2"
    },
    {
        "realName": "Barstow",
        "country": "USA (CA)",
        "x": "-98124.8",
        "z": "12579.6"
    },
    {
        "realName": "Barstow",
        "country": "USA (CA)",
        "x": "-98124.8",
        "z": "12579.6"
    },
    {
        "realName": "Bartlett",
        "country": "USA (NE)",
        "x": "-11184.6",
        "z": "-16517.1"
    },
    {
        "realName": "Bassett",
        "country": "USA (NE)",
        "x": "-14995.5",
        "z": "-20549"
    },
    {
        "realName": "Bassett",
        "country": "USA (NE)",
        "x": "-14995.5",
        "z": "-20549"
    },
    {
        "realName": "Beatrice",
        "country": "USA (NE)",
        "x": "-3938.86",
        "z": "-7144.62"
    },
    {
        "realName": "Beatrice",
        "country": "USA (NE)",
        "x": "-3938.86",
        "z": "-7144.62"
    },
    {
        "realName": "Beatrice",
        "country": "USA (KS)",
        "x": "-3938.86",
        "z": "-8144.62"
    },
    {
        "realName": "Beaumont",
        "country": "USA (TX)",
        "x": "9941.66",
        "z": "50291.3"
    },
    {
        "realName": "Bellingham",
        "country": "USA (WA)",
        "x": "-98654.2",
        "y": "55.59",
        "z": "-69115"
    },
    {
        "realName": "Belleville",
        "country": "USA (KS)",
        "x": "-6183.93",
        "z": "-4672.59"
    },
    {
        "realName": "Bend",
        "country": "USA (OR)",
        "x": "-101347",
        "z": "-42357.6"
    },
    {
        "realName": "Bethany",
        "country": "USA (MO)",
        "x": "9225.54",
        "z": "-7276.33"
    },
    {
        "realName": "Big Piney",
        "country": "USA (WY)",
        "x": "-58068.8",
        "z": "-24662.5"
    },
    {
        "realName": "Big Spring",
        "country": "USA (TX)",
        "x": "-24748.8",
        "z": "37294.7"
    },
    {
        "realName": "Big Spring",
        "country": "USA (TX)",
        "x": "-24748.8",
        "z": "37294.7"
    },
    {
        "realName": "Billings",
        "country": "USA (MT)",
        "x": "-48677.9",
        "z": "-42375.1"
    },
    {
        "realName": "Bishop",
        "country": "USA (CA)",
        "x": "-97447.9",
        "z": "-835.484"
    },
    {
        "realName": "Bluff",
        "country": "USA (UT)",
        "x": "-60436.4",
        "z": "4884.14"
    },
    {
        "realName": "Bluff",
        "country": "USA (UT)",
        "x": "-60436.4",
        "z": "4884.14"
    },
    {
        "realName": "Boise",
        "country": "USA (ID)",
        "x": "-81820.6",
        "z": "-35583.8"
    },
    {
        "realName": "Boise City",
        "country": "USA (OK)",
        "x": "-28370.7",
        "z": "10697.5"
    },
    {
        "realName": "Boron",
        "country": "USA (CA)",
        "x": "-97727.2",
        "z": "10188.1"
    },
    {
        "realName": "Bozeman",
        "country": "USA (MT)",
        "x": "-57979.1",
        "z": "-41966.3"
    },
    {
        "realName": "Bozeman",
        "country": "USA (MT)",
        "x": "-57979.1",
        "z": "-41966.3"
    },
    {
        "realName": "Bozeman",
        "country": "USA (MT)",
        "x": "-60079.1",
        "z": "-44066.3"
    },
    {
        "realName": "Brawley",
        "country": "USA (CA)",
        "x": "-92227.9",
        "z": "23840.7"
    },
    {
        "realName": "Brawley",
        "country": "Mexique (XX)",
        "x": "-92227.9",
        "z": "23840.7"
    },
    {
        "realName": "Broadus",
        "country": "USA (MT)",
        "x": "-37438.1",
        "z": "-39430.3"
    },
    {
        "realName": "Broadus",
        "country": "USA (MT)",
        "x": "-37438.1",
        "z": "-39430.3"
    },
    {
        "realName": "Brownwood",
        "country": "USA (TX)",
        "x": "-14710.9",
        "z": "41271.9"
    },
    {
        "realName": "Buffalo",
        "country": "USA (TX)",
        "x": "405.907",
        "z": "41963.2"
    },
    {
        "realName": "Burlington",
        "country": "USA (CO)",
        "x": "-28855.2",
        "z": "-2904.98"
    },
    {
        "realName": "Burlington",
        "country": "USA (IA)",
        "x": "20294",
        "z": "-10562.7"
    },
    {
        "realName": "Burns",
        "country": "USA (OR)",
        "x": "-92989.7",
        "z": "-37951.5"
    },
    {
        "realName": "Butte",
        "country": "USA (MT)",
        "x": "-65388.6",
        "z": "-44535.3"
    },
    {
        "realName": "Butte",
        "country": "USA (MT)",
        "x": "-63813.1",
        "z": "-46794"
    },
    {
        "realName": "Butte",
        "country": "USA (MT)",
        "x": "-63813.1",
        "z": "-46794"
    },
    {
        "realName": "Canadian",
        "country": "USA (TX)",
        "x": "-20100.1",
        "z": "16426.2"
    },
    {
        "realName": "Cape Girardeau",
        "country": "USA (MO)",
        "x": "29311.8",
        "z": "8091.99"
    },
    {
        "realName": "Carlsbad",
        "country": "USA (NM)",
        "x": "-38330.6",
        "z": "35353.5"
    },
    {
        "realName": "Carson City",
        "country": "USA (NV)",
        "x": "-102681",
        "z": "-13171.5"
    },
    {
        "realName": "Casper",
        "country": "USA (WY)",
        "x": "-41501.4",
        "z": "-25775"
    },
    {
        "realName": "Couer d'Alene",
        "country": "USA (WA)",
        "x": "-77440.9",
        "z": "-58343.6"
    },
    {
        "realName": "Cedar City",
        "country": "USA (UT)",
        "x": "-74187.1",
        "z": "-2143.96"
    },
    {
        "realName": "Cedar Rapids",
        "country": "USA (IA)",
        "x": "17420.8",
        "z": "-17290.5"
    },
    {
        "realName": "Cedar Rapids",
        "country": "USA (IA)",
        "x": "17420.8",
        "z": "-17290.5"
    },
    {
        "realName": "Cedar Valley",
        "country": "USA (IA)",
        "x": "17820.8",
        "z": "-17490.5"
    },
    {
        "realName": "Chadron",
        "country": "USA (NE)",
        "x": "-28044.9",
        "z": "-22955.2"
    },
    {
        "realName": "Cheyenne",
        "country": "USA (WY)",
        "x": "-36591.9",
        "z": "-14475.8"
    },
    {
        "realName": "Childress",
        "country": "USA (TX)",
        "x": "-19420.1",
        "z": "24984"
    },
    {
        "realName": "Childress",
        "country": "USA (OK)",
        "x": "-19420.1",
        "z": "24984"
    },
    {
        "realName": "Chillicothe",
        "country": "USA (MO)",
        "x": "11256.2",
        "z": "-4720.42"
    },
    {
        "realName": "Chillicothe",
        "country": "USA (MO)",
        "x": "11256.2",
        "z": "-4720.42"
    },
    {
        "realName": "Chinle",
        "country": "USA (AZ)",
        "x": "-61531.6",
        "z": "11680.6"
    },
    {
        "realName": "Clayton",
        "country": "USA (NM)",
        "x": "-32846.3",
        "z": "13019.1"
    },
    {
        "realName": "Clifton",
        "country": "USA (AZ)",
        "x": "-62631.9",
        "z": "28255.8"
    },
    {
        "realName": "Clinton",
        "country": "USA (OK)",
        "x": "-15042.5",
        "z": "19340"
    },
    {
        "realName": "Clinton",
        "country": "USA (OK)",
        "x": "-15042.5",
        "z": "19340"
    },
    {
        "realName": "Clovis",
        "country": "USA (NM)",
        "x": "-33411.9",
        "z": "24758.7"
    },
    {
        "realName": "Cody",
        "country": "USA (WY)",
        "x": "-53205.6",
        "z": "-35109.9"
    },
    {
        "realName": "Colby",
        "country": "USA (KS)",
        "x": "-23043.8",
        "z": "-1644.82"
    },
    {
        "realName": "College Station",
        "country": "USA (TX)",
        "x": "-3015.47",
        "z": "46104.4"
    },
    {
        "realName": "Colorado Springs/Pueblo",
        "country": "USA (CO)",
        "x": "-37543",
        "z": "528.353"
    },
    {
        "realName": "Columbia / Jefferson City",
        "country": "USA (MO)",
        "x": "15450.5",
        "z": "-812.559"
    },
    {
        "realName": "Columbus",
        "country": "USA (NE)",
        "x": "-6094.45",
        "z": "-14339.5"
    },
    {
        "realName": "Colville",
        "country": "USA (WA)",
        "x": "-81594.7",
        "z": "-63715.6"
    },
	
    	{
        "realName": "Coos Bay",
        "country": "USA (OR)",
        "x": "-115694",
        "z": "-43570.7"
    },
    {
        "realName": "Corsicana",
        "country": "USA (TX)",
        "x": "-2120.1",
        "z": "38715.8"
    },
    {
        "realName": "Corpus Christi",
        "country": "USA (TX)",
        "x": "-7054.73",
        "z": "63483.4"
    },
    {
        "realName": "Cotulla",
        "country": "USA (TX)",
        "x": "-16758.7",
        "z": "58529.4"
    },
    {
        "realName": "Crescent City",
        "country": "USA (CA)",
        "x": "-117438",
        "z": "-35254.1"
    },
    {
        "realName": "Cushing",
        "country": "USA (OK)",
        "x": "-3995.68",
        "z": "16010.5"
    },
    {
        "realName": "Cushing",
        "country": "USA (OK)",
        "x": "-3995.68",
        "z": "16010.5"
    },
    {
        "realName": "Dallas/Fort Worth",
        "country": "USA (TX)",
        "x": "-5002.56",
        "z": "34026.8"
    },
    {
        "realName": "Dalhart",
        "country": "USA (TX)",
        "x": "-30010.5",
        "z": "15794.6"
    },
    {
        "realName": "Dalhart",
        "country": "USA (TX)",
        "x": "-30010.5",
        "z": "15794.6"
    },
    {
        "realName": "Dateland",
        "country": "USA (AZ)",
        "x": "-81820.2",
        "z": "28604.3"
    },
    {
        "realName": "Davenport",
        "country": "USA (IA)",
        "x": "23254.2",
        "z": "-15124.5"
    },
    {
        "realName": "Davenport",
        "country": "USA (IA)",
        "x": "23254.2",
        "z": "-15124.5"
    },
    {
        "realName": "Deepwater",
        "country": "USA (MO)",
        "x": "10305.1",
        "z": "4579.84"
    },
    {
        "realName": "Del Rio",
        "country": "USA (TX)",
        "x": "-24782.2",
        "z": "53833.6"
    },
    {
        "realName": "Delta",
        "country": "USA (UT)",
        "x": "-72506.8",
        "z": "-9067.3"
    },
    {
        "realName": "Deming",
        "country": "USA (NM)",
        "x": "-56483.5",
        "z": "34248.3"
    },
    {
        "realName": "Denver",
        "country": "USA (CO)",
        "x": "-38561.4",
        "z": "-5191.34"
    },
    {
        "realName": "De Queen",
        "country": "USA (AR)",
        "x": "8009.72",
        "z": "25208.4"
    },
    {
        "realName": "Des Moines",
        "country": "USA (IA)",
        "x": "9082.62",
        "z": "-15338.5"
    },
    {
        "realName": "Diablo",
        "country": "USA (WA)",
        "x": "-93493.5",
        "z": "-67364.4"
    },
    {
        "realName": "Dillon",
        "country": "USA (MT)",
        "x": "-65859.8",
        "z": "-39032.8"
    },
    {
        "realName": "Dodge City",
        "country": "USA (KS)",
        "x": "-17483.2",
        "z": "6177.79"
    },
    {
        "realName": "Dubuque",
        "country": "USA (IA)",
        "x": "21512.5",
        "z": "-20596.2"
    },
    {
        "realName": "Durango",
        "country": "USA (CO)",
        "x": "-52062.4",
        "z": "5510.96"
    },
    {
        "realName": "Durango",
        "country": "USA (NM)",
        "x": "-52062.4",
        "z": "5510.96"
    },
    {
        "realName": "Durant",
        "country": "USA (OK)",
        "x": "-1330.45",
        "z": "26513.8"
    },
    {
        "realName": "Eagle Pass/Piedras Negras",
        "country": "USA (TX)",
        "x": "-22270.2",
        "z": "57994.2"
    },
    {
        "realName": "Eagle Nest",
        "country": "USA (NM)",
        "x": "-42881.7",
        "z": "11832.4"
    },
    {
        "realName": "Ehrenberg",
        "country": "USA (AZ)",
        "x": "-86563.6",
        "z": "20968.2"
    },
    {
        "realName": "El Dorado",
        "country": "USA (AR)",
        "x": "16340.6",
        "z": "30834.6"
    },
    {
        "realName": "Elko",
        "country": "USA (NV)",
        "x": "-81952",
        "z": "-20153"
    },
    {
        "realName": "Elm Creek",
        "country": "USA (NE)",
        "x": "-15649.8",
        "z": "-10331.8"
    },
    {
        "realName": "Elm Creek",
        "country": "USA (NE)",
        "x": "-15649.8",
        "z": "-10331.8"
    },
    {
        "realName": "El Paso/Cd. Juárez",
        "country": "USA (TX)",
        "x": "-49615.9",
        "z": "38414.9"
    },
    {
        "realName": "Ely",
        "country": "USA (NV)",
        "x": "-81817",
        "z": "-10079.4"
    },
    {
        "realName": "Embarcadero",
        "country": "USA (CA)",
        "x": "-114385",
        "z": "-15787.5"
    },
    {
        "realName": "Emporia",
        "country": "USA (KS)",
        "x": "-900.115",
        "z": "3993.1"
    },
    {
        "realName": "Enid",
        "country": "USA (OK)",
        "x": "-8720.07",
        "z": "14152.2"
    },
    {
        "realName": "Eugene",
        "country": "USA (OR)",
        "x": "-108218",
        "z": "-43727.7"
    },
    {
        "realName": "Eureka",
        "country": "USA (CA)",
        "x": "-118391",
        "z": "-27408.9"
    },
    {
        "realName": "Eureka",
        "country": "USA (NV)",
        "x": "-88331.5",
        "z": "-13386"
    },
    {
        "realName": "Evanston",
        "country": "USA (WY)",
        "x": "-60461",
        "z": "-18638.7"
    },
    {
        "realName": "Fallon",
        "country": "USA (NV)",
        "x": "-94981.2",
        "z": "-12840.8"
    },
    {
        "realName": "Fallon",
        "country": "USA (NV)",
        "x": "-94089.7",
        "z": "-16853.6"
    },
    {
        "realName": "Farmington",
        "country": "USA (NM)",
        "x": "-54704.5",
        "z": "8813.18"
    },
    {
        "realName": "Farmington",
        "country": "USA (CO)",
        "x": "-54704.5",
        "z": "8813.18"
    },
    {
        "realName": "Fayetteville",
        "country": "USA (AR)",
        "x": "9899.16",
        "z": "14301.6"
    },
    {
        "realName": "Flagstaff",
        "country": "USA (AZ)",
        "x": "-72334.6",
        "z": "16275.2"
    },
    {
        "realName": "Forsyth",
        "country": "USA (MT)",
        "x": "-42303.6",
        "z": "-44059.5"
    },
    {
        "realName": "Forsyth",
        "country": "USA (MT)",
        "x": "-42303.6",
        "z": "-44059.5"
    },
    {
        "realName": "Fort Collins",
        "country": "USA (CO)",
        "x": "-39016.8",
        "z": "-11147.9"
    },
    {
        "realName": "Fort Dodge",
        "country": "USA (IA)",
        "x": "8216",
        "z": "-21030.2"
    },
    {
        "realName": "Fort Smith",
        "country": "USA (AR)",
        "x": "8790.19",
        "z": "20151.9"
    },
    {
        "realName": "Fort Stockton",
        "country": "USA (TX)",
        "x": "-33554.3",
        "z": "45384.6"
    },
    {
        "realName": "Freedom",
        "country": "USA (WY)",
        "x": "-62024.8",
        "z": "-26921.5"
    },
    {
        "realName": "Freer",
        "country": "USA (TX)",
        "x": "-13322",
        "z": "62735.9"
    },
    {
        "realName": "Fresno",
        "country": "USA (CA)",
        "x": "-105676",
        "z": "189.91"
    },
    {
        "realName": "Grand Canyon Village",
        "country": "USA (AZ)",
        "x": "-73445",
        "z": "10298.5"
    },
    {
        "realName": "Gainesville",
        "country": "USA (TX)",
        "x": "-4900.64",
        "z": "29395.8"
    },
    {
        "realName": "Gainesville",
        "country": "USA (TX)",
        "x": "-4900.64",
        "z": "29395.8"
    },
    {
        "realName": "Gallup",
        "country": "USA (NM)",
        "x": "-58246.5",
        "z": "15448.3"
    },
    {
        "realName": "Galveston",
        "country": "USA (TX)",
        "x": "6388.7",
        "z": "54871.6"
    },
    {
        "realName": "Garden City",
        "country": "USA (KS)",
        "x": "-21687.2",
        "z": "5757.88"
    },
    {
        "realName": "Garner",
        "country": "USA (IA)",
        "x": "8608.87",
        "z": "-23581.7"
    },
    {
        "realName": "Gila Bend",
        "country": "USA (AZ)",
        "x": "-77809.4",
        "z": "27710.3"
    },
    {
        "realName": "Gillette",
        "country": "USA (WY)",
        "x": "-37555",
        "z": "-31984.8"
    },
    {
        "realName": "Glasgow",
        "country": "USA (MT)",
        "x": "-40268.7",
        "z": "-54673.6"
    },
    {
        "realName": "Glendive",
        "country": "USA (MT)",
        "x": "-33819.1",
        "z": "-47322.6"
    },
    {
        "realName": "Glendive",
        "country": "USA (MT)",
        "x": "-33819.1",
        "z": "-47322.6"
    },
    {
        "realName": "Glenwood Springs",
        "country": "USA (CO)",
        "x": "-48845.1",
        "z": "-5649.02"
    },
    {
        "realName": "Grand Island",
        "country": "USA (NE)",
        "x": "-10488.6",
        "z": "-11728.4"
    },
    {
        "realName": "Grand Junction/Montrose",
        "country": "USA (CO)",
        "x": "-52937.9",
        "z": "-2215.41"
    },
    {
        "realName": "Grand Junction",
        "country": "USA (CO)",
        "x": "-55356.3",
        "z": "-4570.03"
    },
    {
        "realName": "Grand Lake",
        "country": "USA (CO)",
        "x": "-43107.9",
        "z": "-8889.43"
    },
    {
        "realName": "Grangeville",
        "country": "USA (ID)",
        "x": "-77628.2",
        "z": "-48313.5"
    },
    {
        "realName": "Granite",
        "country": "USA (OK)",
        "x": "-16042.5",
        "z": "22340"
    },
    {
        "realName": "Great Falls",
        "country": "USA (MT)",
        "x": "-57882.9",
        "z": "-54597.5"
    },
    {
        "realName": "Greybull",
        "country": "USA (WY)",
        "x": "-48448.5",
        "z": "-33764.9"
    },
    {
        "realName": "Guthrie",
        "country": "USA (TX)",
        "x": "-19943.8",
        "z": "29604.5"
    },
    {
        "realName": "Guymon",
        "country": "USA (OK)",
        "x": "-24243",
        "z": "12150.3"
    },
    {
        "realName": "Guymon",
        "country": "USA (KS)",
        "x": "-24243",
        "z": "12150.3"
    },
    {
        "realName": "Hamburg",
        "country": "USA (AR)",
        "x": "19855.1",
        "z": "32363.9"
    },
    {
        "realName": "Hamburg",
        "country": "USA (LA)",
        "x": "19055.1",
        "z": "33363.9"
    },
    {
        "realName": "Hannibal",
        "country": "USA (MO)",
        "x": "19841.1",
        "z": "-4531.3"
    },
    {
        "realName": "Hannibal",
        "country": "USA (MO)",
        "x": "19841.1",
        "z": "-7531.3"
    },
    {
        "realName": "Harrison",
        "country": "USA (AR)",
        "x": "14616.1",
        "z": "15740.4"
    },
    {
        "realName": "Harrison",
        "country": "USA (AR)",
        "x": "13116.1",
        "z": "13940.4"
    },
    {
        "realName": "Havre",
        "country": "USA (MT)",
        "x": "-53179.6",
        "z": "-57026.8"
    },
    {
        "realName": "Hays",
        "country": "USA (KS)",
        "x": "-14594.3",
        "z": "1119.61"
    },
    {
        "realName": "Hebron",
        "country": "USA (NE)",
        "x": "-7040.66",
        "z": "-7196.19"
    },
    {
        "realName": "Hebron",
        "country": "USA (KS)",
        "x": "-7040.66",
        "z": "-6596.19"
    },
    {
        "realName": "Helena",
        "country": "USA (MT)",
        "x": "-61403.9",
        "z": "-49728.7"
    },
    {
        "realName": "Hillcrest",
        "country": "USA (CA)",
        "x": "-106360",
        "z": "-26962.8"
    },
    {
        "realName": "Hilt",
        "country": "USA (OR)",
        "x": "-110151",
        "z": "-30511"
    },
    {
        "realName": "Hobbs",
        "country": "USA (NM)",
        "x": "-33734.9",
        "z": "33858.8"
    },
    {
        "realName": "Hobbs",
        "country": "USA (NM)",
        "x": "-33734.9",
        "z": "33858.8"
    },
    {
        "realName": "Hot Springs",
        "country": "USA (AR)",
        "x": "13276.4",
        "z": "24247.1"
    },
    {
        "realName": "Hot Springs",
        "country": "USA (AR)",
        "x": "16276.4",
        "z": "24247.1"
    },
    {
        "realName": "Houston",
        "country": "USA (TX)",
        "x": "2575.22",
        "z": "52629.5"
    },
    {
        "realName": "Huntsville",
        "country": "USA (TX)",
        "x": "1132.03",
        "z": "45913.7"
    },
    {
        "realName": "Huron",
        "country": "USA (CA)",
        "x": "-108146",
        "z": "1737.38"
    },
    {
        "realName": "Hutchinson",
        "country": "USA (KS)",
        "x": "-9413.49",
        "z": "4985.48"
    },
    {
        "realName": "Hutchinson",
        "country": "USA (KS)",
        "x": "-9413.49",
        "z": "4985.48"
    },
    {
        "realName": "Hyannis",
        "country": "USA (NE)",
        "x": "-24200.3",
        "z": "-17655.9"
    },
    {
        "realName": "Idabel",
        "country": "USA (OK)",
        "x": "5238.44",
        "z": "27563.8"
    },
    {
        "realName": "Idabel",
        "country": "USA (TX)",
        "x": "5238.44",
        "z": "27563.8"
    },
    {
        "realName": "Idaho Falls",
        "country": "USA (ID)",
        "x": "-65859.8",
        "z": "-31584.5"
    },
    {
        "realName": "Indio",
        "country": "USA (CA)",
        "x": "-93764.8",
        "z": "19623.9"
    },
    {
        "realName": "Jackson",
        "country": "USA (WY)",
        "x": "-58060.3",
        "z": "-31351.6"
    },
    {
        "realName": "Jefferson City",
        "country": "USA (MO)",
        "x": "17008.3",
        "z": "2437.67"
    },
    {
        "realName": "John Day",
        "country": "USA (OR)",
        "x": "-91674.1",
        "z": "-42358.9"
    },
    {
        "realName": "Jonesboro",
        "country": "USA (AR)",
        "x": "23995.3",
        "z": "16592.9"
    },
    {
        "realName": "Joplin",
        "country": "USA (MO)",
        "x": "7068.35",
        "z": "11367.4"
    },
    {
        "realName": "Jordan",
        "country": "USA (MT)",
        "x": "-41930.1",
        "z": "-49571.2"
    },
    {
        "realName": "Junction",
        "country": "USA (TX)",
        "x": "-18677.4",
        "z": "48348.2"
    },
    {
        "realName": "Junction City",
        "country": "USA (KS)",
        "x": "-4005.22",
        "z": "-766.828"
    },
    {
        "realName": "Kalispell",
        "country": "USA (MT)",
        "x": "-68691.6",
        "z": "-59999.2"
    },
    {
        "realName": "Kanab",
        "country": "USA (UT)",
        "x": "-73451.6",
        "z": "3938.74"
    },
    {
        "realName": "770 KATL",
        "country": "USA (MT)",
        "x": "-38197.5",
        "z": "-45381.5"
    },
    {
        "realName": "Kayenta",
        "country": "USA (AZ)",
        "x": "-64177",
        "z": "7337.55"
    },
    {
        "realName": "Kansas City",
        "country": "USA (MO)",
        "x": "6693.1",
        "z": "-114.828"
    },
    {
        "realName": "Kansas City",
        "country": "USA (MO)",
        "x": "10362.9",
        "z": "-1470.25"
    },
    {
        "realName": "Kennewick",
        "country": "USA (WA)",
        "x": "-89029.3",
        "z": "-53557.5"
    },
    {
        "realName": "Kerrville",
        "country": "USA (TX)",
        "x": "-14615.3",
        "z": "50527.9"
    },
    {
        "realName": "Ketchum",
        "country": "USA (ID)",
        "x": "-73985.5",
        "z": "-34851.1"
    },
    {
        "realName": "Kingman",
        "country": "USA (AZ)",
        "x": "-80255.8",
        "z": "13606.3"
    },
    {
        "realName": "Kirksville",
        "country": "USA (MO)",
        "x": "14876.6",
        "z": "-6523.64"
    },
    {
        "realName": "Klamath Falls",
        "country": "USA (OR)",
        "x": "-104728",
        "z": "-34541.4"
    },
    {
        "realName": "Lakeview",
        "country": "USA (OR)",
        "x": "-100861",
        "z": "-30060.6"
    },
    {
        "realName": "Langtry",
        "country": "USA (TX)",
        "x": "-29560.3",
        "z": "51154.9"
    },
    {
        "realName": "Lamar",
        "country": "USA (CO)",
        "x": "-29205.3",
        "z": "3966.89"
    },
    {
        "realName": "Laramie",
        "country": "USA (WY)",
        "x": "-41711.4",
        "z": "-17557"
    },
    {
        "realName": "Laredo",
        "country": "USA (TX)",
        "x": "-18130.7",
        "z": "64101.5"
    },
    {
        "realName": "Las Vegas",
        "country": "USA (NV)",
        "x": "-85816.2",
        "z": "5816.68"
    },
    {
        "realName": "South Las Vegas",
        "country": "USA (NV)",
        "x": "-82931.7",
        "z": "10694.9"
    },
    {
        "realName": "Las Cruces",
        "country": "USA (NM)",
        "x": "-51219.6",
        "z": "33813.9"
    },
    {
        "realName": "Las Cruces",
        "country": "USA (NM)",
        "x": "-53910.3",
        "z": "34933.2"
    },
    {
        "realName": "Las Cruces",
        "country": "USA (NM)",
        "x": "-52376.3",
        "z": "35211.9"
    },
    {
        "realName": "Las Cruces",
        "country": "USA (NM)",
        "x": "-50763",
        "z": "35806.7"
    },
    {
        "realName": "Las Cruces",
        "country": "USA (TX)",
        "x": "-51219.6",
        "z": "33813.9"
    },
    {
        "realName": "Lawton",
        "country": "USA (OK)",
        "x": "-11049.4",
        "z": "23392.7"
    },
    {
        "realName": "Lee Vining",
        "country": "USA (CA)",
        "x": "-100992",
        "z": "-7469.51"
    },
    {
        "realName": "Lewiston",
        "country": "USA (ID)",
        "x": "-80795.7",
        "z": "-51559.7"
    },
    {
        "realName": "Lewistown",
        "country": "USA (MT)",
        "x": "-51777.8",
        "z": "-49878.1"
    },
    {
        "realName": "Lincoln",
        "country": "USA (MT)",
        "x": "-64169.8",
        "z": "-53153.1"
    },
    {
        "realName": "Lincoln",
        "country": "USA (NE)",
        "x": "-3768.03",
        "z": "-10183.7"
    },
    {
        "realName": "Little Rock",
        "country": "USA (AR)",
        "x": "18708.1",
        "z": "22284.6"
    },
    {
        "realName": "Logan",
        "country": "USA (UT)",
        "x": "-67620.3",
        "z": "-23411.3"
    },
    {
        "realName": "Longview",
        "country": "USA (WA)",
        "x": "-103165",
        "z": "-57231.5"
    },
    {
        "realName": "Longview",
        "country": "USA (OR)",
        "x": "-103165",
        "z": "-57231.5"
    },
    {
        "realName": "Los Angeles",
        "country": "USA (CA)",
        "x": "-103281",
        "z": "16218.6"
    },
    {
        "realName": "South Lake Tahoe",
        "country": "USA (CA)",
        "x": "-105692",
        "z": "-10812.2"
    },
    {
        "realName": "South Lake Tahoe",
        "country": "USA (NV)",
        "x": "-105692",
        "z": "-10812.2"
    },
    {
        "realName": "Lubbock",
        "country": "USA (TX)",
        "x": "-27321",
        "z": "30001.9"
    },
    {
        "realName": "Ludlow",
        "country": "USA (CA)",
        "x": "-90423.7",
        "z": "14670.1"
    },
    {
        "realName": "Ludlow",
        "country": "USA (CA)",
        "x": "-92712.4",
        "z": "13970.1"
    },
    {
        "realName": "Lufkin",
        "country": "USA (TX)",
        "x": "5703.92",
        "z": "42729.5"
    },
    {
        "realName": "Lusk",
        "country": "USA (WY)",
        "x": "-34607.7",
        "z": "-23037.9"
    },
    {
        "realName": "Malta",
        "country": "USA (MT)",
        "x": "-46872.8",
        "z": "-55913.4"
    },
    {
        "realName": "Mankato",
        "country": "USA (KS)",
        "x": "-9676.41",
        "z": "-4568.5"
    },
    {
        "realName": "Marathon",
        "country": "USA (TX)",
        "x": "-34935.6",
        "z": "50479.4"
    },
    {
        "realName": "Marfa",
        "country": "USA (TX)",
        "x": "-38922.9",
        "z": "47888.4"
    },
    {
        "realName": "Marfa",
        "country": "USA (TX)",
        "x": "-38922.9",
        "z": "47888.4"
    },
    {
        "realName": "Maryville",
        "country": "USA (MO)",
        "x": "5488.47",
        "z": "-8524.48"
    },
    {
        "realName": "Marysville",
        "country": "USA (KS)",
        "x": "-2604.68",
        "z": "-4706.35"
    },
    {
        "realName": "Mason City",
        "country": "USA (IA)",
        "x": "11989.4",
        "z": "-23640"
    },
    {
        "realName": "McAlester",
        "country": "USA (OK)",
        "x": "1094.81",
        "z": "22901.7"
    },
    {
        "realName": "Rio Grande Valley",
        "country": "USA (TX)",
        "x": "-10372.3",
        "z": "74038.6"
    },
    {
        "realName": "McCall",
        "country": "USA (ID)",
        "x": "-79313.3",
        "z": "-42465"
    },
    {
        "realName": "McCamey",
        "country": "USA (TX)",
        "x": "-29335.4",
        "z": "43554.9"
    },
    {
        "realName": "McCook",
        "country": "USA (NE)",
        "x": "-19839.3",
        "z": "-7176.68"
    },
    {
        "realName": "McDermitt",
        "country": "USA (NV)",
        "x": "-89641.8",
        "z": "-28539.1"
    },
    {
        "realName": "Medford",
        "country": "USA (OR)",
        "x": "-110683",
        "z": "-35739.2"
    },
    {
        "realName": "Merriman",
        "country": "USA (NE)",
        "x": "-23476.4",
        "z": "-22963.8"
    },
    {
        "realName": "Midland",
        "country": "USA (TX)",
        "x": "-28095.9",
        "z": "37941.6"
    },
    {
        "realName": "Miles City",
        "country": "USA (MT)",
        "x": "-38197.5",
        "z": "-45381.5"
    },
    {
        "realName": "Miles City",
        "country": "USA (MT)",
        "x": "-38197.5",
        "z": "-45381.5"
    },
    {
        "realName": "Missoula",
        "country": "USA (MT)",
        "x": "-69914.2",
        "z": "-51575.5"
    },
    {
        "realName": "Moab",
        "country": "USA (UT)",
        "x": "-59408.7",
        "z": "-1841.51"
    },
    {
        "realName": "Moab",
        "country": "USA (UT)",
        "x": "-59408.7",
        "z": "-1841.51"
    },
    {
        "realName": "Moab",
        "country": "USA (UT)",
        "x": "-59408.7",
        "z": "-1841.51"
    },
    {
        "realName": "Modesto",
        "country": "USA (CA)",
        "x": "-108318",
        "z": "-5370.46"
    },
    {
        "realName": "Mojave",
        "country": "USA (CA)",
        "x": "-101533",
        "z": "10744.1"
    },
    {
        "realName": "Monterey",
        "country": "USA (CA)",
        "x": "-115647",
        "z": "-1109.71"
    },
    {
        "realName": "Monticello",
        "country": "USA (UT)",
        "x": "-58701.8",
        "z": "1743"
    },
    {
        "realName": "Monticello",
        "country": "USA (UT)",
        "x": "-58701.8",
        "z": "1743"
    },
    {
        "realName": "Montpelier",
        "country": "USA (ID)",
        "x": "-62548.9",
        "z": "-23269.8"
    },
    {
        "realName": "Mountain Home",
        "country": "USA (AR)",
        "x": "17033.3",
        "z": "14618.9"
    },
    {
        "realName": "Needles",
        "country": "USA (CA)",
        "x": "-85257.7",
        "z": "14889.6"
    },
    {
        "realName": "Needles",
        "country": "USA (AZ)",
        "x": "-85257.7",
        "z": "14889.6"
    },
    {
        "realName": "Neodesha",
        "country": "USA (KS)",
        "x": "1600.7",
        "z": "9024.61"
    },
    {
        "realName": "Newport",
        "country": "USA (OR)",
        "x": "-112428",
        "z": "-49031.1"
    },
    {
        "realName": "Norfolk",
        "country": "USA (NE)",
        "x": "-6215.09",
        "z": "-17418.2"
    },
    {
        "realName": "North Platte",
        "country": "USA (NE)",
        "x": "-20265.6",
        "z": "-12950.8"
    },
    {
        "realName": "Odessa",
        "country": "USA (TX)",
        "x": "-31048.6",
        "z": "39292.8"
    },
    {
        "realName": "Oklahoma City",
        "country": "USA (OK)",
        "x": "-7446.37",
        "z": "18443.3"
    },
    {
        "realName": "Olympia",
        "country": "USA (WA)",
        "x": "-103161",
        "z": "-61813"
    },
    {
        "realName": "Olympia",
        "country": "USA (WA)",
        "x": "-103161",
        "z": "-61813"
    },
    {
        "realName": "Ogallala",
        "country": "USA (NE)",
        "x": "-25219.9",
        "z": "-12820"
    },
    {
        "realName": "Omaha",
        "country": "USA (NE)",
        "x": "382.242",
        "z": "-12617.8"
    },
    {
        "realName": "Omak",
        "country": "USA (WA)",
        "x": "-89594.8",
        "z": "-64462"
    },
    {
        "realName": "O'Neill",
        "country": "USA (NE)",
        "x": "-11409.6",
        "z": "-19863.6"
    },
    {
        "realName": "Osage Beach",
        "country": "USA (MO)",
        "x": "15169.5",
        "z": "3829.92"
    },
    {
        "realName": "Oskaloosa",
        "country": "USA (IA)",
        "x": "14412.6",
        "z": "-14084.6"
    },
    {
        "realName": "Ottumwa",
        "country": "USA (IA)",
        "x": "15641",
        "z": "-11374"
    },
    {
        "realName": "Ouray",
        "country": "USA (CO)",
        "x": "-51932",
        "z": "1738.21"
    },
    {
        "realName": "Oxnard",
        "country": "USA (CA)",
        "x": "-108859",
        "z": "12807.6"
    },
    {
        "realName": "Ozona",
        "country": "USA (TX)",
        "x": "-24814.7",
        "z": "46422.9"
    },
    {
        "realName": "Page",
        "country": "USA (AZ)",
        "x": "-69181.3",
        "z": "5521.9"
    },
    {
        "realName": "Palacios",
        "country": "USA (TX)",
        "x": "-511.372",
        "z": "58588.3"
    },
    {
        "realName": "Palm Springs",
        "country": "USA (CA)",
        "x": "-96082.8",
        "z": "17375.5"
    },
    {
        "realName": "Paris",
        "country": "USA (TX)",
        "x": "2250.92",
        "z": "29384.3"
    },
    {
        "realName": "Pecos",
        "country": "USA (TX)",
        "x": "-34816.8",
        "z": "40362.8"
    },
    {
        "realName": "Pendleton",
        "country": "USA (WA)",
        "x": "-90510.3",
        "z": "-47812.9"
    },
    {
        "realName": "Phillipsburg",
        "country": "USA (KS)",
        "x": "-14624.9",
        "z": "-4813.45"
    },
    {
        "realName": "Phoenix",
        "country": "USA (AZ)",
        "x": "-75196.4",
        "z": "24257.7"
    },
    {
        "realName": "Pine Bluff",
        "country": "USA (AR)",
        "x": "20436.1",
        "z": "26065.1"
    },
    {
        "realName": "Pioche",
        "country": "USA (NV)",
        "x": "-80956.8",
        "z": "-4638.39"
    },
    {
        "realName": "Pittsburg",
        "country": "USA (MO)",
        "x": "5682.23",
        "z": "8593.65"
    },
    {
        "realName": "Pocatello",
        "country": "USA (ID)",
        "x": "-68356.2",
        "z": "-27970.9"
    },
    {
        "realName": "Poplar Bluff",
        "country": "USA (MO)",
        "x": "25327",
        "z": "12544.5"
    },
    {
        "realName": "Port Angeles",
        "country": "USA (WA)",
        "x": "-104688",
        "z": "-67597.6"
    },
    {
        "realName": "Portland",
        "country": "USA (OR)",
        "x": "-104350",
        "z": "-51491.9"
    },
    {
        "realName": "Postville",
        "country": "USA (IA)",
        "x": "18229.9",
        "z": "-23460.5"
    },
    {
        "realName": "Price",
        "country": "USA (UT)",
        "x": "-62580.7",
        "z": "-9222.07"
    },
    {
        "realName": "Prescott",
        "country": "USA (AZ)",
        "x": "-76411.6",
        "z": "18355.9"
    },
    {
        "realName": "Prescott",
        "country": "USA (AZ)",
        "x": "-76411.6",
        "z": "18355.9"
    },
    {
        "realName": "Prescott",
        "country": "USA (AZ)",
        "x": "-76411.6",
        "z": "18355.9"
    },
    {
        "realName": "North Arizona",
        "country": "USA (AZ)",
        "x": "-74411.6",
        "z": "18255.9"
    },
    {
        "realName": "Phoenix",
        "country": "USA (AZ)",
        "x": "-75411.6",
        "z": "20355.9"
    },
    {
        "realName": "Prescott",
        "country": "USA (AR)",
        "x": "13246.9",
        "z": "27396"
    },
    {
        "realName": "Prescott",
        "country": "USA (AR)",
        "x": "13946.9",
        "z": "26896"
    },
    {
        "realName": "Presidio",
        "country": "Mexique (XX)",
        "x": "-39989.5",
        "z": "51575.1"
    },
    {
        "realName": "Princeton",
        "country": "USA (MO)",
        "x": "12466.2",
        "z": "-8722.28"
    },
    {
        "realName": "Quad Cities",
        "country": "USA (IA)",
        "x": "21354.2",
        "z": "-15424.5"
    },
    {
        "realName": "Quemado",
        "country": "USA (NM)",
        "x": "-57853",
        "z": "22342.4"
    },
    {
        "realName": "Rachel",
        "country": "USA (NV)",
        "x": "-87034.5",
        "z": "-1783.4"
    },
    {
        "realName": "Rangely",
        "country": "USA (CO)",
        "x": "-54094.8",
        "z": "-9396.7"
    },
    {
        "realName": "Red Bluff",
        "country": "USA (CA)",
        "x": "-112992",
        "z": "-20492.6"
    },
    {
        "realName": "Red Cloud",
        "country": "USA (NE)",
        "x": "-11109.8",
        "z": "-6343.74"
    },
    {
        "realName": "Redding",
        "country": "USA (CA)",
        "x": "-110950",
        "z": "-24872.1"
    },
    {
        "realName": "Redding",
        "country": "USA (CA)",
        "x": "-110950",
        "z": "-24872.1"
    },
    {
        "realName": "Reno",
        "country": "USA (NV)",
        "x": "-99918.2",
        "z": "-18717.4"
    },
    {
        "realName": "Republic",
        "country": "USA (WA)",
        "x": "-85366",
        "z": "-63851"
    },
    {
        "realName": "Ridgecrest",
        "country": "USA (CA)",
        "x": "-98773.3",
        "z": "6136.26"
    },
    {
        "realName": "Riverside",
        "country": "USA (CA)",
        "x": "-99043.6",
        "z": "17999.1"
    },
    {
        "realName": "Riverton",
        "country": "USA (WY)",
        "x": "-50587.1",
        "z": "-27268.7"
    },
    {
        "realName": "Raton",
        "country": "USA (NM)",
        "x": "-38146.3",
        "z": "10209.8"
    },
    {
        "realName": "Rawlins",
        "country": "USA (WY)",
        "x": "-47429.8",
        "z": "-20265"
    },
    {
        "realName": "Rock Springs",
        "country": "USA (WY)",
        "x": "-53904.7",
        "z": "-18853.2"
    },
    {
        "realName": "Rolla",
        "country": "USA (MO)",
        "x": "19098",
        "z": "5746.81"
    },
    {
        "realName": "Roswell",
        "country": "USA (NM)",
        "x": "-39713.4",
        "z": "29859.5"
    },
    {
        "realName": "Roswell",
        "country": "USA (NM)",
        "x": "-39713.4",
        "z": "29859.5"
    },
    {
        "realName": "Russelville",
        "country": "USA (AR)",
        "x": "14084.8",
        "z": "18646.2"
    },
    {
        "realName": "Sac City",
        "country": "USA (IA)",
        "x": "3967.15",
        "z": "-19663"
    },
    {
        "realName": "Sacramento",
        "country": "USA (CA)",
        "x": "-109920",
        "z": "-14095.8"
    },
    {
        "realName": "Colusa",
        "country": "USA (CA)",
        "x": "-112214",
        "z": "-17201.1"
    },
    {
        "realName": "Colusa",
        "country": "USA (CA)",
        "x": "-112214",
        "z": "-17201.1"
    },
    {
        "realName": "Sacramento",
        "country": "USA (CA)",
        "x": "-109545",
        "z": "-18580.3"
    },
    {
        "realName": "Sacramento",
        "country": "USA (CA)",
        "x": "-109814",
        "z": "-11257.7"
    },
    {
        "realName": "Salida",
        "country": "USA (CO)",
        "x": "-44653.8",
        "z": "127.839"
    },
    {
        "realName": "Salmon",
        "country": "USA (ID)",
        "x": "-71060.2",
        "z": "-42379.9"
    },
    {
        "realName": "Salina",
        "country": "USA (KS)",
        "x": "-8136.89",
        "z": "1182.27"
    },
    {
        "realName": "Salina",
        "country": "USA (UT)",
        "x": "-68567.1",
        "z": "-6747.52"
    },
    {
        "realName": "Salinas",
        "country": "USA (CA)",
        "x": "-114540",
        "z": "-2404.439"
    },
    {
        "realName": "Salt Lake City",
        "country": "USA (UT)",
        "x": "-68092",
        "z": "-16343.5"
    },
    {
        "realName": "San Angelo",
        "country": "USA (TX)",
        "x": "-20629.6",
        "z": "42453.9"
    },
    {
        "realName": "San Antonio",
        "country": "USA (TX)",
        "x": "-12756.9",
        "z": "54107.3"
    },
    {
        "realName": "San Antonio",
        "country": "USA (TX)",
        "x": "-14236.6",
        "z": "58524.7"
    },
    {
        "realName": "San Diego/Tijuana",
        "country": "USA (CA)",
        "x": "-98862.2",
        "z": "24029.7"
    },
    {
        "realName": "Sandpoint",
        "country": "USA (ID)",
        "x": "-76528.2",
        "z": "-63044.7"
    },
    {
        "realName": "Sandpoint",
        "country": "USA (WA)",
        "x": "-76528.2",
        "z": "-63044.7"
    },
    {
        "realName": "San Francisco",
        "country": "USA (CA)",
        "x": "-116267",
        "z": "-10076.9"
    },
    {
        "realName": "San Jose",
        "country": "USA (CA)",
        "x": "-113764",
        "z": "-6003.07"
    },
    {
        "realName": "San Simon",
        "country": "USA (AZ)",
        "x": "-62119.2",
        "z": "33562"
    },
    {
        "realName": "Santa Fe",
        "country": "USA (NM)",
        "x": "-44752.1",
        "z": "16062.1"
    },
    {
        "realName": "Santa Fe",
        "country": "USA (NM)",
        "x": "-44752.1",
        "z": "16062.1"
    },
    {
        "realName": "Santa Maria",
        "country": "USA (CA)",
        "x": "-112374",
        "z": "7463.42"
    },
    {
        "realName": "Santa Rosa",
        "country": "USA (CA)",
        "x": "-117954",
        "z": "-16022.9"
    },
    {
        "realName": "Santa Rosa",
        "country": "USA (NM)",
        "x": "-39338.3",
        "z": "21093.7"
    },
    {
        "realName": "Schulenburg",
        "country": "USA (TX)",
        "x": "-4574.02",
        "z": "52492.1"
    },
    {
        "realName": "Scottsbluff",
        "country": "USA (NE)",
        "x": "-32898",
        "z": "-19348.7"
    },
    {
        "realName": "Scottsbluff",
        "country": "USA (NE)",
        "x": "-32898",
        "z": "-19348.7"
    },
    {
        "realName": "Seattle",
        "country": "USA (WA)",
        "x": "-97690.4",
        "z": "-63065.2"
    },
    {
        "realName": "Sedalia",
        "country": "USA (MO)",
        "x": "12342.6",
        "z": "1465.22"
    },
    {
        "realName": "Shamrock",
        "country": "USA (TX)",
        "x": "-20004.5",
        "z": "20673.4"
    },
    {
        "realName": "Shamrock",
        "country": "USA (OK)",
        "x": "-20004.5",
        "z": "20673.4"
    },
    {
        "realName": "Shelby",
        "country": "USA (MT)",
        "x": "-59648.5",
        "z": "-61213.5"
    },
    {
        "realName": "Sheldon",
        "country": "USA (IA)",
        "x": "799.534",
        "z": "-23803.5"
    },
    {
        "realName": "Sheridan",
        "country": "USA (WY)",
        "x": "-42261.8",
        "z": "-35202.9"
    },
    {
        "realName": "Show Low",
        "country": "USA (AZ)",
        "x": "-65151",
        "z": "21330.9"
    },
    {
        "realName": "Sidney",
        "country": "USA (NE)",
        "x": "-29880.5",
        "z": "-14527.6"
    },
    {
        "realName": "Sierra Vista",
        "country": "USA (AZ)",
        "x": "-68525.5",
        "z": "36654"
    },
    {
        "realName": "Sioux City",
        "country": "USA (IA)",
        "x": "-1510.61",
        "z": "-19097.7"
    },
    {
        "realName": "Socorro",
        "country": "USA (NM)",
        "x": "-52010.1",
        "z": "25677.1"
    },
    {
        "realName": "South Utah",
        "country": "USA (UT)",
        "x": "-58701.8",
        "z": "1743"
    },
    {
        "realName": "Spencer",
        "country": "USA (IA)",
        "x": "3896.49",
        "z": "-23655.2"
    },
    {
        "realName": "Spokane",
        "country": "USA (WA)",
        "x": "-81652.4",
        "z": "-58561.8"
    },
    {
        "realName": "Springfield",
        "country": "USA (MO)",
        "x": "12754.8",
        "z": "9791.22"
    },
    {
        "realName": "Springfield",
        "country": "USA (AR)",
        "x": "12754.8",
        "z": "9791.22"
    },
    {
        "realName": "Susanville",
        "country": "USA (CA)",
        "x": "-106334",
        "z": "-21803.6"
    },
    {
        "realName": "Steamboat Springs",
        "country": "USA (CO)",
        "x": "-46238.9",
        "z": "-11100.9"
    },
    {
        "realName": "Stephenville",
        "country": "USA (TX)",
        "x": "-10991.5",
        "z": "38021.7"
    },
    {
        "realName": "Sterling",
        "country": "USA (CO)",
        "x": "-32170.9",
        "z": "-10118.3"
    },
    {
        "realName": "St. George",
        "country": "USA (UT)",
        "x": "-78856.8",
        "z": "3000.27"
    },
    {
        "realName": "Saint John",
        "country": "USA (KS)",
        "x": "-12390.6",
        "z": "6328.88"
    },
    {
        "realName": "St. Joseph",
        "country": "USA (MO)",
        "x": "4320.43",
        "z": "-4234.05"
    },
    {
        "realName": "St. Joseph",
        "country": "USA (MO)",
        "x": "4544.22",
        "z": "-4752.35"
    },
    {
        "realName": "St. Joseph",
        "country": "USA (MO)",
        "x": "4544.22",
        "z": "-4752.35"
    },
    {
        "realName": "St. Louis",
        "country": "USA (MO)",
        "x": "25707.9",
        "z": "1361.86"
    },
    {
        "realName": "Stockton",
        "country": "USA (CA)",
        "x": "-109402",
        "z": "-9359.29"
    },
    {
        "realName": "Sweetwater",
        "country": "USA (TX)",
        "x": "-20670.4",
        "z": "36687.1"
    },
    {
        "realName": "Tacoma",
        "country": "USA (WA)",
        "x": "-100595",
        "z": "-60834.9"
    },
    {
        "realName": "Tacoma",
        "country": "USA (WA)",
        "x": "-100595",
        "z": "-60834.9"
    },
    {
        "realName": "Texarkana",
        "country": "USA (TX)",
        "x": "9446.33",
        "z": "31127"
    },
    {
        "realName": "The Dalles",
        "country": "USA (OR)",
        "x": "-96967.8",
        "z": "-50162.2"
    },
    {
        "realName": "Thedford",
        "country": "USA (NE)",
        "x": "-19709.7",
        "z": "-17464"
    },
    {
        "realName": "Tierra Amarilla",
        "country": "USA (NM)",
        "x": "-47359.9",
        "z": "10267"
    },
    {
        "realName": "Tonopah",
        "country": "USA (NV)",
        "x": "-92209.5",
        "z": "-4832.38"
    },
    {
        "realName": "Topeka",
        "country": "USA (KS)",
        "x": "603.289",
        "z": "376.1289"
    },
    {
        "realName": "Topeka",
        "country": "USA (KS)",
        "x": "2603.289",
        "z": "176.1289"
    },
    {
        "realName": "Topeka",
        "country": "USA (KS)",
        "x": "1303.289",
        "z": "-476.1289"
    },
    {
        "realName": "Topeka",
        "country": "USA (KS)",
        "x": "1303.289",
        "z": "-476.1289"
    },
    {
        "realName": "Topeka",
        "country": "USA (KS)",
        "x": "1303.289",
        "z": "-476.1289"
    },
    {
        "realName": "Truckee",
        "country": "USA (CA)",
        "x": "-105818",
        "z": "-17000.3"
    },
    {
        "realName": "Truckee",
        "country": "USA (NV)",
        "x": "-105818",
        "z": "-17000.3"
    },
    {
        "realName": "Truth or Consequences",
        "country": "USA (NM)",
        "x": "-52987.3",
        "z": "29697.8"
    },
    {
        "realName": "Tuba City",
        "country": "USA (AZ)",
        "x": "-68471.1",
        "z": "9649.17"
    },
    {
        "realName": "Tucson",
        "country": "USA (AZ)",
        "x": "-71749.5",
        "z": "32610.5"
    },
    {
        "realName": "Tulsa",
        "country": "USA (OK)",
        "x": "-59.2364",
        "z": "15322.7"
    },
    {
        "realName": "Twin Falls",
        "country": "USA (ID)",
        "x": "-75516.3",
        "z": "-27484.9"
    },
    {
        "realName": "Tyler",
        "country": "USA (TX)",
        "x": "3338.86",
        "z": "37689.5"
    },
    {
        "realName": "Ukiah",
        "country": "USA (CA)",
        "x": "-119005",
        "z": "-20503.9"
    },
    {
        "realName": "Uvalde",
        "country": "USA (TX)",
        "x": "-18954",
        "z": "53580"
    },
    {
        "realName": "Valentine",
        "country": "USA (NE)",
        "x": "-19012.4",
        "z": "-22342.2"
    },
    {
        "realName": "Van Horn",
        "country": "USA (TX)",
        "x": "-42493.9",
        "z": "44906.2"
    },
    {
        "realName": "Vernal",
        "country": "USA (UT)",
        "x": "-57321.6",
        "z": "-12804.7"
    },
    {
        "realName": "Victoria",
        "country": "USA (TX)",
        "x": "-5242.46",
        "z": "57336.1"
    },
    {
        "realName": "Victorville",
        "country": "USA (CA)",
        "x": "-98494.6",
        "z": "15237.6"
    },
    {
        "realName": "Waco",
        "country": "USA (TX)",
        "x": "-5465.2",
        "z": "42150.9"
    },
    {
        "realName": "WaKeeney",
        "country": "USA (KS)",
        "x": "-17524.2",
        "z": "-567.434"
    },
    {
        "realName": "Wallace",
        "country": "USA (WA)",
        "x": "-76900.3",
        "z": "-55897.9"
    },
    {
        "realName": "Wallace",
        "country": "USA (MT)",
        "x": "-73500.3",
        "z": "-53897.9"
    },
    {
        "realName": "Waterloo",
        "country": "USA (IA)",
        "x": "14722",
        "z": "-20366.8"
    },
    {
        "realName": "Wenatchee",
        "country": "USA (WA)",
        "x": "-92417.7",
        "z": "-60054.8"
    },
    {
        "realName": "West Yellowstone",
        "country": "USA (MT)",
        "x": "-59029.6",
        "z": "-37340.4"
    },
    {
        "realName": "Wheatland",
        "country": "USA (WY)",
        "x": "-36817.5",
        "z": "-20075.8"
    },
    {
        "realName": "Wheatland",
        "country": "USA (NE)",
        "x": "-35017.5",
        "z": "-20075.8"
    },
    {
        "realName": "Wichita",
        "country": "USA (KS)",
        "x": "-6677.27",
        "z": "7352.23"
    },
    {
        "realName": "Wichita Falls",
        "country": "USA (TX)",
        "x": "-11670.6",
        "z": "29060.8"
    },
    {
        "realName": "Winnemucca",
        "country": "USA (NV)",
        "x": "-91334.8",
        "z": "-22075.4"
    },
    {
        "realName": "Willow Springs",
        "country": "USA (MO)",
        "x": "19635.9",
        "z": "11553.7"
    },
    {
        "realName": "Wolf Point",
        "country": "USA (MT)",
        "x": "-36778.1",
        "z": "-53491"
    },
    {
        "realName": "Woodward",
        "country": "USA (OK)",
        "x": "-15953.3",
        "z": "13959.5"
    },
    {
        "realName": "Wray",
        "country": "USA (CO)",
        "x": "-26846.6",
        "z": "-7087.33"
    },
    {
        "realName": "Yakima",
        "country": "USA (WA)",
        "x": "-95722.7",
        "z": "-55991.9"
    },
    {
        "realName": "Yuma",
        "country": "USA (AZ)",
        "x": "-87619.4",
        "z": "27086.4"
    },
    {
        "realName": "Zapata",
        "country": "USA (TX)",
        "x": "-16817",
        "z": "69694"
    },
];


var cities_mexique = [
  {
    "realName": "Acaponeta",
    "country": "Mexique (NAY)",
    "x": "-49634.9",
    "z": "92334.3"
  },
  {
    "realName": "Aguascalientes",
    "country": "Mexique (AGU)",
    "x": "-34084.9",
    "z": "97712.8"
  },
  {
    "realName": "Agua Prieta",
    "country": "Mexique (SON)",
    "x": "-65394.4",
    "z": "39217.9"
  },
  {
    "realName": "Juan Aldama",
    "country": "Mexique (CHH)",
    "x": "-48410.2",
    "z": "50661.1"
  },
  {
    "realName": "Arivechi",
    "country": "Mexique (SON)",
    "x": "-64595.3",
    "z": "49911.9"
  },
  {
    "realName": "Ascensión",
    "country": "Mexique (CHH)",
    "x": "-56361.9",
    "z": "42160.6"
  },
  {
    "realName": "Baja California Sur",
    "country": "Mexique (BCS)",
    "x": "-95133.8",
    "z": "54741.5"
  },
  {
    "realName": "Basaseachi",
    "country": "Mexique (CHH)",
    "x": "-61744.8",
    "z": "55995.1"
  },
  {
    "realName": "Batopilas",
    "country": "Mexique (CHH)",
    "x": "-60167.8",
    "z": "63194.3"
  },
  {
    "realName": "Bocoyna",
    "country": "Mexique (CHH)",
    "x": "-58843.1",
    "z": "58234.3"
  },
  {
    "realName": "San Buenaventura",
    "country": "Mexique (CHH)",
    "x": "-59363.8",
    "z": "48015.3"
  },
  {
    "realName": "Caborca",
    "country": "Mexique (SON)",
    "x": "-81887.7",
    "z": "37355.9"
  },
  {
    "realName": "Cabo San Lucas",
    "country": "Mexique (BCS)",
    "x": "-73303.8",
    "z": "87060.1"
  },
  {
    "realName": "Calvillo",
    "country": "Mexique (AGU)",
    "x": "-36306.9",
    "z": "98081.7"
  },
  {
    "realName": "Camargo",
    "country": "Mexique (CHH)",
    "x": "-46753.6",
    "z": "61959"
  },
  {
    "realName": "Camargo",
    "country": "Mexique (CHH)",
    "x": "-46753.6",
    "z": "61959"
  },
  {
    "realName": "Cananea",
    "country": "Mexique (SON)",
    "x": "-69120.9",
    "z": "40193.8"
  },
  {
    "realName": "Canatlán",
    "country": "Mexique (DUR)",
    "x": "-46551",
    "z": "80756.9"
  },
  {
    "realName": "Canelas",
    "country": "Mexique (DUR)",
    "x": "-52549.8",
    "z": "76837.7"
  },
  {
    "realName": "Ciudad Constitución",
    "country": "Mexique (BCS)",
    "x": "-81092.8",
    "z": "73674.7"
  },
  {
    "realName": "Cuauhtémoc",
    "country": "Mexique (CHH)",
    "x": "-56051.3",
    "z": "56136.4"
  },
  {
    "realName": "Ciudad Insurgentes",
    "country": "Mexique (BCS)",
    "x": "-85605.8",
    "z": "67951.1"
  },
  {
    "realName": "Ciudad Obregón",
    "country": "Mexique (SON)",
    "x": "-70636.1",
    "z": "61058.9"
  },
  {
    "realName": "Cedral",
    "country": "Mexique (SLP)",
    "x": "-24881.9",
    "z": "86722.1"
  },
  {
    "realName": "Cerritos",
    "country": "Mexique (SLP)",
    "x": "-21721.4",
    "z": "96150.3"
  },
  {
    "realName": "Charcas",
    "country": "Mexique (SLP)",
    "x": "-27185.1",
    "z": "90552.2"
  },
  {
    "realName": "Chihuahua",
    "country": "Mexique (CHH)",
    "x": "-52091.8",
    "z": "54247.2"
  },
  {
    "realName": "San Ciro de Acosta",
    "country": "Mexique (SLP)",
    "x": "-20907.8",
    "z": "100003"
  },
  {
    "realName": "Ciudad Coahuila",
    "country": "Mexique (BCN)",
    "x": "-88703.4",
    "z": "31551"
  },
  {
    "realName": "Ciudad Coahuila",
    "country": "USA (AZ)",
    "x": "-88703.4",
    "z": "31551"
  },
  {
    "realName": "Colotlán",
    "country": "Mexique (JLS)",
    "x": "-39521.7",
    "z": "95257.5"
  },
  {
    "realName": "Compostela",
    "country": "Mexique (NAY)",
    "x": "-47145.5",
    "z": "100437"
  },
  {
    "realName": "Concepción del Oro",
    "country": "Mexique (ZAC)",
    "x": "-28231.4",
    "z": "82038.7"
  },
  {
    "realName": "Cosalá",
    "country": "Mexique (SIN)",
    "x": "-55158",
    "z": "80503.4"
  },
  {
    "realName": "Cuencamé",
    "country": "Mexique (DUR)",
    "x": "-40048.1",
    "z": "79864.4"
  },
  {
    "realName": "Culiacán",
    "country": "Mexique (SIN)",
    "x": "-58924.2",
    "z": "76832"
  },
  {
    "realName": "Delicias",
    "country": "Mexique (CHH)",
    "x": "-48038.5",
    "z": "59106.5"
  },
  {
    "realName": "Ébano",
    "country": "Mexique (SLP)",
    "x": "-12719.3",
    "z": "96517.6"
  },
  {
    "realName": "El Naranjo",
    "country": "Mexique (SLP)",
    "x": "-15972",
    "z": "94750.5"
  },
  {
    "realName": "El Rosario",
    "country": "Mexique (BCN)",
    "x": "-96007.1",
    "z": "40800.4"
  },
  {
    "realName": "El Salto",
    "country": "Mexique (DUR)",
    "x": "-49104.3",
    "z": "84737.7"
  },
  {
    "realName": "Ensenada",
    "country": "Mexique (BCN)",
    "x": "-98139.2",
    "z": "32962.7"
  },
  {
    "realName": "Fresnillo",
    "country": "Mexique (ZAC)",
    "x": "-36298.9",
    "z": "89484.7"
  },
  {
    "realName": "Fresnillo",
    "country": "Mexique (ZAC)",
    "x": "-36298.9",
    "z": "89484.7"
  },
  {
    "realName": "Gómez Palacio",
    "country": "Mexique (DUR)",
    "x": "-38817.5",
    "z": "75478.9"
  },
  {
    "realName": "Guadalupe y Calvo",
    "country": "Mexique (CHH)",
    "x": "-55970.1",
    "z": "70551.4"
  },
  {
    "realName": "Guadalupe Victoria",
    "country": "Mexique (DUR)",
    "x": "-42041",
    "z": "81972.1"
  },
  {
    "realName": "Guachochi",
    "country": "Mexique (CHH)",
    "x": "-57713.7",
    "z": "66510.7"
  },
  {
    "realName": "Guamúchil",
    "country": "Mexique (SIN)",
    "x": "-61624.6",
    "z": "74681"
  },
  {
    "realName": "Guanaceví",
    "country": "Mexique (DUR)",
    "x": "-52316",
    "z": "72506.4"
  },
  {
    "realName": "Guasave",
    "country": "Mexique (SIN)",
    "x": "-64504.9",
    "z": "72909.2"
  },
  {
    "realName": "Guasave",
    "country": "Mexique (SIN)",
    "x": "-64504.9",
    "z": "72909.2"
  },
  {
    "realName": "Guaymas",
    "country": "Mexique (SIN)",
    "x": "-75161.3",
    "z": "56623.3"
  },
  {
    "realName": "Guerrero Negro",
    "country": "Mexique (BCS)",
    "x": "-90866.2",
    "z": "54339.1"
  },
  {
    "realName": "Hermosillo",
    "country": "Mexique (SON)",
    "x": "-73603.3",
    "z": "50492.1"
  },
  {
    "realName": "Huazamota",
    "country": "Mexique (DUR)",
    "x": "-45749",
    "z": "91863.7"
  },
  {
    "realName": "Huejuquilla",
    "country": "Mexique (JLS)",
    "x": "-41910.4",
    "z": "91370.9"
  },
  {
    "realName": "Heróica Nogales",
    "country": "Mexique (SON)",
    "x": "-72031.8",
    "z": "39032.1"
  },
  {
    "realName": "Illescas",
    "country": "Mexique (ZAC)",
    "x": "-31647.1",
    "z": "89753"
  },
  {
    "realName": "Jalpa",
    "country": "Mexique (ZAC)",
    "x": "-38033.5",
    "z": "99312.3"
  },
  {
    "realName": "Jerez de García Salinas",
    "country": "Mexique (ZAC)",
    "x": "-37503.1",
    "z": "93193.4"
  },
  {
    "realName": "Jesús María",
    "country": "Mexique (NAY)",
    "x": "-45786.7",
    "z": "93429.3"
  },
  {
    "realName": "Ciudad Jiménez",
    "country": "Mexique (CHH)",
    "x": "-45481.6",
    "z": "65762.4"
  },
  {
    "realName": "La Cruz",
    "country": "Mexique (SIN)",
    "x": "-56966.7",
    "z": "83215.3"
  },
  {
    "realName": "La Perla",
    "country": "Mexique (CHH)",
    "x": "-42553",
    "z": "58949.1"
  },
  {
    "realName": "La Paz",
    "country": "Mexique (BCS)",
    "x": "-74741.2",
    "z": "79135.7"
  },
  {
    "realName": "Loreto",
    "country": "Mexique (BCS)",
    "x": "-78850.3",
    "z": "68185.9"
  },
  {
    "realName": "Loreto",
    "country": "Mexique (BCS)",
    "x": "-78850.3",
    "z": "68185.9"
  },
  {
    "realName": "Los Barriles",
    "country": "Mexique (BCS)",
    "x": "-72301.5",
    "z": "81982.4"
  },
  {
    "realName": "Los Mochis",
    "country": "Mexique (SIN)",
    "x": "-67797",
    "z": "69818.5"
  },
  {
    "realName": "Magdalena de Kino",
    "country": "Mexique (SON)",
    "x": "-75137.9",
    "z": "43157.5"
  },
  {
    "realName": "Magdalena de Kino",
    "country": "Mexique (SON)",
    "x": "-75137.9",
    "z": "43157.5"
  },
  {
    "realName": "Ciudad del Maíz",
    "country": "Mexique (SLP)",
    "x": "-19190.1",
    "z": "95666.4"
  },
  {
    "realName": "Mapimí",
    "country": "Mexique (DUR)",
    "x": "-40751.6",
    "z": "73471.1"
  },
  {
    "realName": "Matehuala",
    "country": "Mexique (SLP)",
    "x": "-24749.5",
    "z": "87939.7"
  },
  {
    "realName": "Mazatlán",
    "country": "Mexique (SIN)",
    "x": "-54732.3",
    "z": "87832.3"
  },
  {
    "realName": "Mexicali",
    "country": "Mexique (BCN)",
    "x": "-92383.1",
    "z": "28113.3"
  },
  {
    "realName": "Moctezuma",
    "country": "Mexique (SON)",
    "x": "-68328.5",
    "z": "45879.5"
  },
  {
    "realName": "Moctezuma",
    "country": "Mexique (SLP)",
    "x": "-27109.6",
    "z": "92962.3"
  },
  {
    "realName": "Nacozari",
    "country": "Mexique (SON)",
    "x": "-68180.9",
    "z": "42257.1"
  },
  {
    "realName": "Navojoa",
    "country": "Mexique (SON)",
    "x": "-68552.6",
    "z": "64116.6"
  },
  {
    "realName": "Navojoa",
    "country": "Mexique (SON)",
    "x": "-68552.6",
    "z": "64116.6"
  },
  {
    "realName": "Nuevo Casas Grandes",
    "country": "Mexique (CHH)",
    "x": "-58325.3",
    "z": "44735.5"
  },
  {
    "realName": "Nuevo Vallarta",
    "country": "Mexique (NAY)",
    "x": "-49966.9",
    "z": "102900"
  },
  {
    "realName": "Ojinaga",
    "country": "Mexique (CHH)",
    "x": "-41514.9",
    "z": "53936.1"
  },
  {
    "realName": "Ojuelos",
    "country": "Mexique (SLP)",
    "x": "-30366.1",
    "z": "97724.8"
  },
  {
    "realName": "Parral",
    "country": "Mexique (CHH)",
    "x": "-49800.4",
    "z": "66558.9"
  },
  {
    "realName": "Pinos",
    "country": "Mexique (SLP)",
    "x": "-29029.3",
    "z": "94768.1"
  },
  {
    "realName": "Puerto Peñasco",
    "country": "Mexique (SON)",
    "x": "-84643.3",
    "z": "34661.3"
  },
  {
    "realName": "Puerto San Carlos",
    "country": "Mexique (BCS)",
    "x": "-84728.6",
    "z": "75038"
  },
  {
    "realName": "Punta Abreojos",
    "country": "Mexique (BCS)",
    "x": "-89163.6",
    "z": "61505.1"
  },
  {
    "realName": "Punta Prieta",
    "country": "Mexique (BCS)",
    "x": "-89711.4",
    "z": "48742"
  },
  {
    "realName": "Real de Catorce",
    "country": "Mexique (SLP)",
    "x": "-26718.7",
    "z": "87304"
  },
  {
    "realName": "Río Grande",
    "country": "Mexique (ZAC)",
    "x": "-36954.9",
    "z": "84909.9"
  },
  {
    "realName": "Río Verde",
    "country": "Mexique (SLP)",
    "x": "-21672.4",
    "z": "98529.3"
  },
  {
    "realName": "San Blas",
    "country": "Mexique (NAY)",
    "x": "-50755.9",
    "z": "97179.3"
  },
  {
    "realName": "San Luis Potosí",
    "country": "Mexique (SLP)",
    "x": "-27379.3",
    "z": "96228.5"
  },
  {
    "realName": "San Luis Río Colorado",
    "country": "Mexique (SON)",
    "x": "-85822",
    "z": "30702.9"
  },
  {
    "realName": "San Luis Río Colorado",
    "country": "Mexique (BCN)",
    "x": "-85822",
    "z": "30702.9"
  },
  {
    "realName": "San Luis Río Colorado",
    "country": "USA (AZ)",
    "x": "-85822",
    "z": "30702.9"
  },
  {
    "realName": "Santa Ana",
    "country": "Mexique (SON)",
    "x": "-77887.8",
    "z": "41657.6"
  },
  {
    "realName": "Santa Rosalía",
    "country": "Mexique (BCS)",
    "x": "-81985",
    "z": "59817"
  },
  {
    "realName": "Santiago Papasquiaro",
    "country": "Mexique (DUR)",
    "x": "-49233.5",
    "z": "77940.5"
  },
  {
    "realName": "San Felípe",
    "country": "Mexique (BCN)",
    "x": "-90542.5",
    "z": "36321.8"
  },
  {
    "realName": "Sombrerete",
    "country": "Mexique (ZAC)",
    "x": "-39808.1",
    "z": "86782.2"
  },
  {
    "realName": "Sonoyta",
    "country": "Mexique (SON)",
    "x": "-81177.1",
    "z": "32482.3"
  },
  {
    "realName": "Santa María del Oro",
    "country": "Mexique (DUR)",
    "x": "-47788",
    "z": "71899.9"
  },
  {
    "realName": "Santa María del Rio",
    "country": "Mexique (SLP)",
    "x": "-25493.9",
    "z": "99220.6"
  },
  {
    "realName": "Tamazula",
    "country": "Mexique (SIN)",
    "x": "-55266.3",
    "z": "78948.5"
  },
  {
    "realName": "Tamazunchale",
    "country": "Mexique (SLP)",
    "x": "-15649.9",
    "z": "100829"
  },
  {
    "realName": "Tecuala",
    "country": "Mexique (NAY)",
    "x": "-51019.6",
    "z": "93164.7"
  },
  {
    "realName": "Tepic",
    "country": "Mexique (NAY)",
    "x": "-46889.3",
    "z": "98193.3"
  },
  {
    "realName": "San Diego/Tijuana",
    "country": "USA (CA)",
    "x": "-99184.2",
    "z": "27196.8"
  },
  {
    "realName": "Tlaltenango",
    "country": "Mexique (ZAC)",
    "x": "-39775.4",
    "z": "97674.3"
  },
  {
    "realName": "Urique",
    "country": "Mexique (CHH)",
    "x": "-62632.4",
    "z": "62993.2"
  },
  {
    "realName": "Ciudad Valles",
    "country": "Mexique (SLP)",
    "x": "-15868.6",
    "z": "97722.6"
  },
  {
    "realName": "Durango",
    "country": "Mexique (DUR)",
    "x": "-45394.6",
    "z": "84324.4"
  },
  {
    "realName": "Vanegas",
    "country": "Mexique (SLP)",
    "x": "-26572.9",
    "z": "85806.8"
  },
  {
    "realName": "Villanueva",
    "country": "Mexique (ZAC)",
    "x": "-36782.9",
    "z": "95035"
  },
  {
    "realName": "Villa de Guadalupe",
    "country": "Mexique (SLP)",
    "x": "-25183",
    "z": "89954.2"
  },
  {
    "realName": "Villa Zaragoza",
    "country": "Mexique (SLP)",
    "x": "-25323.1",
    "z": "97196.6"
  },
  {
    "realName": "Villa Ahumada",
    "country": "USA (TX)",
    "x": "-51593.6",
    "z": "43591.8"
  },
  {
    "realName": "Yécora",
    "country": "Mexique (SON)",
    "x": "-65075.4",
    "z": "57626.5"
  },
  {
    "realName": "Zacatecas",
    "country": "Mexique (ZAC)",
    "x": "-33904.4",
    "z": "92182.5"
  },
  {
    "realName": "Zacatecas",
    "country": "Mexique (ZAC)",
    "x": "-33904.4",
    "z": "92182.5"
  },
 ];

var cities_c2c = [
    {
    "realName": "Anniston",
    "country": "USA (AL)",
    "x": "47052.7",
    "z": "27017.7"
  },
  {
    "realName": "Birmingham",
    "country": "USA (AL)",
    "x": "43256.8",
    "z": "28322"
  },
  {
    "realName": "Huntsville",
    "country": "USA (AL)",
    "x": "41799.1",
    "z": "21186.1"
  },
  {
    "realName": "Mobile",
    "country": "USA (AL)",
    "x": "39248",
    "z": "45610.4"
  },
  {
    "realName": "Mobile",
    "country": "USA (AL)",
    "x": "39248",
    "z": "45610.4"
  },
  {
    "realName": "Montgomery",
    "country": "USA (AL)",
    "x": "45209.6",
    "z": "37586.9"
  },
  {
    "realName": "Tuscaloosa",
    "country": "USA (AL)",
    "x": "38725.8",
    "z": "32224.4"
  },
  {
    "realName": "Hartford",
    "country": "USA (CT)",
    "x": "96897.8",
    "z": "-28362.4"
  },
  {
    "realName": "New Haven",
    "country": "USA (CT)",
    "x": "96746.5",
    "z": "-25291.5"
  },
  
	{
      "realName": "Wilmington",
      "country": "USA (DE)",
      "x": "87796.5",
      "z": "-14371.5"
    },
  {
    "realName": "Panama City",
    "country": "USA (FL)",
    "x": "51618.7",
    "z": "43546.9"
  },
  {
    "realName": "Port Saint Lucie",
    "country": "USA (FL)",
    "x": "79975.3",
    "z": "60176.5"
  },
  {
    "realName": "Gainesville",
    "country": "USA (FL)",
    "x": "65934.9",
    "z": "48829"
  },
  {
    "realName": "Jacksonville",
    "country": "USA (FL)",
    "x": "70683.2",
    "z": "42033.6"
  },
  {
    "realName": "Key West",
    "country": "USA (FL)",
    "x": "75154.8",
    "z": "76254.8"
  },
  {
    "realName": "Melbourne",
    "country": "USA (FL)",
    "x": "77407.9",
    "z": "55267.3"
  },
  {
    "realName": "Miami",
    "country": "USA (FL)",
    "x": "81409.5",
    "z": "68934.8"
  },
  {
    "realName": "Fort Myers",
    "country": "USA (FL)",
    "x": "73653",
    "z": "66650.7"
  },
  {
    "realName": "Daytona Beach",
    "country": "USA (FL)",
    "x": "74529",
    "z": "48411.4"
  },
  {
    "realName": "Daytona Beach",
    "country": "USA (FL)",
    "x": "74529",
    "z": "48411.4"
  },
  {
    "realName": "Orlando",
    "country": "USA (FL)",
    "x": "72499.1",
    "z": "53947.9"
  },
  {
    "realName": "Pensacola",
    "country": "USA (FL)",
    "x": "44251.7",
    "z": "45536.2"
  },
  {
    "realName": "Pensacola",
    "country": "USA (FL)",
    "x": "44251.7",
    "z": "45536.2"
  },
  {
    "realName": "Sarasota",
    "country": "USA (FL)",
    "x": "69058.5",
    "z": "61218.6"
  },
  {
    "realName": "Sarasota",
    "country": "USA (FL)",
    "x": "69058.5",
    "z": "61218.6"
  },
  {
    "realName": "Tallahassee",
    "country": "USA (FL)",
    "x": "57304.9",
    "z": "44458.2"
  },
  {
    "realName": "Tampa",
    "country": "USA (FL)",
    "x": "67718.8",
    "z": "57431"
  },
  {
    "realName": "Albany",
    "country": "USA (GA)",
    "x": "59300.6",
    "z": "36924.4"
  },
  {
    "realName": "Atlanta",
    "country": "USA (GA)",
    "x": "53503.3",
    "z": "25862"
  },
  {
    "realName": "Augusta",
    "country": "USA (GA)",
    "x": "65444.4",
    "z": "25661.2"
  },
  {
    "realName": "Columbus",
    "country": "USA (GA)",
    "x": "51200.3",
    "z": "31099.5"
  },
  {
    "realName": "Macon",
    "country": "USA (GA)",
    "x": "58277.8",
    "z": "30230.2"
  },
  {
    "realName": "Savannah",
    "country": "USA (GA)",
    "x": "71340.3",
    "z": "33230.1"
  },
  {
    "realName": "Statesboro",
    "country": "USA (GA)",
    "x": "65187.3",
    "z": "32035.8"
  },
  {
    "realName": "Valdosta",
    "country": "USA (GA)",
    "x": "61486.7",
    "z": "41379.2"
  },
  {
    "realName": "Waycross",
    "country": "USA (GA)",
    "x": "65835.8",
    "z": "36748"
  },
  {
    "realName": "Hilo",
    "country": "USA (HI)",
    "x": "-293173",
    "z": "42103.5"
  },
  {
    "realName": "Honolulu",
    "country": "USA (HI)",
    "x": "-313617",
    "z": "-11027.75"
  },
  {
    "realName": "Kilua Kona",
    "country": "USA (HI)",
    "x": "-305466",
    "z": "40895.7"
  },
  {
    "realName": "Naalehu",
    "country": "USA (HI)",
    "x": "-302175",
    "z": "48855.6"
  },
  {
    "realName": "Bloomington",
    "country": "USA (IL)",
    "x": "30066.2",
    "z": "-9248.75"
  },
  {
    "realName": "Champaign",
    "country": "USA (IL)",
    "x": "33836.7",
    "z": "-7500.1"
  },
  {
    "realName": "Chicago",
    "country": "USA (IL)",
    "x": "34826.7",
    "z": "-17855.9"
  },
  {
    "realName": "LaSalle",
    "country": "USA (IL)",
    "x": "28595.5",
    "z": "-14477.3"
  },
  {
    "realName": "Mt. Vernon",
    "country": "USA (IL)",
    "x": "32140.6",
    "z": "2314.56"
  },
  {
    "realName": "Peoria",
    "country": "USA (IL)",
    "x": "25361.1",
    "z": "-10042.6"
  },
  {
    "realName": "Quincy",
    "country": "USA (IL)",
    "x": "21377.1",
    "z": "-5253.58"
  },
  {
    "realName": "Rockford",
    "country": "USA (IL)",
    "x": "29326.7",
    "z": "-19394.9"
  },
  {
    "realName": "Springfield",
    "country": "USA (IL)",
    "x": "27536.2",
    "z": "-4769.32"
  },
  {
    "realName": "Indianapolis",
    "country": "USA (IN)",
    "x": "42699.5",
    "z": "-6499.56"
  },
  {
    "realName": "Evansville",
    "country": "USA (IN)",
    "x": "38176.1",
    "z": "3043.07"
  },
  {
    "realName": "Fort Wayne",
    "country": "USA (IN)",
    "x": "46861.2",
    "z": "-13849.3"
  },
  {
    "realName": "Lafayette",
    "country": "USA (IN)",
    "x": "38297.4",
    "z": "-10933.1"
  },
  {
    "realName": "South Bend",
    "country": "USA (IN)",
    "x": "43206.4",
    "z": "-16693.6"
  },
  {
    "realName": "Terre Haute",
    "country": "USA (IN)",
    "x": "35385.1",
    "z": "-3420.99"
  },
  {
    "realName": "Great Bend",
    "country": "USA (KS)",
    "x": "-12390.6",
    "z": "3328.88"
  },
  {
    "realName": "Liberal",
    "country": "USA (KS)",
    "x": "-22130.8",
    "z": "10233.8"
  },
  {
    "realName": "Bowling Green",
    "country": "USA (KY)",
    "x": "43937",
    "z": "8545.25"
  },
  {
    "realName": "Lexington",
    "country": "USA (KY)",
    "x": "51012.7",
    "z": "2368.46"
  },
  {
    "realName": "London",
    "country": "USA (KY)",
    "x": "52935.9",
    "z": "8618.22"
  },
  {
    "realName": "Louisville",
    "country": "USA (KY)",
    "x": "45233.7",
    "z": "1811.28"
  },
  {
    "realName": "Paducah",
    "country": "USA (KY)",
    "x": "35843.7",
    "z": "9181.52"
  },
  {
    "realName": "Alexandria",
    "country": "USA (LA)",
    "x": "17350.1",
    "z": "42386.1"
  },
  {
    "realName": "Baton Rouge",
    "country": "USA (LA)",
    "x": "23112.9",
    "z": "47069.5"
  },
  {
    "realName": "Lafayette",
    "country": "USA (LA)",
    "x": "19753.2",
    "z": "48213.6"
  },
  {
    "realName": "Lafayette",
    "country": "USA (LA)",
    "x": "19753.2",
    "z": "48213.6"
  },
  {
    "realName": "Lake Charles",
    "country": "USA (LA)",
    "x": "14587.6",
    "z": "48573"
  },
  {
    "realName": "Monroe",
    "country": "USA (LA)",
    "x": "18310.5",
    "z": "35505.5"
  },
  {
    "realName": "Natchitoches",
    "country": "USA (LA)",
    "x": "14267.8",
    "z": "38305.5"
  },
  {
    "realName": "New Orleans",
    "country": "USA (LA)",
    "x": "29456.7",
    "z": "50159.6"
  },
  {
    "realName": "Shreveport",
    "country": "USA (LA)",
    "x": "10027.9",
    "z": "35026.7"
  },
  {
    "realName": "Augusta",
    "country": "USA (ME)",
    "x": "104817",
    "z": "-47146.5"
  },
  {
    "realName": "Bangor",
    "country": "USA (ME)",
    "x": "107520",
    "z": "-49291.6"
  },
  {
    "realName": "Houlton",
    "country": "USA (ME)",
    "x": "106893",
    "z": "-57324.5"
  },
  {
    "realName": "Portland",
    "country": "USA (ME)",
    "x": "103879",
    "z": "-41233.5"
  },
  {
    "realName": "Baltimore",
    "country": "USA (MD)",
    "x": "83921.1",
    "z": "-10999.3"
  },
  {
    "realName": "Baltimore",
    "country": "USA (MD)",
    "x": "83921.1",
    "z": "-10999.3"
  },
  {
    "realName": "Washington, DC",
    "country": "USA (DC)",
    "x": "82526",
    "z": "-8588.73"
  },
  {
    "realName": "Washington, DC",
    "country": "USA (DC)",
    "x": "82526",
    "z": "-8588.73"
  },
  {
    "realName": "Boston",
    "country": "USA (MA)",
    "x": "102655",
    "z": "-33039.5"
  },
  {
    "realName": "Springfield",
    "country": "USA (MA)",
    "x": "96752.6",
    "z": "-34428.4"
  },
  {
    "realName": "Detroit",
    "country": "USA (MI)",
    "x": "53558.8",
    "z": "-22861.4"
  },
  {
    "realName": "Grand Rapids",
    "country": "USA (MI)",
    "x": "39965.5",
    "z": "-25104.4"
  },
  {
    "realName": "Lansing",
    "country": "USA (MI)",
    "x": "46487.4",
    "z": "-23688.5"
  },
  {
    "realName": "Flint",
    "country": "USA (MI)",
    "x": "49938.1",
    "z": "-30218.3"
  },
  {
    "realName": "Traverse City",
    "country": "USA (MI)",
    "x": "41267.3",
    "z": "-34538.1"
  },
  {
    "realName": "Alpena",
    "country": "USA (MI)",
    "x": "49828.8",
    "z": "-37610.9"
  },
  {
    "realName": "Albert Lea",
    "country": "USA (MN)",
    "x": "10904.6",
    "z": "-26538.6"
  },
  {
    "realName": "Albert Lea",
    "country": "USA (MN)",
    "x": "10904.6",
    "z": "-26538.6"
  },
  {
    "realName": "Albert Lea",
    "country": "USA (MN)",
    "x": "12304.6",
    "z": "-26538.6"
  },
  {
    "realName": "Bemidji",
    "country": "USA (MN)",
    "x": "4582.52",
    "z": "-48284.4"
  },
  {
    "realName": "Duluth",
    "country": "USA (MN)",
    "x": "15242.3",
    "z": "-44691"
  },
  {
    "realName": "Minneapolis",
    "country": "USA (MN)",
    "x": "10360",
    "z": "-34026.9"
  },
  {
    "realName": "Rochester",
    "country": "USA (MN)",
    "x": "15607.5",
    "z": "-28327"
  },
  {
    "realName": "Rochester",
    "country": "USA (MN)",
    "x": "15607.5",
    "z": "-28327"
  },
  {
    "realName": "Rochester",
    "country": "USA (MN)",
    "x": "15127.4",
    "z": "-25665.2"
  },
  {
    "realName": "Rochester",
    "country": "USA (MN)",
    "x": "14827.4",
    "z": "-25665.2"
  },
  {
    "realName": "Rochester",
    "country": "USA (MN)",
    "x": "15127.4",
    "z": "-25665.2"
  },
  {
    "realName": "St. Cloud",
    "country": "USA (MN)",
    "x": "6070.76",
    "z": "-39767.2"
  },
  {
    "realName": "Worthington",
    "country": "USA (MN)",
    "x": "3612.22",
    "z": "-26880.8"
  },
  {
    "realName": "Grenada",
    "country": "USA (MS)",
    "x": "28595.6",
    "z": "28221.2"
  },
  {
    "realName": "Gulfport",
    "country": "USA (MS)",
    "x": "33807.3",
    "z": "47029"
  },
  {
    "realName": "Hattiesburg",
    "country": "USA (MS)",
    "x": "32292.2",
    "z": "41669"
  },
  {
    "realName": "Indianola",
    "country": "USA (MS)",
    "x": "22595.6",
    "z": "29521.2"
  },
  {
    "realName": "Meridian",
    "country": "USA (MS)",
    "x": "34012.5",
    "z": "34380.1"
  },
  {
    "realName": "McComb",
    "country": "USA (MS)",
    "x": "27807.6",
    "z": "41437.5"
  },
  {
    "realName": "Tupelo",
    "country": "USA (MS)",
    "x": "34178.3",
    "z": "26680.7"
  },
  {
    "realName": "Jackson/Vicksburg",
    "country": "USA (MS)",
    "x": "26945.4",
    "z": "36484.4"
  },
  {
    "realName": "Asheville",
    "country": "USA (NC)",
    "x": "61439.6",
    "z": "14311.7"
  },
  {
    "realName": "Charlotte",
    "country": "USA (NC)",
    "x": "68977.8",
    "z": "15468.7"
  },
  {
    "realName": "Fayetteville",
    "country": "USA (NC)",
    "x": "78325.3",
    "z": "14592.2"
  },
  {
    "realName": "Greensboro",
    "country": "USA (NC)",
    "x": "72004.6",
    "z": "9829.19"
  },
  {
    "realName": "Greenville",
    "country": "USA (NC)",
    "x": "86825.3",
    "z": "12477.3"
  },
  {
    "realName": "Raleigh",
    "country": "USA (NC)",
    "x": "80658.2",
    "z": "7362.4"
  },
  {
    "realName": "Wilmington",
    "country": "USA (NC)",
    "x": "82775.7",
    "z": "18383.1"
  },
  {
    "realName": "Bismarck",
    "country": "USA (ND)",
    "x": "-18309.1",
    "z": "-44849"
  },
  {
    "realName": "Dickinson",
    "country": "USA (ND)",
    "x": "-25178",
    "z": "-45496.6"
  },
  {
    "realName": "Fargo",
    "country": "USA (ND)",
    "x": "-4158.69",
    "z": "-45997.3"
  },
  {
    "realName": "Grand Forks",
    "country": "USA (ND)",
    "x": "-3210.07",
    "z": "-51147.3"
  },
  {
    "realName": "Jamestown",
    "country": "USA (ND)",
    "x": "-11006.8",
    "z": "-45126.9"
  },
  {
    "realName": "Williston",
    "country": "USA (ND)",
    "x": "-29149.3",
    "z": "-52932.4"
  },
  {
    "realName": "Manchester",
    "country": "USA (NH)",
    "x": "100251",
    "z": "-36421.9"
  },
  {
    "realName": "Portsmouth",
    "country": "USA (NH)",
    "x": "105968",
    "z": "-38020"
  },
  {
	"realName": "Trenton",
	"country": "USA (NJ)",
	"x": "90635.9",
	"z": "-18108.2"
    },
  {
    "realName": "Albany",
    "country": "USA (NY)",
    "x": "91460.4",
    "z": "-32164.3"
  },
  {
    "realName": "Binghamton",
    "country": "USA (NY)",
    "x": "84069.2",
    "z": "-26854.7"
  },
  {
    "realName": "Buffalo",
    "country": "USA (NY)",
    "x": "70709",
    "z": "-28759.2"
  },
  {
    "realName": "Elmira",
    "country": "USA (NY)",
    "x": "77838.5",
    "z": "-24805.9"
  },
  {
	"realName": "Glens Falls",
	"country": "USA (NY)",
	"x": "90720.8",
	"z": "-35786.9"
    },
  {
    "realName": "Ithaca",
    "country": "USA (NY)",
    "x": "80198.5",
    "z": "-28192.8"
  },
  {
    "realName": "New York",
    "country": "USA (NY)",
    "x": "94380.8",
    "z": "-21379.9"
  },
  {
    "realName": "Olean",
    "country": "USA (NY)",
    "x": "73204.3",
    "z": "-24820"
  },
  {
    "realName": "Oneonta",
    "country": "USA (NY)",
    "x": "86289.3",
    "z": "-30124.2"
  },
  {
    "realName": "Poughkeepsie",
    "country": "USA (NY)",
    "x": "90584.8",
    "z": "-25687.8"
  },
  {
    "realName": "Rochester",
    "country": "USA (NY)",
    "x": "74809.1",
    "z": "-31480.9"
  },
  {
    "realName": "Syracuse",
    "country": "USA (NY)",
    "x": "81289.3",
    "z": "-32124.2"
  },
  {
    "realName": "Utica",
    "country": "USA (NY)",
    "x": "87032.6",
    "z": "-36357.1"
  },
  {
    "realName": "Canton",
    "country": "USA (OH)",
    "x": "60529.6",
    "z": "-13281.3"
  },
  {
    "realName": "Cincinnati",
    "country": "USA (OH)",
    "x": "50308.5",
    "z": "-3609.28"
  },
  {
    "realName": "Cleveland",
    "country": "USA (OH)",
    "x": "60607.5",
    "z": "-21904.6"
  },
  {
    "realName": "Columbus",
    "country": "USA (OH)",
    "x": "56294.3",
    "z": "-8068.84"
  },
  {
    "realName": "Dayton",
    "country": "USA (OH)",
    "x": "50875.4",
    "z": "-7785.59"
  },
  {
    "realName": "Lima",
    "country": "USA (OH)",
    "x": "51602.9",
    "z": "-13929.9"
  },
  {
    "realName": "Toledo",
    "country": "USA (OH)",
    "x": "52495.3",
    "z": "-18242.3"
  },
  {
    "realName": "Youngstown",
    "country": "USA (OH)",
    "x": "64949.2",
    "z": "-18030.3"
  },
  {
    "realName": "Allentown",
    "country": "USA (PA)",
    "x": "87413.7",
    "z": "-19170.9"
  },
  {
    "realName": "DuBois",
    "country": "USA (PA)",
    "x": "74653.1",
    "z": "-18980.1"
  },
  {
    "realName": "Erie",
    "country": "USA (PA)",
    "x": "67823",
    "z": "-23033.8"
  },
  {
    "realName": "Harrisburg",
    "country": "USA (PA)",
    "x": "81389.3",
    "z": "-15847.9"
  },
  {
    "realName": "Harrisburg",
    "country": "USA (PA)",
    "x": "81389.3",
    "z": "-15847.9"
  },
  {
    "realName": "Johnstown",
    "country": "USA (PA)",
    "x": "75254.8",
    "z": "-13310"
  },
  {
    "realName": "Lancaster",
    "country": "USA (PA)",
    "x": "85055.5",
    "z": "-15908.2"
  },
  {
    "realName": "Lancaster",
    "country": "USA (PA)",
    "x": "85055.5",
    "z": "-15908.2"
  },
  {
    "realName": "Pittsburgh",
    "country": "USA (PA)",
    "x": "68714.6",
    "z": "-12459.6"
  },
  {
    "realName": "Scranton",
    "country": "USA (PA)",
    "x": "85315.1",
    "z": "-23451.5"
  },
  {
    "realName": "Philadelphia",
    "country": "USA (PA)",
    "x": "89157.5",
    "z": "-16054.3"
  },
  {
    "realName": "Williamsport",
    "country": "USA (PA)",
    "x": "81838.5",
    "z": "-19805.9"
  },
  {
    "realName": "Providence",
    "country": "USA (RI)",
    "x": "101936",
    "z": "-29754.1"
  },
  {
    "realName": "Charleston",
    "country": "USA (SC)",
    "x": "74815.6",
    "z": "28091.9"
  },
  {
    "realName": "Columbia",
    "country": "USA (SC)",
    "x": "68910.3",
    "z": "22065.1"
  },
  {
    "realName": "Florence",
    "country": "USA (SC)",
    "x": "75656.7",
    "z": "20125.4"
  },
  {
    "realName": "Georgetown",
    "country": "USA (SC)",
    "x": "78769.9",
    "z": "24070.8"
  },
  {
    "realName": "Greenville",
    "country": "USA (SC)",
    "x": "61776.2",
    "z": "21010.3"
  },
  {
    "realName": "Myrtle Beach",
    "country": "USA (SC)",
    "x": "80484.6",
    "z": "21544.3"
  },
  {
    "realName": "Mitchell",
    "country": "USA (SD)",
    "x": "-10707.6",
    "z": "-27015.4"
  },
  {
    "realName": "Pierre",
    "country": "USA (SD)",
    "x": "-17267.9",
    "z": "-28592.6"
  },
  {
    "realName": "Rapid City",
    "country": "USA (SD)",
    "x": "-28875.1",
    "z": "-30052.5"
  },
  {
    "realName": "Sioux Falls",
    "country": "USA (SD)",
    "x": "-3253.96",
    "z": "-25688.5"
  },
  {
    "realName": "Chattanooga",
    "country": "USA (TN)",
    "x": "48735.4",
    "z": "19086.8"
  },
  {
    "realName": "Cookeville",
    "country": "USA (TN)",
    "x": "48082.3",
    "z": "13205"
  },
  {
    "realName": "Jackson",
    "country": "USA (TN)",
    "x": "33107.8",
    "z": "17386.2"
  },
  {
    "realName": "Kingsport",
    "country": "USA (TN)",
    "x": "59494.8",
    "z": "7043.76"
  },
  {
    "realName": "Knoxville",
    "country": "USA (TN)",
    "x": "53402.1",
    "z": "13898.1"
  },
  {
    "realName": "Memphis",
    "country": "USA (TN)",
    "x": "26982.5",
    "z": "20436.6"
  },
  {
    "realName": "Nashville",
    "country": "USA (TN)",
    "x": "41926.1",
    "z": "13211.2"
  },
  {
    "realName": "Burlington",
    "country": "USA (VT)",
    "x": "91517.3",
    "z": "-42651.6"
  },
  {
    "realName": "Hagerstown",
    "country": "USA (MD)",
    "x": "78665.1",
    "z": "-12007.7"
  },
  {
    "realName": "Lebanon",
    "country": "USA (NH)",
    "x": "95627",
    "z": "-39177.6"
  },
  {
    "realName": "Charlottesville",
    "country": "USA (VA)",
    "x": "74952.3",
    "z": "-1239.93"
  },
  {
    "realName": "Fredericksburg",
    "country": "USA (VA)",
    "x": "81330",
    "z": "-4494.48"
  },
  {
    "realName": "Harrisonburg",
    "country": "USA (VA)",
    "x": "76355.7",
    "z": "-5788.03"
  },
  {
    "realName": "Norfolk",
    "country": "USA (VA)",
    "x": "87689.6",
    "z": "2326.24"
  },
  {
    "realName": "Richmond",
    "country": "USA (VA)",
    "x": "82279.8",
    "z": "490.537"
  },
  {
    "realName": "Roanoke",
    "country": "USA (VA)",
    "x": "72370.9",
    "z": "2572.97"
  },
  {
    "realName": "Winchester",
    "country": "USA (VA)",
    "x": "77995.2",
    "z": "-9302.82"
  },
  {
    "realName": "Wytheville",
    "country": "USA (VA)",
    "x": "66609.6",
    "z": "6230.84"
  },
  {
    "realName": "Charleston",
    "country": "USA (WV)",
    "x": "65115.5",
    "z": "170.621"
  },
  {
    "realName": "Charleston",
    "country": "USA (WV)",
    "x": "65115.5",
    "z": "170.621"
  },
  {
    "realName": "Huntington",
    "country": "USA (WV)",
    "x": "58499.1",
    "z": "-745.599"
  },
  {
    "realName": "Huntington",
    "country": "USA (WV)",
    "x": "58499.1",
    "z": "-745.599"
  },
  {
    "realName": "Parkersburg",
    "country": "USA (WV)",
    "x": "63509.9",
    "z": "-7009.07"
  },
  {
    "realName": "Clarksburg",
    "country": "USA (WV)",
    "x": "67729.6",
    "z": "-5651.21"
  },
  {
    "realName": "Eau Claire",
    "country": "USA (WI)",
    "x": "18094.4",
    "z": "-33687.8"
  },
  {
    "realName": "Green Bay",
    "country": "USA (WI)",
    "x": "32131.6",
    "z": "-32069.8"
  },
  {
    "realName": "La Crosse",
    "country": "USA (WI)",
    "x": "19789.5",
    "z": "-27736"
  },
  {
    "realName": "Madison",
    "country": "USA (WI)",
    "x": "27438.6",
    "z": "-23828.8"
  },
  {
    "realName": "Milwaukee",
    "country": "USA (WI)",
    "x": "32376.2",
    "z": "-24465.1"
  },
  {
    "realName": "Prairie du Chien",
    "country": "USA (WI)",
    "x": "20932.9",
    "z": "-24688.9"
  },
  {
    "realName": "Wausau",
    "country": "USA (WI)",
    "x": "26019.9",
    "z": "-33688.5"
  },
];


var cities_canada = [
    {
    "realName": "Baie-Comeau",
    "country": "Canada (QC)",
    "x": "99059.4",
    "z": "-73027.1"
  },
  {
    "realName": "Bancroft",
    "country": "Canada (ON)",
    "x": "71074.7",
    "z": "-41660.5"
  },
  {
    "realName": "Belleville",
    "country": "Canada (ON)",
    "x": "73964",
    "z": "-36945.2"
  },
  {
    "realName": "Calgary",
    "country": "Canada (AB)",
    "x": "-64088.6",
    "z": "-74325.2"
  },
  {
    "realName": "Caraquet",
    "country": "Canada (NB)",
    "x": "114593",
    "z": "-69287.6"
  },
  {
    "realName": "Chapleau",
    "country": "Canada (ON)",
    "x": "48197.1",
    "z": "-53884.2"
  },
  {
    "realName": "Dawson Creek",
    "country": "Canada (BC)",
    "x": "-74949.1",
    "z": "-106148"
  },
  {
    "realName": "Dease Lake",
    "country": "Canada (BC)",
    "x": "-95251.7",
    "z": "-129369"
  },
  {
    "realName": "Deux-Rivieres",
    "country": "Canada (ON)",
    "x": "68679",
    "z": "-47707.5"
  },
  {
    "realName": "Dryden",
    "country": "Canada (ON)",
    "x": "13957.7",
    "z": "-60448.3"
  },
  {
    "realName": "Edmonton",
    "country": "Canada (AB)",
    "x": "-58262",
    "z": "-89326.9"
  },
  {
    "realName": "Fort Frances",
    "country": "Canada (ON)",
    "x": "9579.86",
    "z": "-55181.6"
  },
  {
    "realName": "Fort McMurray",
    "country": "Canada (AB)",
    "x": "-47067.2",
    "z": "-107664"
  },
  {
    "realName": "Fort Nelson",
    "country": "Canada (BC)",
    "x": "-75233.3",
    "z": "-124972"
  },
  {
    "realName": "Fort Simpson",
    "country": "Canada (NT)",
    "x": "-67255",
    "z": "-141067"
  },
  {
    "realName": "Fredericton",
    "country": "Canada (NB)",
    "x": "112384",
    "z": "-57236.5"
  },
  {
    "realName": "Gaspe",
    "country": "Canada (QC)",
    "x": "113350",
    "z": "-74955.3"
  },
  {
    "realName": "Golden",
    "country": "Canada (BC)",
    "x": "-73410.9",
    "z": "-79297.7"
  },
  {
    "realName": "Grand Falls",
    "country": "Canada (NB)",
    "x": "106470",
    "z": "-63541.6"
  },
  {
    "realName": "Grand Forks",
    "country": "Canada (BC)",
    "x": "-82726.8",
    "z": "-67486.2"
  },
  {
    "realName": "Halifax",
    "country": "Canada (NS)",
    "x": "126331",
    "z": "-54553"
  },
  {
    "realName": "Hearst",
    "country": "Canada (ON)",
    "x": "45405.4",
    "z": "-64762.7"
  },
  {
    "realName": "High Level",
    "country": "Canada (AB)",
    "x": "-60917.7",
    "z": "-120900"
  },
  {
    "realName": "Hope",
    "country": "Canada (BC)",
    "x": "-94110.7",
    "z": "-71841.2"
  },
  {
    "realName": "Horseshoe Bay",
    "country": "Canada (BC)",
    "x": "-103698",
    "z": "-75997.2"
  },
  {
    "realName": "Houston",
    "country": "Canada (BC)",
    "x": "-97567.9",
    "z": "-104145"
  },
  {
    "realName": "Iroquois Falls",
    "country": "Canada (ON)",
    "x": "57355.1",
    "z": "-60873.2"
  },
  {
    "realName": "Jasper",
    "country": "Canada (AB)",
    "x": "-73415",
    "z": "-88979.8"
  },
  {
    "realName": "Kamloops",
    "country": "Canada (BC)",
    "x": "-85885.3",
    "z": "-78420.5"
  },
  {
    "realName": "Kelowna",
    "country": "Canada (BC)",
    "x": "-85262.3",
    "z": "-72796.7"
  },
  {
    "realName": "Kenora",
    "country": "Canada (ON)",
    "x": "5352.33",
    "z": "-61309.7"
  },
  {
    "realName": "Kindersley",
    "country": "Canada (SK)",
    "x": "-45923",
    "z": "-75881.9"
  },
  {
    "realName": "Kingston",
    "country": "Canada (ON)",
    "x": "78648.3",
    "z": "-39027.5"
  },
  {
    "realName": "Kingston",
    "country": "Canada (ON)",
    "x": "78648.3",
    "z": "-39027.5"
  },
  {
    "realName": "Labrador City",
    "country": "Canada (NL)",
    "x": "93507.1",
    "z": "-93864.3"
  },
  {
    "realName": "Lac La Biche",
    "country": "Canada (AB)",
    "x": "-51299.1",
    "z": "-96200.2"
  },
  {
    "realName": "La Tuque",
    "country": "Canada (QC)",
    "x": "86850.1",
    "z": "-58882.9"
  },
  {
    "realName": "Lillooet",
    "country": "Canada (BC)",
    "x": "-93234.8",
    "z": "-79834.4"
  },
  {
    "realName": "Lloydminster",
    "country": "Canada (AB/SK)",
    "x": "-47007",
    "z": "-86748.3"
  },
  {
    "realName": "London",
    "country": "Canada (ON)",
    "x": "59810.2",
    "z": "-28415.4"
  },
  {
    "realName": "Maniwaki",
    "country": "Canada (QC)",
    "x": "76695.3",
    "z": "-51041.1"
  },
  {
    "realName": "Medicine Hat",
    "country": "Canada (AB)",
    "x": "-48690.6",
    "z": "-65890.8"
  },
  {
    "realName": "Marathon",
    "country": "Canada (ON)",
    "x": "37156.5",
    "z": "-57067.3"
  },
  {
    "realName": "Matane",
    "country": "Canada (QC)",
    "x": "103192",
    "z": "-72119.8"
  },
  {
    "realName": "Merrit",
    "country": "Canada (BC)",
    "x": "-90468.8",
    "z": "-75121"
  },
  {
    "realName": "Moncton",
    "country": "Canada (NB)",
    "x": "118089",
    "z": "-61184.6"
  },
  {
    "realName": "Montreal",
    "country": "Canada (QC)",
    "x": "88397.9",
    "z": "-49154.3"
  },
  {
    "realName": "North Bay",
    "country": "Canada (ON)",
    "x": "63927.5",
    "z": "-47243.8"
  },
  {
    "realName": "Nakina",
    "country": "Canada (ON)",
    "x": "34124.8",
    "z": "-66400.7"
  },
  {
    "realName": "New Liskeard",
    "country": "Canada (ON)",
    "x": "61924",
    "z": "-53346.7"
  },
  {
    "realName": "Orillia",
    "country": "Canada (ON)",
    "x": "67028.8",
    "z": "-38455.8"
  },
  {
    "realName": "Osoyoos",
    "country": "Canada (BC)",
    "x": "-86504.2",
    "z": "-67646.3"
  },
  {
    "realName": "Ottawa",
    "country": "Canada (ON)",
    "x": "80067",
    "z": "-46320.4"
  },
  {
    "realName": "Owen Sound",
    "country": "Canada (ON)",
    "x": "59307.3",
    "z": "-36299.4"
  },
  {
    "realName": "Parry Sound",
    "country": "Canada (ON)",
    "x": "65455.3",
    "z": "-42134.3"
  },
  {
    "realName": "Pemberton",
    "country": "Canada (BC)",
    "x": "-97086.9",
    "z": "-78672.3"
  },
  {
    "realName": "Pembroke",
    "country": "Canada (ON)",
    "x": "73649",
    "z": "-46389.3"
  },
  {
    "realName": "Prince George",
    "country": "Canada (BC)",
    "x": "-87517.5",
    "z": "-99375.6"
  },
  {
    "realName": "Prince Rupert",
    "country": "Canada (BC)",
    "x": "-108895",
    "z": "-107909"
  },
  {
    "realName": "Princeton",
    "country": "Canada (BC)",
    "x": "-89911.4",
    "z": "-69829"
  },
  {
    "realName": "Quebec",
    "country": "Canada (QC)",
    "x": "93155.4",
    "z": "-58398.7"
  },
  {
    "realName": "Riviere-du-Loup",
    "country": "Canada (QC)",
    "x": "98911.1",
    "z": "-64965.4"
  },
  {
    "realName": "Regina",
    "country": "Canada (SK)",
    "x": "-31901.6",
    "z": "-68350.9"
  },
  {
    "realName": "Rouyn-Noranda",
    "country": "Canada (QC)",
    "x": "64290.2",
    "z": "-59556.8"
  },
  {
    "realName": "Russel",
    "country": "Canada (MB)",
    "x": "-18438.4",
    "z": "-68912.5"
  },
  {
    "realName": "Saguenay",
    "country": "Canada (QC)",
    "x": "91106.6",
    "z": "-66192.5"
  },
  {
    "realName": "Saskatoon",
    "country": "Canada (SK)",
    "x": "-37439.1",
    "z": "-77226.7"
  },
  {
    "realName": "Sault-Ste-Marie",
    "country": "Canada (ON)",
    "x": "46658.4",
    "z": "-45949.8"
  },
  {
    "realName": "Sept-iles",
    "country": "Canada (QC)",
    "x": "103300",
    "z": "-80432.5"
  },
  {
    "realName": "Sherbrooke",
    "country": "Canada (QC)",
    "x": "94917",
    "z": "-49305.4"
  },
  {
    "realName": "Stewart",
    "country": "Canada (BC)",
    "x": "-102241",
    "z": "-115701"
  },
  {
    "realName": "Sudbury",
    "country": "Canada (ON)",
    "x": "56362.2",
    "z": "-47613.1"
  },
  {
    "realName": "Squamish",
    "country": "Canada (BC)",
    "x": "-101549",
    "z": "-78990.2"
  },
  {
    "realName": "Thunder Bay",
    "country": "Canada (ON)",
    "x": "25738.7",
    "z": "-54215"
  },
  {
    "realName": "Timmins",
    "country": "Canada (ON)",
    "x": "57898.7",
    "z": "-58230.9"
  },
  {
    "realName": "Toronto",
    "country": "Canada (ON)",
    "x": "67315",
    "z": "-33489.6"
  },
  {
    "realName": "Truro",
    "country": "Canada (NS)",
    "x": "126436",
    "z": "-59150.2"
  },
  {
    "realName": "Vancouver",
    "country": "Canada (BC)",
    "x": "-100466.8",
    "z": "-72646.3"
  },
  {
    "realName": "Victoria",
    "country": "Canada (BC)",
    "x": "-101525",
    "z": "-68937.4"
  },
  {
    "realName": "Virden",
    "country": "Canada (MB)",
    "x": "-17350.5",
    "z": "-63395.2"
  },
  {
    "realName": "Watson Lake",
    "country": "Canada (YT)",
    "x": "-86524.3",
    "z": "-136995"
  },
  {
    "realName": "Whitehorse",
    "country": "Canada (YT)",
    "x": "-99299",
    "z": "-145242"
  },
  {
    "realName": "Whistler",
    "country": "Canada (BC)",
    "x": "-98948.1",
    "z": "-77017"
  },
  {
    "realName": "Whitney",
    "country": "Canada (ON)",
    "x": "70115.4",
    "z": "-44045.4"
  },
  {
    "realName": "Williams Lake",
    "country": "Canada (BC)",
    "x": "-89195.2",
    "z": "-88717.9"
  },
  {
    "realName": "Winnipeg",
    "country": "Canada (MB)",
    "x": "-3862.98",
    "z": "-62793.3"
  },
  {
    "realName": "Yarmouth",
    "country": "Canada (NS)",
    "x": "118775",
    "z": "-48255.3"
  },
  {
    "realName": "Yellowknife",
    "country": "Canada (NT)",
    "x": "-46836.9",
    "z": "-140606"
  }
];


var cities_caraïbes = [
    {
    "realName": "Adicora",
    "country": "Venezuela (Falcón)",
    "x": "157727",
    "z": "136283"
  },
  {
    "realName": "Coro",
    "country": "Venezuela (Falcón)",
    "x": "159451",
    "z": "139921"
  },
  {
    "realName": "Freeport",
    "country": "Bahamas (Grand Bahama)",
    "x": "88350.9",
    "z": "62912.5"
  },
  {
    "realName": "Guantanamo Bay",
    "country": "Cuba (Guantánamo)",
    "x": "115113",
    "z": "97014.4"
  },
  {
    "realName": "Havana",
    "country": "Cuba (Havana)",
    "x": "72902.3",
    "z": "85783.6"
  },
  {
    "realName": "Kingston",
    "country": "Jamaica (Kingston Parish)",
    "x": "108606",
    "z": "110186"
  },
  {
    "realName": "Mayagüez",
    "country": "USA (Puerto Rico)",
    "x": "161247",
    "z": "94517.4"
  },
  {
    "realName": "Montego Bay",
    "country": "Jamaica (Saint James Parish)",
    "x": "101687",
    "z": "108924"
  },
  {
    "realName": "Nassau",
    "country": "Bahamas (New Providence)",
    "x": "96750.8",
    "z": "69835.9"
  },
  {
    "realName": "Oranjestad",
    "country": "Aruba",
    "x": "155584",
    "z": "133214"
  },
  {
    "realName": "Punto Fijo",
    "country": "Venezuela (Falcón)",
    "x": "155329",
    "z": "138177"
  },
  {
    "realName": "Ponce",
    "country": "USA (Puerto Rico)",
    "x": "165673",
    "z": "95513.8"
  },
  {
    "realName": "San Juan",
    "country": "USA (Puerto Rico)",
    "x": "166305",
    "z": "90296.7"
  },
  {
    "realName": "Treasure Cay",
    "country": "Bahamas (Abaco Islands)",
    "x": "96667.7",
    "z": "61340.7"
  },
];


var cities_alaska = [
    {
    "realName": "Alcan",
    "country": "USA (AK)",
    "x": "-123196",
    "z": "-165269"
  },
  {
    "realName": "Anchorage",
    "country": "USA (AK)",
    "x": "-150691",
    "z": "-172013"
  },
  {
    "realName": "Cantwell",
    "country": "USA (AK)",
    "x": "-139272",
    "z": "-182233"
  },
  {
    "realName": "Clam Gulch",
    "country": "USA (AK)",
    "x": "-156602",
    "z": "-170927"
  },
  {
    "realName": "Coldfoot",
    "country": "USA (AK)",
    "x": "-126644",
    "z": "-207671"
  },
  {
    "realName": "Cooper Landing",
    "country": "USA (AK)",
    "x": "-151741",
    "z": "-167777"
  },
  {
    "realName": "Delta Junction",
    "country": "USA (AK)",
    "x": "-130113",
    "z": "-181524"
  },
  {
    "realName": "Delta Junction",
    "country": "USA (AK)",
    "x": "-130113",
    "z": "-181524"
  },
  {
    "realName": "Fairbanks",
    "country": "USA (AK)",
    "x": "-131672",
    "z": "-188155"
  },
  {
    "realName": "Fox River",
    "country": "USA (AK)",
    "x": "-156705",
    "z": "-166057"
  },
  {
    "realName": "Glennallen",
    "country": "USA (AK)",
    "x": "-135275",
    "z": "-169538"
  },
  {
    "realName": "Homer",
    "country": "USA (AK)",
    "x": "-158708",
    "z": "-166242"
  },
  {
    "realName": "Nenana",
    "country": "USA (AK)",
    "x": "-136269",
    "z": "-188015"
  },
  {
    "realName": "Nenana",
    "country": "USA (AK)",
    "x": "-136269",
    "z": "-188015"
  },
  {
    "realName": "Prudhoe Bay",
    "country": "USA (AK)",
    "x": "-111145",
    "z": "-224276"
  },
  {
    "realName": "Tok",
    "country": "USA (AK)",
    "x": "-125423",
    "z": "-172368"
  },
  {
    "realName": "Valdez",
    "country": "USA (AK)",
    "x": "-143310",
    "z": "-166205"
  },
  {
    "realName": "Wasilla",
    "country": "USA (AK)",
    "x": "-147411",
    "z": "-172804"
  }
];


var cities_divers = [
    
  {
	"_id": "kvaldor",
	"realName": "Val-d'Or",
	"country": "Canada (QC)",
	"mod": "Eastern Canada Expansion"
  },
	
	
];



cities = cities.concat(cities)

//Mexique
cities = cities.concat(cities_mexique);

//Uncomment the lines below to enable C2C
cities = cities.concat(cities_c2c);

//Uncomment the lines below to enable Canadream
cities = cities.concat(cities_canada);

//Uncomment the lines below to enable Terra Maps Caribbean
cities = cities.concat(cities_caraïbes );

//Alaska
cities = cities.concat(cities_alaska);

//Ajout de villes supplementaire
cities = cities.concat(cities_divers);


var citiesATS = [];
citiesATS = citiesATS.concat(cities);
citiesATS = citiesATS.concat(cities_mexique);
citiesATS = citiesATS.concat(cities_c2c);
citiesATS = citiesATS.concat(cities_canada);
citiesATS = citiesATS.concat(cities_caraïbes);
citiesATS = citiesATS.concat(cities_alaska);
citiesATS = citiesATS.concat(cities_divers);

window.citiesATS = citiesATS;
