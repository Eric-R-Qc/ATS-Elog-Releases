if (location.hostname === 'localhost' && 'serviceWorker' in navigator) {
  navigator.serviceWorker.getRegistrations().then(rs => rs.forEach(r => r.unregister()));
  if (window.caches?.keys) caches.keys().then(keys => keys.forEach(k => caches.delete(k)));
}

// === BUILD STAMP ===
window.ATS_ELOG_BUILD = "Dev v1.0.3 Beta 31-10-2025 16h30";
console.log("%cATS Elog " + window.ATS_ELOG_BUILD,
  "background:#111;color:#0f0;padding:2px 6px;border-radius:4px;font-weight:700");

// (optionnel) badge visuel
document.addEventListener("DOMContentLoaded", () => {
  const tag = document.createElement("div");
  tag.textContent = window.ATS_ELOG_BUILD;
  tag.style.cssText = "position:fixed;right:8px;bottom:8px;font:11px/1 monospace;opacity:.65;background:#000;color:#fff;padding:2px 6px;border-radius:6px;z-index:99999";
  document.body.appendChild(tag);
});

console.log("ATS Elog script chargé !");
window.lastSentOffset = null;
// Source finale de villes (priorité Sheet)
window.citiesFinal = [];
window.citiesReady = false;   // false ⇒ on n'affiche pas de ville

const endpoint = "/data91";
const refreshMs = 1000;
let lastCity = "";
let lastState = "";
let lastTz = null;
let lastCitySent = "";
let lastStateSent = "";

const translations = {
  fr: {
    hos: "HOS",
    home: "Accueil",
    settings: "Réglages",
    logs: "LogBooks",
    about: "À propos",
	dev:"Contribution",
	titre_about: "ATS Elog — A propos", 
    rest_in: "Repos",
    drive_rem: "Conduite restante",
    rest_Rem: "Service restant",
    cycle_rem: "Cycle 70h/8 jours",
    language: "Langue",
    ats_timezone: "Fuseau Horaire ATS",
    endpoint: "Endpoint données",
    save: "Enregistrer",
    saved: "Sauvegardé !",
    editChauffeur: "Nom du Conducteur",
	// ↓↓ mise a jours a faire dans les autres langues ↓↓
	vehicules_btn: "🗂️ Vehicules",		
	elog_day: "Jour",
	elog_week: "Semaine",
	villeActuelle: "Ville",
	elEtat: "État / Province",
	pays: "Pays",
	immat_non_def: "⚠️ Merci de renseigner les plaques des remorques secondaires dans la page VEHICULES pour respecter la réglementation de ce convoi !", //plaque supp a informer
	trailer_model: "Type",
	trailer: "Remorque",
	trailer1: "Trailer 1",
	trailer2: "Trailer 2",
	trailer3: "Trailer 3",
	plate_placeholder: "Mettre plaque d’immatriculation",
	saveTrailerPlates: "Enregistrer plaques secondaires",
	vehicules: "Véhicules",
	camion: "Camion",
	marque: "Marque",
	modele: "Modèle",
	plaque_immat_truck: "Plaque d'immatriculation",
	
	
	overlay_move: "Deplacer l'Overlay",
	copyright: "©2025 ATS Elog développé par Eric R",
	version: "",
	
	reset_cache: "Reinitialiser le cache de l'overlay",
	
	a_propos_txt1:"Informations",
	a_propos_txt2: "Je suis camionneur de métier et passionné de simulation. ATS Elog est un projet personnel que je développe seul : je ne suis pas codeur, j’apprends en avançant, en cherchant les infos et en testant.",
	a_propos_txt3: "Je me heurte souvent à des obstacles, mais je finis toujours par les surmonter. Merci pour votre patience et votre soutien.",
	a_propos_txt5: "Pour plus d’informations et les liens officiels, rejoignez-moi :",
	a_propos_txt6:"Discord",
	a_propos_txt8:"Forum SCS Software",
	thanks_cities: "Merci pour la contribution des villes :",
	Convoy_MP: "Convoi/MP (réset manuelle des heures)",
	envoyer_city: "Envoyer",
	ajout_ville: "Ajouter une nouvelle ville",
	dev: "Ajouter une ville",
	dev_intro: "Ajoute des villes manquantes à la base. Tes contributions aident toute la communauté ATS Elog.",
	gps_coords: "Coordonnées GPS",
	
	update_title: "Nouvelle version disponible",
    current_version:"Version actuelle",
    latest_version:"Dernière version",
    later: "Plus tard",
    dont_show: "Ne plus afficher pour cette version",
	download: "Télécharger",
	install_wait: "Veuillez patienter",
	install_wait_mobile_manual: "Installation de l’application manuelle",
	application_web: "Installer l’application",
	pwa_tip0: "Windows: En haut a droite de la barre d’adresse, il doit avoir une icone qui propose d’installer en Application",
    pwa_tip: "iPhone/iPad: Bouton Partager → Ajouter à l’écran d’accueil.",
    pwa_tip2: "Android: Ouvrir avec App Internet natif(Samsung Internet) → Menu en bas a droite → Ajouter à → Écran d’accueil. Autre navigateur = racourci web et pas la version application",
	text_ip: "Lien pour interface Externe (mobile/Tablette):",
    bouton_ip: "Afficher",
    text_ip1: "Accès depuis un autre appareil",
    text_ip2: "Utilise ce lien sur ton téléphone / tablette :",
    fermer: "Fermer",
	reset_cache_app: "⚠️ Vider le cache ⚠️",
	
	features_title: "Fonctionnalités",
	arcade_mode: "Mode Arcade",
	simulation_mode: "Mode Simulation",
	changelog: "Historique",

	// Arcade
	arcade_fatigue_on: "Activer la simulation de la fatigue dans le jeu (redémarrage d’ATS requis lorsque vous cochez/décochez la case pour que le plugin change de mode).",
	arcade_auto_control: "Contrôle des statuts ON / SB / D 100 % automatique.",
	arcade_buttons_locked: "Boutons OFF / SB / ON non cliquables.",
	arcade_driving_5mph: "DRIVING détecté automatiquement ≥ 5 mph.",
	arcade_reset_service: "Réinitialiser le temps de service = dormir sur les emplacements.",
	arcade_reset_cycle: "Réinitialiser le cycle = dormir 3 fois de suite sans interruption.",


	// Simulation
	sim_fatigue_off: "Désactiver la simulation de la fatigue dans le jeu (redémarrage d’ATS requis lorsque vous cochez/décochez la case pour que le plugin change de mode).",
	sim_manual_buttons_warn: "Boutons OFF / SB / ON manuels (attention lors des pauses).",
	sim_driving_5mph: "DRIVING automatique ≥ 5 mph.",
	sim_secondary_plates_required: "Plaques d’immatriculation secondaires des remorques obligatoires (bi-train/double/triple).",
	sim_dev_console_enable: "Activer la console développeur pour avancer le temps librement et débloquer la caméra libre (voir tuto ci-dessous).",
	sim_daily_rest: "Repos journalier = dormir ou 10 h.",
	sim_cycle_34h_variants: "Repos cycle 34 h (3 pauses + 4 h ou 24 h + 10 h).",

	tuto_title: "Tuto",
	tuto_dev_console_path: "Console Développeur : allez dans « Documents → American Truck Simulator → config.cfg », recherchez « uset g_console \"0\" » et « uset g_developer \"0\" », remplacez « 0 » par « 1 », enregistrez, puis démarrez ATS.",
	tuto_free_cam_keys: "Activer la caméra libre : touche 0 (au-dessus de P). Déplacements au pavé numérique : 9/3 = monter/descendre, 8/5 = avancer/reculer, 4/6 = gauche/droite ; molette souris = vitesse.",
	tuto_open_console: "Ouvrir la console développeur : touche « ~ » (au-dessus de Tab).",
	tuto_change_time: "Changer l’heure (attention à votre statut OFF/SB/ON) : ex. aller à 5h30 → commande : g_set_time 5.50",


	changelog_empty: "Aucun changelog disponible pour le moment.",

},
  en: {
    hos: "HOS",
    home: "Home",
    settings: "Settings",
    logs: "LogBooks",
    about: "About",
	titre_about: "ATS Elog — About",
    rest_in: "Rest",
    drive_rem: "Drive remaining",
    rest_Rem: "Service remaining",
    cycle_rem: "70h/8 days cycle",
    language: "Language",
    ats_timezone: "ATS Timezone",
    endpoint: "Data endpoint",
    save: "Save",
    saved: "Saved!",
    editChauffeur: "Driver name",
	vehicules_btn: "🗂️ Vehcicle",
	elog_day: "Day",
	elog_week: "Week",
	villeActuelle: "City",
	elEtat: "State / Province",
	pays: "Country",
	immat_non_def: "⚠️ Please fill in the secondary trailer license plates on the VEHICLES page to comply with regulations for this convoy!",	//plaque supp a informer
	trailer_model: "Type",
	trailer: "Trailer",
	trailer1: "Trailer 1",
	trailer2: "Trailer 2",
	trailer3: "Trailer 3",
	plate_placeholder: "Enter license plate",
	saveTrailerPlates: "Save secondary plates",
	vehicules: "Vehicles",
    camion: "Truck",
    marque: "Make",
    modele: "Model",
    plaque_immat_truck: "License Plate",

    copyright: "©2025 ATS Elog developed by Eric R",
    version: "",
	overlay_move: "Move the overlay",
	reset_cache: "Clear the overlay cache",
	a_propos_txt1: "Information",
    a_propos_txt2: "I'm a professional truck driver and a simulation enthusiast. ATS Elog is a one-person project—I'm not a programmer; I learn as I go, researching and experimenting.",
	a_propos_txt3: "I often run into hurdles, but I work through them over time. Thank you for your patience and support.",
	a_propos_txt5: "For more information and official links, join me:",
    a_propos_txt6: "Discord",
    a_propos_txt8: "SCS Software Forum:",
	thanks_cities: "Thanks for city contributions:",
	Convoy_MP: "Convoy/MP (manual hours reset)",
	envoyer_city: "Send",
	ajout_ville: "Add a new city",
	dev: "Add a city",
	dev_intro: "Add missing cities to the database. Your contributions help the entire ATS Elog community.",
	gps_coords: "",
	
	update_title: "New version available",
    current_version: "Current version",
    latest_version: "Latest version",
    later: "Later",
    dont_show: "Don't show again for this version",
	download: "Download",
	install_wait: "Please wait",
	install_wait_mobile_manual: "Manual app installation",
	application_web: "Install PC application",
    pwa_tip: "On iPhone/iPad: Share → Add to Home Screen.<br>On Android/Chrome/Microsoft Edge: Browser menu → Install app.",
    text_ip: "External interface link (Mobile/Tablet):",
    bouton_ip: "Show",
    text_ip1: "Access from another device",
    text_ip2: "Use this link on your phone/tablet:",
    fermer: "Close",
	reset_cache_app: "⚠️ Clear Cache ⚠️",
	
	features_title: "Features",
	arcade_mode: "Arcade Mode",
	simulation_mode: "Simulation Mode",
	changelog: "Changelog",

	// Arcade
	arcade_fatigue_on: "Enable fatigue simulation in the game (restarting ATS is required when you check/uncheck the box so the plugin switches mode).",
	arcade_auto_control: "100% automatic control of ON / SB / D states.",
	arcade_buttons_locked: "OFF / SB / ON buttons are disabled.",
	arcade_driving_5mph: "DRIVING detected automatically ≥ 5 mph.",
	arcade_reset_service: "Reset service time = sleep at rest areas.",
	arcade_reset_cycle: "Reset cycle = sleep three times in a row without interruption.",

	// Simulation
	sim_fatigue_off: "Disable fatigue simulation in the game (restarting ATS is required when you check/uncheck the box so the plugin switches mode).",
	sim_manual_buttons_warn: "Manual OFF / SB / ON buttons (be careful with pauses).",
	sim_driving_5mph: "DRIVING automatic ≥ 5 mph.",
	sim_secondary_plates_required: "Secondary trailer license plates required (double/triple).",
	sim_dev_console_enable: "Enable the developer console to skip time freely and unlock the free camera (see tutorial below).",
	sim_daily_rest: "Daily rest = sleep or 10 h.",
	sim_cycle_34h_variants: "34-hour cycle rest (3 breaks + 4 h or 24 h + 10 h).",

	tuto_title: "Tutorial",
	tuto_dev_console_path: "Developer Console: go to “Documents → American Truck Simulator → config.cfg”, find “uset g_console \"0\"” and “uset g_developer \"0\"”, change “0” to “1”, save, then start ATS.",
	tuto_free_cam_keys: "Enable free camera: key 0 (above P). Numpad: 9/3 = up/down, 8/5 = forward/back, 4/6 = left/right; mouse wheel = speed.",
	tuto_open_console: "Open the developer console: “~” (above Tab).",
	tuto_change_time: "Change time (watch your OFF/SB/ON status): e.g., to 5:30 → command: g_set_time 5.50",


	changelog_empty: "No changelog available at the moment.",

	
  },

  es: {
    hos: "HOS",                             // HOS (Horas de Servicio) utilisé partout en Espagne/Amérique Latine
    home: "Inicio",
    settings: "Configuración",
    logs: "Registros",
    about: "Acerca de",
	titre_about: "ATS Elog — Acerca de",
    rest_in: "Descanso",
    drive_rem: "Conducción restante",
    rest_Rem: "Servicio restante",
    cycle_rem: "Ciclo de 70h/8 días",
    language: "Idioma",
    ats_timezone: "Zona horaria ATS",
    endpoint: "Endpoint de datos",
    save: "Guardar",
    saved: "¡Guardado!",
    editChauffeur: "Nombre del conductor",
	vehicules_btn: "🗂️ Vehículos",
	elog_day: "Día",
	elog_week: "Semana",
	villeActuelle: "Ciudad",
	elEtat: "Estado / Provincia",
	pays: "País",
	immat_non_def: "⚠️ ¡Por favor, rellene las matrículas de los remolques secundarios en la página VEHICULOS para cumplir con la normativa de este convoy!",	//plaque supp a informer
    trailer_model: "Tipo",
	trailer: "Remolque",
	trailer1: "Remolque 1",
	trailer2: "Remolque 2",
	trailer3: "Remolque 3",
	plate_placeholder: "Introducir matrícula",
	saveTrailerPlates: "Guardar placas secundarias",
	vehicules: "Vehículos",
	camion: "Camión",
    marque: "Marca",
    modele: "Modelo",
    plaque_immat_truck: "Matrícula",
	
	copyright: "©2025 ATS Elog desarrollado por Eric R",
    version: "",
	overlay_move: "Mover la superposición",
	reset_cache: "Borrar la caché de la superposición",
	a_propos_txt1: "Información",
	a_propos_txt2: "Soy camionero de profesión y un apasionado de la simulación. ATS Elog es un proyecto de una sola persona; no soy programador: aprendo sobre la marcha, investigando y probando.",
	a_propos_txt3: "A menudo me encuentro con obstáculos, pero con el tiempo los supero. Gracias por su paciencia y apoyo.",
	a_propos_txt5: "Para más información y enlaces oficiales, únete aquí:",
    a_propos_txt6: "Discord",
    a_propos_txt8: "Foro de SCS Software:",
	thanks_cities: "Gracias por contribuir con ciudades:",
	Convoy_MP: "Convoy/MP (reinicio manual de las horas)",
	envoyer_city: "Enviar",
	ajout_ville: "Agregar una nueva ciudad",
	dev: "Agregar ciudad",
	dev_intro: "Añade ciudades faltantes a la base de datos. Tus aportes ayudan a toda la comunidad de ATS Elog.",
	gps_coords: "",
	
	update_title: "Nueva versión disponible",
    current_version:"Versión actual",
    latest_version:"Última versión",
    later: "Más tarde",
    dont_show: "No volver a mostrar para esta versión",
	download: "Descargar",
	install_wait: "Por favor espere",
	install_wait_mobile_manual: "Instalación manual de la aplicación",
	application_web: "Instalar aplicación para PC",
    pwa_tip: "En iPhone/iPad: Compartir → Añadir a la pantalla de inicio.<br>En Android/Chrome/Microsoft Edge: menú del navegador → Instalar aplicación.",
    text_ip: "Enlace de interfaz externa (Móvil/Tableta):",
    bouton_ip: "Mostrar",
    text_ip1: "Acceso desde otro dispositivo",
    text_ip2: "Usa este enlace en tu teléfono / tableta:",
    fermer: "Cerrar",
	reset_cache_app: "⚠️ Borrar caché ⚠️", 
	
	features_title: "Funcionalidades",
	arcade_mode: "Modo Arcade",
	simulation_mode: "Modo Simulación",
	changelog: "Cambios",

	// Arcade
	arcade_fatigue_on: "Activar la simulación de fatiga en el juego (se requiere reiniciar ATS cuando marques/desmarques la casilla para que el plugin cambie de modo).",
	arcade_auto_control: "Control 100 % automático de los estados ON / SB / D.",
	arcade_buttons_locked: "Botones OFF / SB / ON deshabilitados.",
	arcade_driving_5mph: "DRIVING detectado automáticamente ≥ 5 mph.",
	arcade_reset_service: "Restablecer el tiempo de servicio = dormir en áreas de descanso.",
	arcade_reset_cycle: "Restablecer el ciclo = dormir 3 veces seguidas sin interrupción.",

	
	// Simulation
	sim_fatigue_off: "Desactivar la simulación de fatiga en el juego (se requiere reiniciar ATS cuando marques/desmarques la casilla para que el plugin cambie de modo).",
	sim_manual_buttons_warn: "Botones OFF / SB / ON manuales (cuidado con las pausas).",
	sim_driving_5mph: "DRIVING automático ≥ 5 mph.",
	sim_secondary_plates_required: "Placas secundarias de los remolques obligatorias (bi-tren/doble/triple).",
	sim_dev_console_enable: "Activar la consola de desarrollador para adelantar el tiempo libremente y desbloquear la cámara libre (ver tutorial abajo).",
	sim_daily_rest: "Descanso diario = dormir o 10 h.",
	sim_cycle_34h_variants: "Descanso de ciclo de 34 h (3 pausas + 4 h o 24 h + 10 h).",

	tuto_title: "Tutorial",
	tuto_dev_console_path: "Consola de desarrollador: ve a « Documentos → American Truck Simulator → config.cfg », busca « uset g_console \"0\" » y « uset g_developer \"0\" », cambia « 0 » por « 1 », guarda y arranca ATS.",
	tuto_free_cam_keys: "Activar la cámara libre: tecla 0 (encima de P). Teclado numérico: 9/3 = subir/bajar, 8/5 = avanzar/retroceder, 4/6 = izquierda/derecha; rueda del ratón = velocidad.",
	tuto_open_console: "Abrir la consola de desarrollador: « ~ » (encima de Tab).",
	tuto_change_time: "Cambiar la hora (ojo con el estado OFF/SB/ON): p. ej., a las 5:30 → comando: g_set_time 5.50",


	changelog_empty: "No hay registro de cambios disponible por el momento.",

	
},
  de: {
    hos: "LZV",                        // HOS = Lenk- und Ruhezeiten (abrégé LZV)
    home: "Startseite",
    settings: "Einstellungen",
    logs: "Protokolle",
    about: "Über",
	titre_about: "ATS Elog — Über",
    rest_in: "Pause",                   // "Repos" (pause, repos, etc.)
    drive_rem: "Restfahrzeit",          // "Conduite restante"
    rest_Rem: "Restdienstzeit",         // "Service restant"
    cycle_rem: "70-Stunden-Zyklus / 8 Tage",
    language: "Sprache",
    ats_timezone: "ATS-Zeitzone",
    endpoint: "Daten-Endpunkt",
    save: "Speichern",                  // "Enregistrer"
    saved: "Gespeichert!",              // "Sauvegardé !"
    editChauffeur: "Fahrername",        // "Nom du Conducteur"
	vehicules_btn: "🗂️ Fahrzeuge",
	elog_day: "Tag",
	elog_week: "Woche",
	villeActuelle: "Stadt",
	elEtat: "Bundesstaat / Provinz",
	pays: "Land",
	immat_non_def: "⚠️ Bitte geben Sie die Kennzeichen der zusätzlichen Anhänger auf der FAHRZEUGE-Seite ein, um die Vorschriften für diesen Konvoi einzuhalten!", //plaque supp a informer
    trailer_model: "Typ",
	trailer: "Anhänger",
	trailer1: "Anhänger 1",
	trailer2: "Anhänger 2",
	trailer3: "Anhänger 3",
	plate_placeholder: "Kennzeichen eingeben",
	saveTrailerPlates: "Sekundäre Kennzeichen speichern",
	vehicules: "Fahrzeuge",
	camion: "Lkw",
    marque: "Marke",
    modele: "Modell",
    plaque_immat_truck: "Kennzeichen",
	
	copyright: "©2025 ATS Elog entwickelt von Eric R",
    version: "",
	overlay_move: "Overlay verschieben",
	reset_cache: "Overlay-Cache leeren",
	a_propos_txt1: "Informationen",
	a_propos_txt2: "Ich bin Berufskraftfahrer und Simulations-Fan. ATS Elog ist ein Ein-Mann-Projekt – ich bin kein Programmierer; ich lerne Schritt für Schritt, recherchiere und teste.",
	a_propos_txt3: "Es gibt oft Hürden, aber mit der Zeit meistere ich sie. Danke für eure Geduld und eure Unterstützung.",
	a_propos_txt5: "Weitere Infos und offizielle Links findest du hier:",
    a_propos_txt6: "Discord",
    a_propos_txt8: "SCS Software Forum:",
	thanks_cities: "Danke für die Städte-Beiträge:",
	Convoy_MP: "Konvoi/MP (manuelles Zurücksetzen der Stunden)",
	envoyer_city: "Senden",
	ajout_ville: "Neue Stadt hinzufügen",
	dev: "Stadt hinzufügen",
	dev_intro: "Füge fehlende Städte zur Datenbank hinzu. Deine Beiträge helfen der gesamten ATS-Elog-Community.",
	gps_coords: "",
	
	update_title: "Neue Version verfügbar",
    current_version: "Aktuelle Version",
    latest_version: "Neueste Version",
    later: "Später",
    dont_show: "Für diese Version nicht mehr anzeigen",
    download: "Herunterladen",
	install_wait: "Bitte warten",
	install_wait_mobile_manual: "Manuelle App-Installation",
	application_web: "PC-Anwendung installieren",
    pwa_tip: "Auf iPhone/iPad: Teilen → Zum Home-Bildschirm hinzufügen.<br>Auf Android/Chrome/Microsoft Edge: Browser-Menü → App installieren.",
    text_ip: "Externer Schnittstellen-Link (Mobil/Tablet):",
    bouton_ip: "Anzeigen",
    text_ip1: "Zugriff von einem anderen Gerät",
    text_ip2: "Verwende diesen Link auf deinem Handy / Tablet:",
    fermer: "Schließen",
	reset_cache_app: "⚠️ Cache leeren ⚠️",
	
	features_title: "Funktionen",
	arcade_mode: "Arcade-Modus",
	simulation_mode: "Simulationsmodus",
	changelog: "Änderungen",
	
	// Arcade
	arcade_fatigue_on: "Ermüdungssimulation im Spiel aktivieren (ATS-Neustart erforderlich, wenn du das Kästchen an-/abwählst, damit das Plugin den Modus wechselt).",
	arcade_auto_control: "100 % automatische Steuerung der Zustände ON / SB / D.",
	arcade_buttons_locked: "Schaltflächen OFF / SB / ON deaktiviert.",
	arcade_driving_5mph: "DRIVING automatisch erkannt ≥ 5 mph.",
	arcade_reset_service: "Dienstzeit zurücksetzen = auf Rastplätzen schlafen.",
	arcade_reset_cycle: "Zyklus zurücksetzen = drei Mal hintereinander ohne Unterbrechung schlafen.",

	
	 // Simulation
	sim_fatigue_off: "Ermüdungssimulation im Spiel deaktivieren (ATS-Neustart erforderlich, wenn du das Kästchen an-/abwählst, damit das Plugin den Modus wechselt).",
	sim_manual_buttons_warn: "Manuelle OFF / SB / ON-Schaltflächen (Achtung bei Pausen).",
	sim_driving_5mph: "DRIVING automatisch ≥ 5 mph.",
	sim_secondary_plates_required: "Zusätzliche Anhängerkennzeichen erforderlich (Bi-Train/Double/Triple).",
	sim_dev_console_enable: "Entwicklerkonsole aktivieren, um die Zeit frei zu verstellen und die freie Kamera zu entsperren (siehe Tutorial unten).",
	sim_daily_rest: "Tägliche Ruhe = schlafen oder 10 h.",
	sim_cycle_34h_variants: "34-Stunden-Zyklusruhe (3 Pausen + 4 h oder 24 h + 10 h).",

	tuto_title: "Tutorial",
	tuto_dev_console_path: "Entwicklerkonsole: Datei „Dokumente → American Truck Simulator → config.cfg“, Zeilen „uset g_console \"0\"“ und „uset g_developer \"0\"“ suchen, „0“ durch „1“ ersetzen, speichern und ATS starten.",
	tuto_free_cam_keys: "Freie Kamera aktivieren: Taste 0 (über P). Ziffernblock: 9/3 = hoch/runter, 8/5 = vor/zurück, 4/6 = links/rechts; Mausrad = Geschwindigkeit.",
	tuto_open_console: "Entwicklerkonsole öffnen: „~“ (über Tab).",
	tuto_change_time: "Uhrzeit ändern (Achtung auf OFF/SB/ON-Status): z. B. 5:30 → Befehl: g_set_time 5.50",

	changelog_empty: "Derzeit kein Änderungsprotokoll verfügbar.",

	
}
};

const langSel = document.getElementById("lang");
const LANG = localStorage.getItem('lang') || 'fr';

// au chargement des réglages
const convoyEl = document.getElementById('convoyMode');
if (convoyEl) convoyEl.checked = localStorage.getItem('convoy_mode') === '1';

function applyTranslations() {
  // remplace l’utilisation de LANG par currentLang
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n;
    const txt = translations[currentLang]?.[key];
    if (txt != null) el.textContent = txt;
  });

  // version UI (si tu veux la garder ici)
  const version = document.querySelectorAll('[data-version]');
  version.forEach(el => el.textContent = "v1.1.14");
}

// Langue courante (synchro avec ton stockage)
window.currentLang = localStorage.getItem('lang') || 'fr';

// Raccourci de traduction
function t(key){
  return (translations[currentLang] && translations[currentLang][key])
      || (translations.fr && translations.fr[key])
      || key;
}

// Appliquer les traductions sur un sous-arbre (ou tout le doc)
function applyI18n(root = document){
  root.querySelectorAll('[data-i18n]').forEach(el => {
    const k = el.dataset.i18n;
    const v = t(k);
    if (v != null) el.textContent = v;
  });
}



/* === Popup MAJ == */
function normalizeVer(v){ return String(v || '').trim().replace(/^v/i,''); }

function showUpdateModal(currentVer, latestVer, links){
  let el = document.getElementById('update-modal');
  if (!el) {
    el = document.createElement('div');
    el.id = 'update-modal';
    el.className = 'update-modal';
    el.innerHTML = `
      <div class="update-card">
        <h3 data-i18n="update_title">Nouvelle version disponible</h3>
        <p><strong data-i18n="current_version">Version actuelle</strong> : <span class="cur">—</span></p>
        <p><strong data-i18n="latest_version">Dernière version</strong> : <span class="latest">—</span></p>
        <div class="update-links"></div>
        <div class="update-actions">
          <button class="btn" data-close data-i18n="later">Plus tard</button>
          <button class="btn btn-primary" data-skip data-i18n="dont_show">Ne plus afficher pour cette version</button>
        </div>
      </div>`;
    document.body.appendChild(el);
    el.querySelector('[data-close]').onclick = () => el.classList.remove('show');
    el.querySelector('[data-skip]').onclick  = () => {
      const v = el.getAttribute('data-latest') || '';
      localStorage.setItem('atselog.skipVersion', v);
      el.classList.remove('show');
    };
  }
  el.querySelector('.cur').textContent    = currentVer || '—';
  el.querySelector('.latest').textContent = latestVer  || '—';
  el.setAttribute('data-latest', latestVer || '');

  const box = el.querySelector('.update-links');
box.innerHTML = '';
(links || []).forEach(li => {
  const wrap = document.createElement('div');

  const a = document.createElement('a');
  a.className = 'btn btn-primary btn-download';
  a.href = li.url || li; a.target = '_blank'; a.rel = 'noopener';
  a.textContent = t('download');   // <- i18n correct
  wrap.appendChild(a);

  if (li.text && li.text !== li.url) {
    const cap = document.createElement('div');
    cap.className = 'caption';
    cap.textContent = li.text;
    wrap.appendChild(cap);
  }
  box.appendChild(wrap);
});

// ⇩⇩ ajoute cette ligne pour traduire tous les [data-i18n] de la modale
applyI18n(el);

el.classList.add('show');}

async function checkVersionAgainstSheet(){
  try{
    // 1) Version du plugin
    const d = await fetch(`${endpoint}?t=${Date.now()}`).then(r=>r.json()).catch(()=>({}));
    const current = normalizeVer(d.version || (document.querySelector('.ui-version')?.textContent || ''));

    // 2) Version & liens depuis le Sheet via GAS
    const meta = await jsonp(`${window.GAS_URL}?meta=1`).catch(()=>null);
    if (!meta || !meta.version) return;

    const latest = normalizeVer(meta.version);
    if (!current || !latest) return;
    if (latest === localStorage.getItem('atselog.skipVersion')) return; // ignorée auparavant
    if (latest !== current) showUpdateModal(current, latest, meta.links || []);
  }catch(e){ console.warn('[UpdateCheck]', e); }
}

/* == Fin Popup MAJ ==*/

/* === Boot TZ from cache (avant tout rendu) === */
(function bootTzFromCache() {
  try {
    const raw = localStorage.getItem('atselog.tz');
    if (!raw) return;
    const o = JSON.parse(raw);
    // Priorité au nouveau champ offFinal ; fallback sur l'ancien off
    const off = Number.isFinite(o?.offFinal) ? o.offFinal : Number(o?.off);
    if (Number.isFinite(off)) window.timeZoneOffset = off;  // heures "finales"
    if (typeof o?.abbr === 'string') window.timeZoneAbbr = o.abbr;
  } catch {}
})();



// --- PRIORITÉ SOURCES VILLES: SHEET > TRUCKY > LOCAL ---
function getTruckyCities() {
  return fetch("https://api.truckyapp.com/v2/map/cities/ats")
    .then(r => r.json())
    .then(d => Array.isArray(d?.response) ? d.response : [])
    .catch(() => []);
}

// clé stable pour dédoublonner (même ville/état/coord ≈ même clé)
function _cityKey(c) {
  return [
    (c.realName || c.name || "").toLowerCase().trim(),
    (c.country || "").toLowerCase().trim(),
    Math.round(Number(c.x) || 0),
    Math.round(Number(c.z) || 0)
  ].join("|");
}

// fusion avec priorité au 2e puis 3e … (dernier gagne)
function mergeByPriority(...lists) {
  const map = new Map();
  for (const list of lists) {
    for (const c of list || []) map.set(_cityKey(c), c);
  }
  return [...map.values()];
}

// === GOOGLE SHEET (GLOBAL) ===============================================
// URL du dernier déploiement WebApp (global)
window.GAS_URL = 'https://script.google.com/macros/s/AKfycbxraUXnnhHVusEgeT6DnX3gI5v21WHh643y74GAyf8WJxx3Ejt__n9UMiSvbQx_D7TM/exec';


// JSONP utilitaire global (pas de CORS)
function jsonp(url) {
  return new Promise((resolve, reject) => {
    const cb = 'gascb_' + Math.random().toString(36).slice(2);
    const s  = document.createElement('script');
    const sep = url.includes('?') ? '&' : '?';
    s.src = `${url}${sep}callback=${cb}`;
    window[cb] = (payload) => { delete window[cb]; s.remove(); resolve(payload); };
    s.onerror  = () => { delete window[cb]; s.remove(); reject(new Error('JSONP échoué')); };
    document.body.appendChild(s);
  });
}


// Récupère les villes depuis le Sheet et normalise -> {realName,country,x,z}
async function fetchSheetCities() {
  try {
    const payload = await jsonp(`${window.GAS_URL}?list=1`);
    const rows = Array.isArray(payload?.rows) ? payload.rows : [];
    return rows.map(r => ({
      realName: r.realName || r.city || r.name || '',
      country:  r.country  || r.stateCountry || '',
      x: Number(r.x ?? r.pos_x ?? r.lon ?? 0),
      z: Number(r.z ?? r.pos_z ?? r.lat ?? 0),
    })).filter(c => c.realName && isFinite(c.x) && isFinite(c.z));
  } catch (e) {
    console.warn('[Sheet] lecture échouée → fallback', e);
    return [];
  }
}


// CHARGEMENT CENTRALISÉ: d’abord Sheet, puis on complète avec Trucky/Local
async function initCitiesPriority() {
  const pSheet  = fetchSheetCities().catch(() => []);
  const pTrucky = getTruckyCities().catch(() => []);
  const local   = normalizeLocalCities(loadLocalCities());

  // 1) Attendre le Sheet d'abord
  const sheet = await pSheet;

  if (sheet.length) {
    // Sheet prêt ⇒ on le publie tout de suite (priorité Sheet)
    window.citiesFinal = mergeByPriority(local, sheet);   // sheet gagne
    window.citiesReady = true;
    window.citiesLoadedFrom = "sheet";
    console.log("[Cities] source = sheet, total =", window.citiesFinal.length);
    if (window.lastGameData) updateUI(window.lastGameData);
  }

  // 2) Quand Trucky arrive, on complète (sans casser les villes du Sheet)
  const trucky = await pTrucky;
  const merged = mergeByPriority(local, trucky, sheet);   // ordre => dernier gagne (sheet)
  window.citiesFinal = merged;

  // 3) Fallback si le Sheet était vide
  if (!window.citiesReady) {
    window.citiesReady = true;
    window.citiesLoadedFrom = trucky.length ? "trucky" : "local";
    console.log("[Cities] source =", window.citiesLoadedFrom, "total =", merged.length);
    if (window.lastGameData) updateUI(window.lastGameData);
  }
}



// --- ÉTAPE 1 : FONCTIONS D'IMPORT ET DE FUSION ---
function loadLocalCities() {
  if (!window.citiesATS) {
    console.warn("Variable citiesATS non trouvée, vérifie l'inclusion du fichier cities-ats.js");
    return {};
  }
  return window.citiesATS;
}

function normalizeLocalCities(localCities) {
  const normalized = [];
  Object.entries(localCities).forEach(([key, city]) => {
    const coordX = Number(city.x || city.coord_x);
    const coordZ = Number(city.z || city.coord_y);
    if (!city || isNaN(coordX) || isNaN(coordZ)) return;
    normalized.push({
      _id: key,
      realName: city.realName || city.name || "",
      x: coordX,
      z: coordZ,
      country: city.country || '',
      dlc: city.dlc || '',
      mod: city.mod || '',
      relative_radius: city.relative_radius || 0.5,
      timezone: city.timezone || ''
    });
  });
  return normalized;
}


function mergeCities(truckyCities, localCitiesNormalized) {
  const map = new Map();
  truckyCities.forEach(city => { if (city._id) map.set(city._id, city); });
  localCitiesNormalized.forEach(city => { if (!map.has(city._id)) map.set(city._id, city); });
  return Array.from(map.values());
}



function showToast(msg, duration = 1000) { // <-- par défaut : 2 secondes
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = msg;
  toast.style.display = 'block';
  clearTimeout(showToast._timeout);
  showToast._timeout = setTimeout(() => {
    toast.style.display = 'none';
  }, duration);
}

// --- sauvegarde du réglage "Mode convoi" quand on clique Enregistrer ---
document.addEventListener('DOMContentLoaded', () => {
  const convoyEl = document.getElementById('convoyMode');
  const saveBtn  = document.getElementById('saveBtn');

  // (re)cocher la case selon l'état sauvé
  if (convoyEl) convoyEl.checked = localStorage.getItem('convoy_mode') === '1'; // déjà présent chez toi

  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      if (convoyEl) localStorage.setItem('convoy_mode', convoyEl.checked ? '1' : '0');
      // ta logique existante: toast + redirection…
    });
  }
});


// --- FUSEAU HORAIRE LOCAL VIA API TRUCKY ---
let truckyCities = [];
let allCities = [];

/*fetch("https://api.truckyapp.com/v2/map/cities/ats")
  .then(r => r.json())
  .then(d => {
    truckyCities = d.response;
    const localCitiesRaw = loadLocalCities();
    const localCities = normalizeLocalCities(localCitiesRaw);
    allCities = mergeCities(truckyCities, localCities);
    if (window.lastGameData) updateUI(window.lastGameData);
  })
  .catch((e) => { truckyCities = []; allCities = []; });
*/
  

// Offsets RELATIFS à l’heure de base ATS (MDT)
const TZ = {
  pac: { off: -1, abbr: "PDT" }, // Pacific = 1h plus tôt que MDT
  mtn: { off:  0, abbr: "MDT" }, // Mountain = base ATS
  cen: { off: +1, abbr: "CDT" }, // Central = +1h vs MDT
  est: { off: +2, abbr: "EDT" }  // Eastern = +2h vs MDT
  // Optionnel: ak: { off: -2, abbr: "AKDT" }  // Alaska (si tu l’ajoutes au mapping)
};

function setPickedTZ(tz) {
  window.timeZoneOffset = tz.off;    // offset RELATIF à MDT (en heures)
  window.timeZoneAbbr   = tz.abbr;
  try {
    localStorage.setItem('atselog.tz', JSON.stringify({
      offFinal: tz.off,
      abbr: tz.abbr
    }));
  } catch {}
}



// Trouve la ville la plus proche (selon coord du jeu)
function nearestCity(px, pz) {
  const list = Array.isArray(window.citiesFinal) ? window.citiesFinal : [];
  if (!list.length) return null;
  let best = null, bestD2 = Infinity;
  for (const c of list) {
    const x = Number(c.x), z = Number(c.z);
    if (!isFinite(x) || !isFinite(z)) continue;
    const d2 = (px - x)*(px - x) + (pz - z)*(pz - z);
    if (d2 < bestD2) { bestD2 = d2; best = c; }
  }
  return best;
}





// Calcule l’heure locale selon la ville la plus proche
function getLocalGameTime(data) {
  if (!data.clock || typeof data.pos_x === "undefined" || typeof data.pos_y === "undefined") return data.clock || "--:--";
  const utcStr = (data && data.clock) || "--:--";
  const [H,M] = utcStr.split(':').map(v => parseInt(v,10) || 0);
  const utcMin = (H*60 + M) % 1440;
  const city = (window.citiesReady ? nearestCity(data.pos_x, data.pos_y) : null);
if (!city) {
  // Fallback: utiliser le dernier fuseau mémorisé pour afficher tout de suite
    const tzMeta = JSON.parse(localStorage.getItem('atselog.tz')||'{}');
	const offHr  = (typeof tzMeta.offFinal === 'number') ? tzMeta.offFinal
				 : (typeof window.timeZoneOffset === 'number') ? window.timeZoneOffset
				 : 0;
	const abbr   = tzMeta.abbr || window.timeZoneAbbr || '';
	if (Number.isFinite(offHr)) {
	  const localMin = (utcMin + offHr*60 + 1440) % 1440;
	  const hh = String(Math.floor(localMin/60)).padStart(2,'0');
	  const mm = String(localMin%60).padStart(2,'0');
	  return `${hh}:${mm}${abbr ? ' ' + abbr : ''}`;
	}

  
  // Pas de cache encore (première visite) → on garde l'heure brute
  return data.clock || "--:--";
}

  // Assignation du fuseau selon état US
  const state = city.country;
  let tz = TZ.cen; // Default = Central
// Mapping fuseaux horaires par nom d'État (state = champ Trucky)
// Mapping fuseaux horaires USA + Canada (compatibilité ATS, Promods Canada, TruckersMP, Trucky API)

// PACIFIC
  if ([
    // USA Pac
    "USA (CA)","USA (OR)","USA (WA)","USA (NV)",
	"California", "Oregon", "Washington", "Nevada",
    // Canada Pac
    "Canada (BC)","Canada (YT)",
    // Mexique Pac (Baja California)
    "Mexico (BC)"
  ].includes(state)) { tz = TZ.pac; }

  // MOUNTAIN
  else if ([
    // USA Mtn
    "USA (AZ)","USA (CO)","USA (ID)","USA (MT)","USA (NM)","USA (UT)","USA (WY)",
	"Arizona", "Colorado", "Idaho", "Montana", "New Mexico", "Utah", "Wyoming",
    // Canada Mtn
    "Canada (AB)","Canada (NT)",
    // Mexique Mtn
    "Mexico (BCS)","Mexico (SON)","Mexico (CHH)","Mexico (SIN)","Mexico (DGO)","Mexico (NAY)"
  ].includes(state)) { tz = TZ.mtn; }

  // CENTRAL
  else if ([
    // USA Cen
    "USA (AR)","USA (IA)","USA (IL)","USA (KS)","USA (LA)","USA (MN)","USA (MS)","USA (MO)",
    "USA (NE)","USA (ND)","USA (OK)","USA (SD)","USA (TX)","USA (WI)",
	
	"Arkansas", "Iowa", "Illinois", "Kansas", "Louisiana", "Minnesota", "Mississippi", "Missouri",
    "Nebraska", "North Dakota", "Oklahoma", "South Dakota", "Texas", "Wisconsin",
    // Canada Cen
    "Canada (SK)","Canada (MB)","Canada (NU)",
    // Mexique Cen
    "Mexico (ZAC)","Mexico (SLP)","Mexico (AGS)","Mexico (JAL)"
  ].includes(state)) { tz = TZ.cen; }

  // EASTERN
  else if ([
    // USA Est
    "USA (FL)","USA (GA)","USA (SC)","USA (NC)","USA (VA)","USA (OH)","USA (NY)","USA (PA)","USA (MI)","USA (IN)","USA (KY)","USA (WV)",
    "USA (MD)","USA (DE)","USA (NJ)","USA (CT)","USA (MA)","USA (RI)","USA (VT)","USA (NH)","USA (ME)","USA (DC)",
    
	"Florida", "Georgia", "South Carolina", "North Carolina", "Virginia", "Ohio", "New York",
    "Pennsylvania", "Michigan", "Indiana", "Kentucky", "West Virginia", "Maryland", "Delaware",
    "New Jersey", "Connecticut", "Massachusetts", "Rhode Island", "Vermont", "New Hampshire", "Maine",
	// Canada Est
    "Canada (ON)","Canada (QC)",
	
	// --- Caraïbes (UTC−5 = Eastern “réel”) ---
	"Bahamas (Grand Bahama)",   // Freeport
	"Bahamas (Abaco)",          // Treasure Cay
	"Bahamas (New Providence)", // Nassau
	"Cuba (Havana)",
	"Cuba (Guantanamo)", "Cuba (Guantánamo)", "Cuba (Guantanamo Bay)",
	"Jamaica (Kingston)",
	"Jamaica (Saint James)",    // Montego Bay

	// --- Caraïbes (UTC−4 = Atlantique) → fallback EST ---
	"Puerto Rico (San Juan)",
	"Puerto Rico (Ponce)",
	"Puerto Rico (Mayagüez)", "Puerto Rico (Mayaguez)",
	"Venezuela (Falcón)", "Venezuela (Falcon)", // Adícora, Coro, Punto Fijo (État de Falcón)
	"Aruba (Oranjestad)"
  ].includes(state)) { tz = TZ.est; }

  // ALASKA — si tu as un TZ.ak, sinon on rabat sur PAC pour rester compatible
  else if (["USA (AK)"].includes(state)) { tz = (TZ.ak || TZ.pac); }


  // Décale l’heure selon l’offset
  const localMin = (utcMin + offHr*60 + 1440) % 1440;
  const hh = String(Math.floor(localMin/60)).padStart(2,'0');
  const mm = String(localMin%60).padStart(2,'0');
  return `${hh}:${mm}${abbr ? ' ' + abbr : ''}`;
}


function parseHHMMtoSec(hhmm = "00:00") {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 3600 + m * 60;
}

function formatHMM(sec = 0) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  return `${String(h).padStart(2, '0')}h${String(m).padStart(2, '0')}`;
}
function formatHMStr(str = "--:--") {
  return str.replace(':', 'h');
}

// Affiche l'heure locale OU heure jeu selon settings
function updateDisplayedTime(data) {
  const el = document.getElementById('header-game-time');
if (!el) return;
const useTz = localStorage.getItem('ats_timezone') === '1';

if (useTz) {
  // 1) priorité au "local" calculé par le plugin
  if (data && data.clock_local) {
    const tzMeta = JSON.parse(localStorage.getItem('atselog.tz') || '{}');
    const abbr   = tzMeta.abbr || '';
    el.textContent = `${data.clock_local}${abbr ? ' ' + abbr : ''}`;
  } else {
    // 2) secours : calcul côté JS avec offset absolu
    el.textContent = getLocalGameTime(data || {});
  }
} else {
  // mode "UTC du jeu"
  el.textContent = (data && data.clock) ? data.clock : "--:--";
}

}
// Quand la case fuseau est cochée/décochée, ou offset changé :
function syncTimezoneWithPlugin(active, offset) {
  fetch(`/api/eld/timezone?active=${active ? 1 : 0}&offset=${offset}`)
    .then(r => r.text())
    .then(console.log)
    .catch(console.error);
}

// À appeler à chaque fois qu’on change le fuseau sur l’UI (ou position GPS si tu veux 100% auto)
const tz = document.getElementById('atsTimezone');
if (tz) {
  tz.checked = localStorage.getItem('ats_timezone') === '1';
  tz.addEventListener('change', () => {
    localStorage.setItem('ats_timezone', tz.checked ? '1' : '0');
    // Décale la timeline & sync plugin
    const active = tz.checked;
    const offset = active ? (window.timeZoneOffset || 0) : 0;
	console.log("Sync timezone", {active, offset}); 
    syncTimezoneWithPlugin(active, offset);
    updateDisplayedTime(window.lastGameData || {});
  });
}

// ==== HOS_OVERRUN_V2 — drive+work en négatif + somme sur primary (persistance) ====
(function(){
  const LSKEY = 'atselog.overrun.v2';

  function HHMM_to_sec(s) {
    if (!s) return NaN;
    const m = String(s).trim().replace(/^[-−]/,'').match(/^(\d{1,2}):(\d{2})$/);
    if (!m) return NaN;
    const sec = (+m[1])*3600 + (+m[2])*60;
    return /^[-−]/.test(String(s)) ? -sec : sec;
  }
  function sec_to_HHMM(sec){
    sec = Math.max(0, sec|0);
    const h = String(Math.floor(sec/3600)).padStart(2,'0');
    const m = String(Math.floor((sec%3600)/60)).padStart(2,'0');
    return `${h}:${m}`;
  }
  function normDayMin(min){ return ((min|0)%1440 + 1440) % 1440; }

  const S = (function load(){
    try { return JSON.parse(localStorage.getItem(LSKEY) || '{}'); } catch{ return {}; }
  })();
  if (!Number.isFinite(S.driveAccumMin)) S.driveAccumMin = 0;
  if (!Number.isFinite(S.workAccumMin))  S.workAccumMin  = 0;
  if (!Number.isFinite(S.lastGameMin))   S.lastGameMin   = null;
  if (typeof S.driveActive !== 'boolean') S.driveActive = false;
  if (typeof S.workActive  !== 'boolean') S.workActive  = false;

  function save(){ try{ localStorage.setItem(LSKEY, JSON.stringify(S)); }catch{} }

  window.HOS_OVERRUN_V2 = {
    update(data) {
      const elP = document.getElementById('primary-timer');
      const elD = document.getElementById('driveTimer');
      const elW = document.getElementById('workdayTimer');
      if (!elP || !elD || !elW) return;

      const gameMin   = normDayMin(data.game_time||0);
      const statusNum = data.status|0; // 0 OFF,1 SB,2 D,3 ON

      // Entrées en infraction (le plugin renvoie souvent 00:00 au plancher → on prend <=0)
      const driveRemSec = HHMM_to_sec(data.drive_rem);
      const workRemSec  = HHMM_to_sec(data.workday_rem || data.rest_rem);
      if (!S.driveActive && Number.isFinite(driveRemSec) && driveRemSec <= 0) S.driveActive = true;
      if (!S.workActive  && Number.isFinite(workRemSec)  && workRemSec  <= 0) S.workActive  = true;

      // Delta minute jeu depuis le dernier tick (wrap minuit OK)
      if (S.lastGameMin == null) S.lastGameMin = gameMin;
      let dMin = gameMin - S.lastGameMin;
      if (dMin < 0) dMin += 1440;
      S.lastGameMin = gameMin;

      // Accumuler uniquement pendant le bon statut
      if (statusNum === 2 && S.driveActive) S.driveAccumMin += dMin; // DRIVING
      if (statusNum === 3 && S.workActive)  S.workAccumMin  += dMin; // ON

      // Reset complet uniquement après repos (quand les DEUX timers redeviennent > 00:01)
      if ((S.driveActive || S.workActive) &&
          Number.isFinite(driveRemSec) && driveRemSec > 60 &&
          Number.isFinite(workRemSec)  && workRemSec  > 60) {
        S.driveActive = S.workActive = false;
        S.driveAccumMin = S.workAccumMin = 0;
        elP.dataset.isOverrun = elD.dataset.isOverrun = elW.dataset.isOverrun = '';
        elP.classList.remove('timer-violation','hos-pulse');
        elD.classList.remove('timer-violation');
        elW.classList.remove('timer-violation');
        save();
        return;
      }

      // Rendu: mettre négatif (au moins -00:01 dès l’entrée)
      const driveNegSec = S.driveActive ? Math.max(60, S.driveAccumMin*60) : 0;
      const workNegSec  = S.workActive  ? Math.max(60, S.workAccumMin*60)  : 0;

      // DRIVE
      if (S.driveActive) {
        elD.textContent = '-' + sec_to_HHMM(driveNegSec);
        elD.classList.add('timer-violation');
        elD.dataset.isOverrun = '1';
      } else if (elD.dataset.isOverrun === '1') {
        elD.dataset.isOverrun = '';
        elD.classList.remove('timer-violation');
        if (elD.dataset.rawTimer) elD.textContent = elD.dataset.rawTimer;
      }

      // WORKDAY
      if (S.workActive) {
        elW.textContent = '-' + sec_to_HHMM(workNegSec);
        elW.classList.add('timer-violation');
        elW.dataset.isOverrun = '1';
      } else if (elW.dataset.isOverrun === '1') {
        elW.dataset.isOverrun = '';
        elW.classList.remove('timer-violation');
        if (elW.dataset.rawTimer) elW.textContent = elW.dataset.rawTimer;
      }

      // PRIMARY = somme des deux négatifs
      const sumNegSec = driveNegSec + workNegSec;
        if (sumNegSec > 0) {
		  elP.textContent = '-' + sec_to_HHMM(sumNegSec);
		  elP.classList.add('timer-violation');   // pas de pulse
		  elP.dataset.isOverrun = '1';
		} else if (elP.dataset.isOverrun === '1') {
		  elP.dataset.isOverrun = '';
		  elP.classList.remove('timer-violation'); // pas de pulse
		  if (elP.dataset.rawTimer) elP.textContent = elP.dataset.rawTimer;
		}

      save();
    }
  };
})();


function updateUI(data) {
	// console.log("Coords ATS :", data.pos_x, data.pos_y, "type:", typeof data.pos_x, typeof data.pos_y);
	// console.log("[ATS-Plugin] Données reçues:", data);

  window.lastGameData = data;
  const isArcade = data.Auto === 1;
  
const city  = window.citiesReady ? nearestCity(Number(data.pos_x), Number(data.pos_y)) : null;
// Met à jour l'offset du fuseau horaire (pour la timeline)
if (city) {
  // Copie de la logique de getLocalGameTime
  let state   = city ? (city.country || '').trim() : '';
  let tz = TZ.cen; // Central par défaut
  // PACIFIC
  if ([
    // USA Pac
    "USA (CA)","USA (OR)","USA (WA)","USA (NV)",
	"California", "Oregon", "Washington", "Nevada",
    // Canada Pac
    "Canada (BC)","Canada (YT)",
    // Mexique Pac (Baja California)
    "Mexico (BC)"
  ].includes(state)) { tz = TZ.pac; }

  // MOUNTAIN
  else if ([
    // USA Mtn
    "USA (AZ)","USA (CO)","USA (ID)","USA (MT)","USA (NM)","USA (UT)","USA (WY)",
	"Arizona", "Colorado", "Idaho", "Montana", "New Mexico", "Utah", "Wyoming",
    // Canada Mtn
    "Canada (AB)","Canada (NT)",
    // Mexique Mtn
    "Mexico (BCS)","Mexico (SON)","Mexico (CHH)","Mexico (SIN)","Mexico (DGO)","Mexico (NAY)"
  ].includes(state)) { tz = TZ.mtn; }

  // CENTRAL
  else if ([
    // USA Cen
    "USA (AR)","USA (IA)","USA (IL)","USA (KS)","USA (LA)","USA (MN)","USA (MS)","USA (MO)",
    "USA (NE)","USA (ND)","USA (OK)","USA (SD)","USA (TX)","USA (WI)",
	
	"Arkansas", "Iowa", "Illinois", "Kansas", "Louisiana", "Minnesota", "Mississippi", "Missouri",
    "Nebraska", "North Dakota", "Oklahoma", "South Dakota", "Texas", "Wisconsin",
    // Canada Cen
    "Canada (SK)","Canada (MB)","Canada (NU)",
    // Mexique Cen
    "Mexico (ZAC)","Mexico (SLP)","Mexico (AGS)","Mexico (JAL)"
  ].includes(state)) { tz = TZ.cen; }

  // EASTERN
  else if ([
    // USA Est
    "USA (FL)","USA (GA)","USA (SC)","USA (NC)","USA (VA)","USA (OH)","USA (NY)","USA (PA)","USA (MI)","USA (IN)","USA (KY)","USA (WV)",
    "USA (MD)","USA (DE)","USA (NJ)","USA (CT)","USA (MA)","USA (RI)","USA (VT)","USA (NH)","USA (ME)","USA (DC)",
    
	"Florida", "Georgia", "South Carolina", "North Carolina", "Virginia", "Ohio", "New York",
    "Pennsylvania", "Michigan", "Indiana", "Kentucky", "West Virginia", "Maryland", "Delaware",
    "New Jersey", "Connecticut", "Massachusetts", "Rhode Island", "Vermont", "New Hampshire", "Maine",
	// Canada Est
    "Canada (ON)","Canada (QC)",
	
	// --- Caraïbes (UTC−5 = Eastern “réel”) ---
	"Bahamas (Grand Bahama)",   // Freeport
	"Bahamas (Abaco)",          // Treasure Cay
	"Bahamas (New Providence)", // Nassau
	"Cuba (Havana)",
	"Cuba (Guantanamo)", "Cuba (Guantánamo)", "Cuba (Guantanamo Bay)",
	"Jamaica (Kingston)",
	"Jamaica (Saint James)",    // Montego Bay

	// --- Caraïbes (UTC−4 = Atlantique) → fallback EST ---
	"Puerto Rico (San Juan)",
	"Puerto Rico (Ponce)",
	"Puerto Rico (Mayagüez)", "Puerto Rico (Mayaguez)",
	"Venezuela (Falcón)", "Venezuela (Falcon)", // Adícora, Coro, Punto Fijo (État de Falcón)
	"Aruba (Oranjestad)"
  ].includes(state)) { tz = TZ.est; }

  // ALASKA — si tu as un TZ.ak, sinon on rabat sur PAC pour rester compatible
  else if (["USA (AK)"].includes(state)) { tz = (TZ.ak || TZ.pac); }

	// Sauvegarde l’offset (absolu UTC) pour la timeline
	window.timeZoneOffset = tz.off; // Offset absolu vs UTC
	window.timeZoneAbbr = tz.abbr;
	setPickedTZ(tz);
	try {
	  localStorage.setItem('atselog.tz', JSON.stringify({
		offFinal: window.timeZoneOffset,
		abbr:     window.timeZoneAbbr
	  }));
	} catch {}
	console.log('[TZ pick]', city?.realName, '→', tz.abbr, tz.off, 'state=', (city?.country||''));
}


// ----- Ville + fuseau -----
const elVille = document.getElementById("villeActuelle");
const elEtat  = document.getElementById("etatActuel");

if (!window.citiesReady) {
    showInlineSpinner(elEtat);
	showInlineSpinner(elVille);
} else {
  // Réutilise la variable `city` déjà calculée plus haut dans updateUI
  if (elVille) elVille.textContent = city?.realName || "—";
  if (elEtat)  elEtat.textContent  = city?.country  || "";

  // Envoi au plugin une seule fois quand la ville change
  if (city && city.realName && city.country &&
      (city.realName !== lastCitySent || city.country !== lastStateSent)) {
    fetch('/api/set_location', {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ city: city.realName, state: city.country })
    }).catch(() => {});
    lastCitySent = city.realName;
    lastStateSent = city.country;
  }
}

// -------------------------------- Info Truck Trailer --------------------------------
const chaineTypeRaw = (data.trailer_ChainType || "").toLowerCase();
// on normalise pour matcher "road train", "train routier", "bi-train", etc.
const chaineType = chaineTypeRaw.replace(/[\s\-_]/g, "");

// 👉 Viser le CONTENEUR .form-field (ou #tf2/#tf3) pour tout cacher/afficher (label + input)
const group2 =
  document.getElementById("input_trailer_immat_2")?.closest(".form-field") ||
  document.getElementById("tf2") ||
  document.getElementById("input_trailer_immat_2")?.parentElement;

const group3 =
  document.getElementById("input_trailer_immat_3")?.closest(".form-field") ||
  document.getElementById("tf3") ||
  document.getElementById("input_trailer_immat_3")?.parentElement;

// Par défaut, on cache Trailer 2 et 3
if (group2) group2.style.display = "none";
if (group3) group3.style.display = "none";

// Double / bi-train  → afficher Trailer 2
if (/double|bitrain/.test(chaineType)) {
  if (group2) group2.style.display = "";
}

// Triple / road train / train routier → afficher Trailer 2 et Trailer 3
if (/triple|roadtrain|trainroutier/.test(chaineType)) {
  if (group2) group2.style.display = "";
  if (group3) group3.style.display = "";
}

// --- Masquer ou afficher le bouton "Enregistrer plaques secondaires" ---
const saveBtn = document.getElementById("saveTrailerPlatesBtn"); // adapte l'id exact
if (saveBtn) {
  // Par défaut, cacher le bouton
  saveBtn.style.display = "none";

  // Afficher uniquement si au moins 2 remorques (double, bi-train, triple, roadtrain, etc.)
  if (/double|bitrain|triple|roadtrain|trainroutier/.test(chaineType)) {
    saveBtn.style.display = "";
  }
  if (/triple|roadtrain|trainroutier/.test(chaineType)) {
  if (group2) group2.style.display = "";
  if (group3) group3.style.display = "";
  }
}



// (le reste de ton remplissage d’infos…)
const eltrailer_name = document.getElementById('trailer_name');
if (eltrailer_name) eltrailer_name.textContent = data.trailer_name || 'N/A';

const eltrailer_immat = document.getElementById('trailer_immat');
if (eltrailer_immat) eltrailer_immat.textContent = data.trailer_immat || 'N/A';

const eltrailer_immat_country = document.getElementById('trailer_immat_country');
if (eltrailer_immat_country) eltrailer_immat_country.textContent = data.trailer_immat_country || 'N/A';

// Placeholders facultatifs
const eltrailer_immat_2 = document.getElementById("input_trailer_immat_2");
if (eltrailer_immat_2) eltrailer_immat_2.placeholder = data.trailer_immat_2 || "";
const eltrailer_immat_3 = document.getElementById("input_trailer_immat_3");
if (eltrailer_immat_3) eltrailer_immat_3.placeholder = data.trailer_immat_3 || "";

	
//-----------------------------------------------------------------------------------


// --- PRIMARY (toujours stocker la valeur reçue, mais n'afficher que si pas en overrun)
{
	const el = document.getElementById('primary-timer');
	if (el) {
	  const incoming = data.drive_rem || '--:--';
	  el.dataset.rawTimer = incoming;
	  if (el.dataset.isOverrun !== '1') {
		el.textContent = incoming;
		// NE PAS toucher aux classes ici : applyClasses() gère l'habillage
	  }
	}
}

// --- DRIVE
{
  const el = document.getElementById('driveTimer');
  if (el) {
    const incoming = data.drive_rem || '--:--';
    el.dataset.rawTimer = incoming;
    if (el.dataset.isOverrun !== '1') el.textContent = incoming;
  }
}

// --- WORKDAY
{
  const el = document.getElementById('workdayTimer');
  if (el) {
    const incoming = (data.workday_rem || data.rest_rem || '--:--').trim();
    el.dataset.rawTimer = incoming;
    if (el.dataset.isOverrun !== '1') el.textContent = incoming;
  }
}


// --- Normaliser le temps jeu (sert aux ticks overrun)
window._lastGameMin = ((data.game_time|0) % 1440 + 1440) % 1440;
window.lastGameData = data; // accessible par le tick overrun

// === OVERRUN v2: somme Drive+Work et persistance
HOS_OVERRUN_V2.update(data);

// -- Stabiliser le primary pendant un overrun (verrou rouge fixe) --
{
  const elP = document.getElementById('primary-timer');
  if (elP && elP.dataset.isOverrun === '1') {
    elP.classList.add('timer-violation');
    elP.classList.remove('timer-warning','hos-pulse'); // aucune animation ni retour au bleu
  }
}


// === TRIGGER OVERRUN — entrée unique quand on passe ≤ 00:00 =================
(function () {
  const elP = document.getElementById('primary-timer');
  if (!elP || elP.dataset.isOverrun === '1') return; // si déjà en overrun, ne rien faire

  // Statut courant (numérique + texte pour robustesse)
  const stNum = data.status; // 0=OFF,1=SB,2=D,3=ON
  const stTxt = (data.status_name || '').toUpperCase();
  const isDriving = (stNum === 2) || (stTxt === 'D' || stTxt === 'DRIVING');
  const isOn      = (stNum === 3) || (stTxt === 'ON');

  // Parse "HH:MM" -> secondes (gère signe éventuel)
  const toSec = (s) => {
    s = String(s || '').trim();
    const neg = /^[-−]/.test(s);
    const m = s.replace(/^[-−]/,'').match(/^(\d{1,2}):(\d{2})$/);
    if (!m) return NaN;
    const sec = (+m[1])*3600 + (+m[2])*60;
    return neg ? -sec : sec;
  };

  const driveSec = toSec(data.drive_rem);
  const workSec  = toSec(data.workday_rem || data.rest_rem);

  // Déclenchement: en D on surveille "conduite restante", en ON "service restant"
  if ((isDriving && Number.isFinite(driveSec) && driveSec <= 0) ||
      (isOn      && Number.isFinite(workSec)  && workSec  <= 0)) {
    window.hosEnterOverrunIfNeeded(elP.textContent || '');
  }
})();


const elRest = document.getElementById('restTimer');
if (elRest) elRest.textContent = formatHMM(parseHHMMtoSec(data.rest_timer || "0:00"));

const elCycle = document.getElementById('cycleTimer');
if (elCycle) {
  const raw = (data.cycle_rem || "--:--").trim();
  const m = (function parseHMFlexible(s){
    const str = String(s).trim();
    const neg = /^[-−]/.test(str);
    const [H,M] = str.replace(/^[-−]/,'').split(':').map(x => parseInt(x || '0', 10));
    if (Number.isNaN(H) || Number.isNaN(M)) return NaN;
    return (neg ? -1 : 1) * (H*60 + M);
  })(raw);
  if (Number.isFinite(m)) {
    const sign = m < 0 ? "-" : "";
    const a = Math.abs(m);
    const H = String(Math.floor(a/60)).padStart(2,'0');
    const M = String(a % 60).padStart(2,'0');
    elCycle.textContent = `${sign}${H}:${M}`;
  } else {
    elCycle.textContent = raw;
  }
}

const elelog_day = document.getElementById('elog-day');
	if (elelog_day) elelog_day.textContent   = data.dayName   || 'Jour';

const elelog_week = document.getElementById('elog-week')
	if (elelog_week) elelog_week.textContent  = data.weekNum||'--';
  
const eltruck_model = document.getElementById('truck_model')
	if (eltruck_model) eltruck_model.textContent  = data.truck_model||'--';  

const eltruck_marque = document.getElementById('truckMake')
	if (eltruck_marque) eltruck_marque.textContent  = data.truck_marque||'--';  
	
const eltruck_immat = document.getElementById('truckPlate')
	if (eltruck_immat) eltruck_immat.textContent  = data.truck_immat||'--';  
	
 const eltruck_immat_country = document.getElementById('truckPlateCountry')
	if (eltruck_immat_country) eltruck_immat_country.textContent  = data.truck_immat_country||'--';  
	
 const eltrailer_ChainType = document.getElementById('trailer_ChainType')
	if (eltrailer_ChainType) eltrailer_ChainType.textContent  = data.trailer_ChainType||'--'; 

 const eltrailer_body_type = document.getElementById('trailer_body_type')
	if (eltrailer_body_type) eltrailer_body_type.textContent  = data.trailer_body_type||'--'; 	
	
 const elGpsX = document.getElementById('gps_x');
	if (elGpsX) elGpsX.textContent = (data.pos_x ?? '--');

const elGpsZ = document.getElementById('gps_z');
	if (elGpsZ) elGpsZ.textContent = (data.pos_y ?? '--'); // ton Z = pos_y
	

	
//Timer central Timeline
const elelog_timer = document.getElementById('elog-timer')
	if (elelog_timer) elelog_timer.textContent = formatHMM((data.current_state_time||0));
	
//Heure Total Timeline
// Met à jour les totaux (OFF, SB, D, ON) colonne droite
function safeSetText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;	
}

if (data.total_OFF !== undefined) safeSetText('total-OFF', formatMinutesToHM(data.total_OFF));
if (data.total_SB  !== undefined) safeSetText('total-SB',  formatMinutesToHM(data.total_SB));
if (data.total_D   !== undefined) safeSetText('total-D',   formatMinutesToHM(data.total_D));
if (data.total_ON  !== undefined) safeSetText('total-ON',  formatMinutesToHM(data.total_ON));




  // 1) Mise à jour de l’état & désactivation des boutons
['OFF','SB','D','ON'].forEach((s,i) => {
  const b = document.getElementById('btn-'+s);
  if (!b) return;
  // active selon le statut
  b.classList.toggle('active', data.status === i);
  // en mode arcade, tous désactivés ; sinon seul D reste grisé
  b.disabled = isArcade || (s === 'D');

  // 2) On bind l’override manuel **uniquement** si non-arcade et bouton cliquable
  if (!isArcade && s !== 'D') {
    b.onclick = () => {
      fetch(`/api/eld/override?mode=manuel&status=${s}`);
      console.log(`[HOS] Override manuel : ${s}`);
    };
  } else {
    // en mode arcade ou D, on supprime tout handler
    b.onclick = null;
  }
});

  const versionTags = document.querySelectorAll('[data-version]');
  versionTags.forEach(tag => tag.textContent = data.version || "v1.1.15");
  
    // Affichage heure jeu/fuseau
  updateDisplayedTime(data);

// Actualiser la timeline à chaque update + TimeZone

// 1. Calcul du "début de journée" (minute 0)
const useTz = localStorage.getItem('ats_timezone') === "1";
const offsetMin = useTz ? (window.timeZoneOffset || 0) * 60 : 0; // minutes

// Heure courante (en minute) selon le mode
let minuteCourante = ((data.game_time || 0) + offsetMin) % 1440;
if (minuteCourante < 0) minuteCourante += 1440;


if (!window.timelineReady) {
  buildHourRow();
  window.timelineReady = true;
}






// ▸ 2) Redessiner la grille + segments à chaque update
// --- FIX live progression ---
// --- Live progression, même quand on n’a que "start"/"end" (sans *_min) ---
const hist = Array.isArray(data.status_history) ? data.status_history.map(s => ({...s})) : [];
if (hist.length) {
  const useLocalTz = localStorage.getItem('ats_timezone') === '1';
  const offMin = useLocalTz ? (window.timeZoneOffset || 0) * 60 : 0;

  const last = hist[hist.length - 1];

  // "Maintenant" (0..1439) dans le même référentiel que l’affichage
let nowMin = ((data.game_time || 0) + (useLocalTz ? offMin : 0)) % 1440;
if (nowMin < 0) nowMin += 1440;


  // Statut courant (nom), pour comparer proprement
  const curStatusName = data.status_name || ['OFF','SB','D','ON'][data.status|0] || String(last.status);

  if ('start_time_min' in last || 'start_min' in last) {
    // Cas 1 : l’API fournit les minutes numériques
    const startKey = ('start_time_min' in last) ? 'start_time_min' : 'start_min';
    const endKey   = ('end_time_min'   in last) ? 'end_time_min'   : 'end_min';

    if (last[endKey] <= last[startKey] || String(last.status) === curStatusName) {
      const newEnd = Math.max(Number(last[startKey])||0, Math.min(1440, nowMin));
      last[endKey] = newEnd;
    }
  } else {
    // Cas 2 : on n’a que des chaînes "HH:MM" -> on étend aussi la chaîne "end"
    const parse = (s) => {
      const [H,M] = String(s||'00:00').split(':').map(Number);
      return ((H*60 + M) % 1440 + 1440) % 1440;

    };
    const startMin = parse(last.start);
    const endMin   = parse(last.end);

    if (endMin <= startMin || String(last.status) === curStatusName) {
      const hh2 = String(Math.floor(nowMin/60)).padStart(2,'0');
      const mm2 = String(nowMin%60).padStart(2,'0');
      last.end = `${hh2}:${mm2}`; // -> le renderer recalcule correctement
    }
  }
}

// (re)dessine
renderTimelineGridAndSegments(hist);





// Reset des plaques secondaires et du flag popup si dételage (bobtail)
if (!data.trailer_connected || !data.trailer_ChainType || data.trailer_ChainType.trim() === "") {
  localStorage.removeItem("trailer_immat_2");
  localStorage.removeItem("trailer_immat_3");
  sessionStorage.removeItem("alertPlaquesD");
}
function toTruckyCityFormat(str) {
  return str
    .toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "") // retire les accents
    .replace(/[\s\-]+/g, "_"); // espaces et tirets → underscore
}
if (city && city.realName && city.country &&
    (city.realName !== lastCitySent || city.country !== lastStateSent)) {
  fetch('/api/set_location', {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ city: city.realName, state: city.country })
  }).catch(() => {});
  lastCitySent = city.realName;
  lastStateSent = city.country;
}
if (
  city && city.realName && city.country &&
  (city.realName !== lastCitySent || city.country !== lastStateSent)
) {
  fetch('/api/set_location', {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ city: city.realName, state: city.country })
  }).catch(() => {});

  lastCitySent = city.realName;
  lastStateSent = city.country;
}
const DAYS = {
  fr: ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"],
  en: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
  es: ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"],
  de: ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"]
};
const lang = LANG || "fr";
let dayLabel = "--";
if (typeof data.dayIndex !== "undefined") {
  dayLabel = DAYS[lang][data.dayIndex];
} else if (data.dayName) {
  const idx = DAYS["fr"].indexOf(data.dayName);
  if (idx !== -1) dayLabel = DAYS[lang][idx];
}
const elDay = document.getElementById("elog-day");
if (elDay) elDay.textContent = dayLabel;

// Semaine (formatée)
const weekLabel = translations[lang].elog_week + " " + (data.weekNum || "--");
const elWeek = document.getElementById("elog-week");
if (elWeek) elWeek.textContent = weekLabel;

// console.log("Statut reçu :", data.status, "| ChainType :", data.trailer_ChainType);

checkTrailerPlatesOnD(data);
autoReturnToIndex(data);
/*
// ▸ 3) Remettre les totaux à zéro lorsqu’on passe 00 h (optionnel)
if (minuteCourante < 2) {
  ["OFF","SB","D","ON"].forEach(s => {
    document.getElementById("total-"+s).textContent = "00h00";
  });
}*/
if (localStorage.getItem('ats_timezone') === '1') {
  if (window.timeZoneOffset !== window.lastSentOffset) {
    syncTimezoneWithPlugin(true, window.timeZoneOffset);
    window.lastSentOffset = window.timeZoneOffset;

  }
}

if (langSel) {
  langSel.value = currentLang;
  langSel.addEventListener('change', (e) => {
    currentLang = e.target.value || 'fr';
    localStorage.setItem('lang', currentLang);

    // Retraduire toute la page
    applyI18n(document);

    // Si la modale de mise à jour est ouverte, retraduis-la aussi
    const modal = document.getElementById('update-modal');
    if (modal && modal.classList.contains('show')) applyI18n(modal);
  });
}

  

}
function getGameMinuteWithTZ(data) {
    // g_gameTimeMin = minutes depuis le point zéro du jeu (UTC base)
    let min = data.game_time || 0;
    // Si fuseau horaire activé, appliquer l’offset
    if (data.tz_active) { // ou vérifie si la case est cochée
        min += (data.usetz_offset || 0) * 60;
    }
    // Toujours ramener dans la journée 0..1439
    return ((min % 1440) + 1440) % 1440;
}




// Génère la bande des heures toutes les 3h (00h, 03h, ..., 21h, 00h)
function buildHourRow() {
  const hoursDiv = document.getElementById('elog-hours');
  if (!hoursDiv) return;
  hoursDiv.innerHTML = '';
  for(let h=0; h<=24; h+=3){
    let span = document.createElement('span');
    span.textContent = String(h%24).padStart(2,"0")+'h';
    hoursDiv.appendChild(span);
  }
}

// -------------------------------------------------Page Vehicules ----------------------------------------------
function saveTrailerPlates() {
  const v2 = document.getElementById("input_trailer_immat_2")?.value.trim();
  const v3 = document.getElementById("input_trailer_immat_3")?.value.trim();
  const body = {};
  if (v2) body.trailer_immat_2 = v2;
  if (v3) body.trailer_immat_3 = v3;
  fetch('/save-plaques', {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  })
    .then(r => r.json())
    .then(data => {
      if (data.ok) showToast("Plaques enregistrées !");
      else showToast("Erreur d’enregistrement", 2000);
    })
    .catch(() => showToast("Erreur d’enregistrement", 2000));
  setTimeout(() => {
    window.location.href = "index.html";
  }, 1000);
}


// --------------------------------------------------------------------------------------------------
function renderTimelineGridAndSegments(statusHistory) {
  const svg = document.getElementById('elog-svg');
  if (!svg) return;

  const WIDTH = 1440, HEIGHT = 100;
  const ROW_HEIGHT = HEIGHT / 4;

  // 1. Grille horaire (lignes verticales)
  svg.innerHTML = '';
  for (let h = 0; h <= 24; h++) {
    let x = (h / 24) * WIDTH;
    let isMajor = (h % 3 === 0);
    svg.innerHTML += `<line x1="${x}" y1="0" x2="${x}" y2="${HEIGHT}" stroke="#AAA" stroke-width="${isMajor ? 5 : 2}" ${isMajor ? 'opacity="0.7"' : 'opacity="0.4"'} />`;
  }
  // 2. Séparateurs horizontaux
  for (let i = 1; i < 4; ++i) {
    let y = i * ROW_HEIGHT;
    svg.innerHTML += `<line x1="0" y1="${y}" x2="${WIDTH}" y2="${y}" stroke="#BBB" stroke-width="1"/>`;
  }
  // 3. Segments de statut
if (Array.isArray(statusHistory)) {
  const useTz = localStorage.getItem('ats_timezone') === "1";
  const offsetMin = useTz ? (window.timeZoneOffset || 0) * 60 : 0; // minutes

  statusHistory.forEach(seg => {
    let startMin, endMin, row;

    if (Array.isArray(seg)) {
      // [startMin, endMin, row] déjà en minutes (UTC base) -> appliquer offset si local
      [startMin, endMin, row] = seg;
      if (useTz) { startMin += offsetMin; endMin += offsetMin; }

    } else if (typeof seg === "object") {
      // Cas 1: l’API fournit des minutes numériques -> appliquer offset ici
      if ('start_time_min' in seg || 'start_min' in seg) {
        const sKey = ('start_time_min' in seg) ? 'start_time_min' : 'start_min';
        const eKey = ('end_time_min'   in seg) ? 'end_time_min'   : 'end_min';
        startMin = Number(seg[sKey]) || 0;
        endMin   = Number(seg[eKey]) || 0;
        if (useTz) { startMin += offsetMin; endMin += offsetMin; }

      // Cas 2: on n’a que des chaînes "HH:MM" -> déjà en heure locale si plugin => pas d’offset
      } else {
        const parse = (s) => {
          const [H, M] = String(s || "00:00").split(":").map(Number);
          return ((H * 60 + M) % 1440 + 1440) % 1440;
        };
        startMin = parse(seg.start);
        endMin   = parse(seg.end);
      }

      row = { OFF:0, SB:1, D:2, ON:3 }[seg.status];
    } else {
      return; // type inattendu
    }

    startMin = ((startMin % 1440) + 1440) % 1440;
    endMin   = ((endMin   % 1440) + 1440) % 1440;
    if (typeof row !== "number") return;

    const y = row * (100/4) + 2;             // même hauteur que ton code
    const height = (100/4) - 4;
    const draw = (a, b) => {
      const x1 = (a / 1440) * 1440;
      const x2 = (b / 1440) * 1440;
      document.getElementById('elog-svg').innerHTML +=
        `<rect x="${x1}" y="${y}" width="${x2 - x1}" height="${height}" fill="#AECBA6" rx="2" ry="2" />`;
    };

    // Si le segment passe minuit, on coupe proprement
    if (endMin <= startMin) {
      draw(0, endMin);
    } else {
      draw(startMin, endMin);
    }
  });
}
}


//---------------------------------------------en dessous a verif ???????--------------------↓↓↓

// Timeline format HH:mm
// Prend un nombre de minutes du jeu (ex: 286948) et retourne hh:mm du jour en jeu
function displayTimelineHour(hhmm, useTimeZone, offset) {
    const min = parseHHMMtoMinutes(hhmm);
    let finalMin = min;
    if (useTimeZone) finalMin = (min + offset + 1440) % 1440;
    const h = String(Math.floor(finalMin / 60) % 24).padStart(2, "0");
    const m = String(finalMin % 60).padStart(2, "0");
    return `${h}:${m}`;
}
//------------------------------------------------------------------------------------------↑↑↑
function parseHHMMtoMinutes(str) {
    if (!str || !str.includes(":")) return 0;
    const [h, m] = str.split(":").map(Number);
    if (isNaN(h) || isNaN(m)) return 0;
    return h * 60 + m;
}
function parseHHMM(str) {
    if (!str || typeof str !== "string") return 0;
    const [h, m] = str.split(":").map(Number);
    return h * 60 + m;
}

function initELDOverride() {
  // Ne rien faire si le bouton principal n’est pas là (donc page settings)
  if (!document.getElementById('btn-OFF')) return;
  const statuses = ['OFF', 'SB', 'D', 'ON'];
  statuses.forEach(s => {
    const btn = document.getElementById(`btn-${s}`);
    if (!btn) return;
    const newBtn = btn.cloneNode(true);
    btn.parentNode.replaceChild(newBtn, btn);
  });
}

function showToast(msg, duration = 1000) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = msg;
  toast.style.display = 'block';
  clearTimeout(showToast._timeout);
  showToast._timeout = setTimeout(() => {
    toast.style.display = 'none';
  }, duration);
}
async function update() {
  try {
    const res = await fetch(`${endpoint}?t=${Date.now()}`);
    if (!res.ok) throw new Error("fetch failed");
    const data = await res.json();
    if (!data.clock) throw new Error("données invalides");

    const conn = document.getElementById('conn-icon');
    if (conn) {
      conn.src = 'textures/icon-conv.png';
      conn.alt = 'Plugin actif';
      conn.className = 'connected';
    }

    updateUI(data);
    localStorage.setItem("lastValidData", JSON.stringify(data));
  } catch (e) {
    console.error("[update()] erreur de connexion :", e);
    const conn = document.getElementById('conn-icon');
    if (conn) {
      conn.src = 'textures/icon-conr.png';
      conn.alt = 'Plugin inactif ou ATS fermé';
      conn.className = 'disconnected';
    }

    const cached = localStorage.getItem("lastValidData");
    if (cached) {
      try {
        const data = JSON.parse(cached);
        updateUI(data);
      } catch (parseError) {
        console.warn("⚠️ JSON localStorage corrompu", parseError);
        localStorage.removeItem("lastValidData");
      }
    }
  } finally {
    setTimeout(update, refreshMs);
  }
}



window.addEventListener("DOMContentLoaded", () => {
  applyTranslations();

  const langSel = document.getElementById("lang");
  if (langSel) {
    langSel.value = LANG;
    langSel.addEventListener("change", () => {
      localStorage.setItem("lang", langSel.value);
      location.reload();
    });
  }

// au chargement des réglages
const convoyEl = document.getElementById('convoyMode');
if (convoyEl) convoyEl.checked = localStorage.getItem('convoy_mode') === '1';

const nameInput = document.getElementById('editChauffeur');
if (nameInput) {
  nameInput.value = localStorage.getItem('nomChauffeur') || '';
}
// Afficher le nom dans le header (index & settings)
const nameDisplay = document.getElementById('affichageChauffeur');
const raw = localStorage.getItem('nomChauffeur') || '';
const nom = normalizeNomChauffeur(raw);
localStorage.setItem('nomChauffeur', nom);

if (nameInput)   nameInput.value = nom;
if (nameDisplay) nameDisplay.textContent = nom;
if (nameDisplay) {
  nameDisplay.textContent = localStorage.getItem('nomChauffeur') || '';
}
  const saveBtn = document.getElementById("saveBtn");
if (saveBtn) {
  saveBtn.addEventListener("click", () => {
    if (langSel) localStorage.setItem("lang", langSel.value);
	if (nameInput) {
      const nom = normalizeNomChauffeur(nameInput.value.trim()); 
      localStorage.setItem('nomChauffeur', nom);
	  const nameDisplay = document.getElementById('affichageChauffeur');
    if (nameDisplay) nameDisplay.textContent = nom;
    }
    showToast(translations[LANG]?.saved || "Sauvegardé !");
    setTimeout(() => {
      window.location.href = "index.html";
    }, 1000);
	// dans le handler de saveBtn (tu l’as déjà)
if (convoyEl) localStorage.setItem('convoy_mode', convoyEl.checked ? '1' : '0');
  });
}
	
// ... à l'intérieur de ton window.addEventListener("DOMContentLoaded", () => { ... });

// --- URL du DERNIER déploiement webapp ---
/*
const GAS_URL = 'https://script.google.com/macros/s/AKfycbxraUXnnhHVusEgeT6DnX3gI5v21WHh643y74GAyf8WJxx3Ejt__n9UMiSvbQx_D7TM/exec';

window.GAS_URL = GAS_URL; // pratique dans la console
*/

console.log('GAS_URL utilisé =>', window.GAS_URL);

// ----- Envoi du formulaire -----
const devForm = document.getElementById('devForm');
if (devForm) {
  devForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Champs saisis
    const ville = document.getElementById('ville').value.trim();
    const etat  = document.getElementById('etat').value.trim();
    const pays  = document.getElementById('pays').value.trim();

    // Valeurs affichées (spans)
    const gpsXEl = document.getElementById('gps_x');
    const gpsZEl = document.getElementById('gps_z');

    // Fallback télémétrie
    const pos_x = gpsXEl && gpsXEl.textContent !== '--'
      ? gpsXEl.textContent.trim()
      : (window.lastGameData?.pos_x ?? '');
    const pos_z = gpsZEl && gpsZEl.textContent !== '--'
      ? gpsZEl.textContent.trim()
      : (window.lastGameData?.pos_y ?? '');

    // Hidden (vérif propre)
    const hx = document.getElementById('pos_x_field');
    const hz = document.getElementById('pos_z_field');
    if (hx) hx.value = pos_x;
    if (hz) hz.value = pos_z;

    const chauffeur = (localStorage.getItem('nomChauffeur') || '')
      .replace(/^🪪\s*/, '')
      .trim();

    try {
      // FormData pour éviter le préflight
      const fd = new FormData();
      fd.append('ville',  ville);
      fd.append('etat',   etat);
      fd.append('pays',   pays);
      fd.append('pos_x',  pos_x);
      fd.append('pos_z',  pos_z);
      fd.append('chauffeur', chauffeur);

      const btn = document.getElementById('boutondev');
      const msg = document.getElementById('formResult');
      if (btn) btn.disabled = true;
      if (msg) msg.textContent = 'Envoi...';

      await fetch(GAS_URL, { method: 'POST', body: fd, mode: 'no-cors' });

      if (msg) msg.textContent = 'Envoi effectué ✔';
      setTimeout(() => { window.location.href = 'index.html'; }, 1000);
    } catch (err) {
      console.error(err);
      const msg = document.getElementById('formResult');
      if (msg) msg.textContent = "Échec d'envoi (réseau).";
      const btn = document.getElementById('boutondev');
      if (btn) btn.disabled = false;
    }
  });
}

// ----- Lecture depuis le Sheet via JSONP (pas de CORS) ----- //
/*
function jsonp(urlWithParams) {
  return new Promise((resolve, reject) => {
    const cb = 'gascb_' + Math.random().toString(36).slice(2);
    const s = document.createElement('script');
    window[cb] = (payload) => { delete window[cb]; s.remove(); resolve(payload); };
    s.onerror = () => { delete window[cb]; s.remove(); reject(new Error('JSONP échoué')); };
    // on force list=1 + callback
    s.src = `${GAS_URL}?list=1&callback=${cb}`;
    document.body.appendChild(s);
  });
}

async function fetchSheetCities() {
  const payload = await jsonp(`${GAS_URL}?list=1`);
  // payload attendu : { ok:true, rows:[...] }
  return Array.isArray(payload?.rows) ? payload.rows : [];
}
*/

// ----- Fusion avec priorité aux données du Sheet -----
function mergeCities(...lists) {
  const map = new Map();
  for (const list of lists) {
    for (const c of list) {
      const key = [
        (c.realName || '').toLowerCase().trim(),
        (c.country  || '').toLowerCase().trim(),
        Math.round(Number(c.x) || 0),
        Math.round(Number(c.z) || 0)
      ].join('|');
      // priorité au dernier => on écrase systématiquement
      map.set(key, c);
    }
  }
  return [...map.values()];
}

// ----- Au démarrage : on charge et on fusionne -----
(async () => {
  try {
    const sheetCities = await fetchSheetCities();     // vient du Google Sheet
    const baseLocal   = (window.cities || []);        // cities-ats.js
    const baseTrucky  = (window.truckyCities || []);  // si tu as déjà un tableau Trucky

    // ordre = local, trucky, sheet ; comme on écrase, le Sheet l’emporte
    const merged = mergeCities(sheetCities, baseLocal, baseTrucky, );

    // remplace la source utilisée par l’UI
    window.cities = merged;
	window.citiesATS = merged;
	if (window.lastGameData) updateUI(window.lastGameData);


    // debug rapide pour vérifier que ça lit bien le Sheet :
    console.log('Villes du Sheet chargées :', sheetCities.length, sheetCities[0]);
    console.log('Total fusionné =', merged.length);

    // si tu as une fonction qui redessine l’UI (liste/recherche/mini-carte)
    if (typeof refreshCityUI === 'function') refreshCityUI(merged);
  } catch (err) {
    console.error('Lecture Sheet échouée :', err);
  }
  
})();

	

  const tz = document.getElementById('atsTimezone');
  if (tz) {
    tz.checked = localStorage.getItem('ats_timezone') === '1';
    tz.addEventListener('change', () => {
      localStorage.setItem('ats_timezone', tz.checked ? '1' : '0');
      // Rafraîchir direct l'affichage
      updateDisplayedTime(window.lastGameData || {});
    });
  }

  function fetchVersionAndInject() {
    fetch(`${endpoint}?t=${Date.now()}`)
      .then(r => r.json())
      .then(d => {
        document.querySelectorAll('.ui-version')
          .forEach(el => {
            el.textContent = d.version ? ` v${d.version}` : '';
          });
      })
      .catch(console.error);
  }

	const eltrailer_immat_2 = document.getElementById("input_trailer_immat_2")
	if (eltrailer_immat_2) eltrailer_immat_2.value = localStorage.getItem("trailer_immat_2") || "";

	const eltrailer_immat_3 = document.getElementById("input_trailer_immat_3")
	if (eltrailer_immat_3) eltrailer_immat_3.value = localStorage.getItem("trailer_immat_3") || "";
	
	fetchVersionAndInject();
	initELDOverride();
	initCitiesPriority().finally(() => {
	update();
	});
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js');
  
  update();



  // 2) charge les villes en arrière-plan (priorité Sheet > Trucky > Local)
  initCitiesPriority().then(() => {
    // quand dispo, on rafraîchit UNIQUEMENT l’affichage dépendant des villes
    if (window.lastGameData) updateUI(window.lastGameData);
	});
	  // --- Vérifier s'il existe une nouvelle version sur le Sheet ---
checkVersionAgainstSheet();
});



// -- Constantes
const EMOJI_ID = "🪪";
const EMOJI_PREFIX = EMOJI_ID + " ";

// Normalise le nom: supprime tous les "🪪 " au début puis remet un seul
function normalizeNomChauffeur(raw) {
  if (!raw) return EMOJI_PREFIX;              // au pire, juste l’émoji + espace
  let s = String(raw).trim();

  // Retire tous les émojis "🪪" et espaces superflus en tête
  s = s.replace(/^(\uD83E\uDDDAs?|\ud83e\udddA)?\s*/i, ""); // robustesse
  s = s.replace(/^🪪\s*/g, "");
  // Si l’utilisateur a déjà mis l’émoji plus loin, on ne le garde pas
  s = s.replace(/🪪/g, "").trim();

  return EMOJI_PREFIX + s;
}

// Applique le préfixe et garde le curseur juste après l’émoji
function enforceEmojiPrefixOnInput(input) {
  const start = input.selectionStart;
  const hadPrefix = input.value.startsWith(EMOJI_PREFIX);
  if (!hadPrefix) {
    input.value = normalizeNomChauffeur(input.value);
  } else {
    // Empêche de casser le préfixe (si on le supprime au clavier)
    if (!input.value.startsWith(EMOJI_PREFIX)) {
      input.value = normalizeNomChauffeur(input.value);
    }
  }
  // Place le caret minimum après le préfixe
  const minPos = EMOJI_PREFIX.length;
  const newPos = Math.max(start, minPos);
  requestAnimationFrame(() => {
    input.setSelectionRange(newPos, newPos);
  });
}

// ----- Application PC -----
document.addEventListener("DOMContentLoaded", () => {
	// ----- Initialisation au chargement -----

  const btn = document.getElementById('install-app-btn');


	
  // ===== PWA install (prompt programmable) =====
  let deferredPrompt = null;

  
  const tip = document.getElementById("pwa-install-tip");
  if (!btn || !tip) return;

  // Helper
  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
  const isStandalone = window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone;
  const isSecure = window.isSecureContext || location.hostname === "localhost";

  // Cas 1: déjà installée
  if (isStandalone) {
    btn.style.display = "none";
    tip.style.display = "none";
    return;
  }

  // Cas 2: iOS → pas de prompt, on montre l’astuce
  if (isIOS) {
    btn.style.display = "none";
    tip.style.display = "";
    return;
  }

  // Cas 3: pas HTTPS / localhost → pas de prompt
  if (!isSecure) {
    btn.style.display = "none";
    tip.style.display = "";
    return;
  }

  // Cas 4: Chrome/Edge/Brave en HTTPS/localhost
  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    deferredPrompt = e;
    btn.style.display = "";
    tip.style.display = "none";
  });

  btn.addEventListener("click", async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      try { await deferredPrompt.userChoice; } catch {}
      deferredPrompt = null;
    } else {
      tip.style.display = "";
    }
  });

  window.addEventListener("appinstalled", () => {
    btn.textContent = "Application installée";
    btn.disabled = true;
    tip.style.display = "none";
  });

  // Enregistrement du service worker
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("sw.js").catch(console.error);
  }

  const input = document.getElementById("inputChauffeur");
  const affichage = document.getElementById("affichageChauffeur");

  // 1) Charger valeur existante (localStorage ou valeur actuelle de l’input)
  let saved = localStorage.getItem("nomChauffeur");
  if (!saved) saved = input.value || "";

  // 2) Normaliser + afficher dans l’input
  const normalized = normalizeNomChauffeur(saved);
  input.value = normalized;

  // 3) Optionnel: maj de l’affichage si présent
  if (affichage) affichage.innerText = normalized;

  // 4) Verrouiller le préfixe à chaque saisie
  input.addEventListener("input", () => enforceEmojiPrefixOnInput(input));

  // 5) Sécuriser aussi Backspace/Delete juste au début
  input.addEventListener("keydown", (e) => {
    const pos = input.selectionStart;
    const sel = input.selectionEnd;
    if (
      // Empêche de supprimer le préfixe
      (e.key === "Backspace" && pos <= EMOJI_PREFIX.length && pos === sel) ||
      (e.key === "Delete" && pos < EMOJI_PREFIX.length)
    ) {
      e.preventDefault();
      // repositionne le curseur juste après le préfixe
      input.setSelectionRange(EMOJI_PREFIX.length, EMOJI_PREFIX.length);
    }
  
  
  setupConvoyResetButtons();
});

// Affiche/masque les boutons selon le réglage et branche les clics
function setupConvoyResetButtons() {
  const isConvoy = localStorage.getItem('convoy_mode') === '1';
  const btnDay   = document.getElementById('resetDayBtn');
  const btnCycle = document.getElementById('resetCycleBtn');
  if (!btnDay || !btnCycle) return;      // pas sur cette page

  btnDay.hidden   = !isConvoy;
  btnCycle.hidden = !isConvoy;

  if (isConvoy) {
    btnDay.onclick = () => {
      if (confirm("Réinitialiser les heures journalières ?")) {
        if (typeof resetDailyHOS === 'function') resetDailyHOS(); // ou ta fonction existante
        showToast("Jour réinitialisé");
        if (window.lastGameData) updateUI(window.lastGameData);
      }
    };
    btnCycle.onclick = () => {
      if (confirm("Réinitialiser les heures du cycle ?")) {
        if (typeof resetCycleHOS === 'function') resetCycleHOS(); // ou ta fonction existante
        showToast("Cycle réinitialisé");
        if (window.lastGameData) updateUI(window.lastGameData);
      }
    };
  } else {
    btnDay.onclick = btnCycle.onclick = null;
  }
}

// Appel automatique sur toutes les pages (ne fait quelque chose que si les boutons existent)
document.addEventListener('DOMContentLoaded', setupConvoyResetButtons);

// --- Réinitialisations (robustes) ---
function resetDailyHOS() {
  // Si ton moteur HOS expose une API dédiée, on l’utilise :
  if (window.hos && typeof hos.resetDay === 'function') {
    hos.resetDay();
  } else {
    // Fallback générique : on repart à "maintenant"
    localStorage.setItem('hos_day_start', Date.now().toString());
    // On efface toutes les données "jour" connues
    for (const k of Object.keys(localStorage)) {
      if (/^hos_day_/i.test(k) || /^hos_today_/i.test(k)) localStorage.removeItem(k);
    }
  }
  refreshHosUI();
}

function resetCycleHOS() {
  if (window.hos && typeof hos.resetCycle === 'function') {
    hos.resetCycle();
  } else {
    localStorage.setItem('hos_cycle_start', Date.now().toString());
    for (const k of Object.keys(localStorage)) {
      if (/^hos_cycle_/i.test(k)) localStorage.removeItem(k);
    }
  }
  refreshHosUI();
}

// Rafraîchit l’affichage HOS proprement
function refreshHosUI() {
  if (typeof refreshHos === 'function') { refreshHos(); return; }
  if (typeof updateUI === 'function' && window.lastGameData) { updateUI(window.lastGameData); return; }
  // dernier recours :
  location.reload();
}
});

// ----- Ta fonction d’enregistrement (mise à jour) -----
function validerChauffeur() {
  const input = document.getElementById('inputChauffeur');
  const affichage = document.getElementById('affichageChauffeur');

  let nom = input.value.trim();
  if (nom.length < 2) {
    showToast("Merci d'entrer un nom valide.");
    return;
  }

  nom = normalizeNomChauffeur(nom);

  // Met à jour l’input + un éventuel affichage
  input.value = nom;
  if (affichage) affichage.innerText = nom;

  // Persistance
  localStorage.setItem('nomChauffeur', nom);

  // Ferme le popup si présent
  const popup = document.getElementById('popupChauffeur');
  if (popup) popup.style.display = 'none';

  // Si tu as déjà une fonction d’UI :
  if (typeof afficherChauffeur === "function") {
    afficherChauffeur();
  }
  // Vérifie si le mode convoi est activé
  const isConvoy = localStorage.getItem('convoy_mode') === '1';
  const resetDayBtn = document.getElementById('resetDayBtn');
  const resetCycleBtn = document.getElementById('resetCycleBtn');

  if (isConvoy) {
    // Affiche les boutons reset
    if (resetDayBtn) resetDayBtn.hidden = false;
    if (resetCycleBtn) resetCycleBtn.hidden = false;

    // Action du bouton "Réinitialiser journée"
    if (resetDayBtn) {
      resetDayBtn.addEventListener('click', () => {
        if (confirm("Réinitialiser les heures de service de la journée ?")) {
          fetch('/api/eld/reset_day')
            .then(r => r.text())
            .then(() => showToast("Heures de service réinitialisées !"))
            .catch(() => showToast("Erreur de réinitialisation"));
        }
      });
    }

    // Action du bouton "Réinitialiser cycle"
    if (resetCycleBtn) {
      resetCycleBtn.addEventListener('click', () => {
        if (confirm("Réinitialiser le cycle de 70 h / 8 jours ?")) {
          fetch('/api/eld/reset_cycle')
            .then(r => r.text())
            .then(() => showToast("Cycle réinitialisé !"))
            .catch(() => showToast("Erreur de réinitialisation"));
        }
      });
    }
  } else {
    // Cache les boutons si mode convoi désactivé
    if (resetDayBtn) resetDayBtn.hidden = true;
    if (resetCycleBtn) resetCycleBtn.hidden = true;
  }
}



// À la toute fin de DOMContentLoaded (pour toutes pages !)
window.addEventListener("DOMContentLoaded", () => {
  // Popup nom chauffeur au premier accès
  const pop = document.getElementById('popupChauffeur');
const aff = document.getElementById('affichageChauffeur');
if (pop && aff) {
  const stored = localStorage.getItem('nomChauffeur') || '';
  const hasRealName = stored.replace(/^🪪\s*/, '').trim().length >= 2;
  if (!hasRealName) {
    pop.style.display = 'flex';
    setTimeout(() => document.getElementById('inputChauffeur').focus(), 150);
  }
}
});

function sauverChauffeur() {
  const nom = document.getElementById('editChauffeur').value.trim();
  if (nom.length < 2) { showToast("Merci d'entrer un nom valide."); return; }
  localStorage.setItem('nomChauffeur', nom);
  // showToast("Nom du conducteur mis à jour !");
}

//IP pour Application


// Outils

function formatMinutesToHM(mins) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (!h && !m) return "00h00";
  return `${String(h).padStart(2, '0')}h${String(m).padStart(2, '0')}`;
}


// === DEBUG : affichage/branchements des boutons reset en Mode Convoi ===
function setupConvoyResetButtonsDebug() {
  const TAG = "[ATS-Elog Convoy]";
 // console.groupCollapsed(`${TAG} init on ${location.pathname}`);

  // 1) Lire l'état stocké
  const convoyVal = localStorage.getItem('convoy_mode');
  const isConvoy = convoyVal === '1';
 // console.log(TAG, "localStorage.convoy_mode =", convoyVal, "→ isConvoy =", isConvoy);

  // 2) Récupérer les éléments
  const resetDayBtn   = document.getElementById('resetDayBtn');
  const resetCycleBtn = document.getElementById('resetCycleBtn');
  const driveTimer    = document.getElementById('driveTimer');
  const cycleTimer    = document.getElementById('cycleTimer');

 /* console.log(TAG, "DOM:",
    { hasResetDayBtn: !!resetDayBtn, hasResetCycleBtn: !!resetCycleBtn, hasDriveTimer: !!driveTimer, hasCycleTimer: !!cycleTimer }
  );
*/

  // Aide visuelle si le HTML n’a pas été corrigé (boutons pas trouvés)
  if (!resetDayBtn || !resetCycleBtn) {
   // console.warn(TAG, "Bouton(s) introuvable(s). Vérifie le HTML (IDs uniques, bouton dans le même <td> que le timer).");
    // On essaie de retrouver une mauvaise 2e occurrence de resetDayBtn (HTML ancien)
    const dups = Array.from(document.querySelectorAll('#resetDayBtn'));
    if (dups.length > 1) {
    //  console.warn(TAG, "⚠️ ID #resetDayBtn en double:", dups);
    }
  }

  // 3) Appliquer visibilité selon le mode
  const applyVisibility = (btn, name) => {
    if (!btn) return;
    if (isConvoy) {
      btn.hidden = false;             // retire l'attribut hidden
      btn.style.display = 'inline-block'; // force l’affichage
      btn.style.visibility = 'visible';
    //  console.log(TAG, `Bouton ${name}: rendu visible`);
    } else {
      btn.hidden = true;
      btn.style.display = '';
      btn.style.visibility = '';
    //  console.log(TAG, `Bouton ${name}: caché (mode convoi OFF)`);
    }
  };

  applyVisibility(resetDayBtn,   "resetDayBtn");
  applyVisibility(resetCycleBtn, "resetCycleBtn");

  // 4) Binder les événements (une seule fois)
  if (!window._convoyResetBound) {
    if (resetDayBtn) {
      resetDayBtn.addEventListener('click', () => {
        console.log(TAG, "Click resetDayBtn → /api/eld/reset_day");
        if (!confirm("Réinitialiser les heures de service de la journée ?")) {
          console.log(TAG, "Action annulée par l’utilisateur.");
          return;
        }
        fetch('/api/eld/reset_day')
          .then(r => r.text())
          .then(txt => {
            console.log(TAG, "Réponse /reset_day:", txt);
            if (typeof showToast === "function") showToast("Heures de service réinitialisées !");
          })
          .catch(err => {
            console.error(TAG, "Erreur /reset_day:", err);
            if (typeof showToast === "function") showToast("Erreur de réinitialisation");
          });
      });
   //   console.log(TAG, "Handler attaché → resetDayBtn");
    }

    if (resetCycleBtn) {
      resetCycleBtn.addEventListener('click', () => {
        console.log(TAG, "Click resetCycleBtn → /api/eld/reset_cycle");
        if (!confirm("Réinitialiser le cycle de 70 h / 8 jours ?")) {
          console.log(TAG, "Action annulée par l’utilisateur.");
          return;
        }
        fetch('/api/eld/reset_cycle')
          .then(r => r.text())
          .then(txt => {
            console.log(TAG, "Réponse /reset_cycle:", txt);
            if (typeof showToast === "function") showToast("Cycle réinitialisé !");
          })
          .catch(err => {
            console.error(TAG, "Erreur /reset_cycle:", err);
            if (typeof showToast === "function") showToast("Erreur de réinitialisation");
          });
      });
   //   console.log(TAG, "Handler attaché → resetCycleBtn");
    }

    window._convoyResetBound = true;
  } else {
 //   console.log(TAG, "Handlers déjà attachés (skip).");
  }

 // console.groupEnd();
}

// 5) Lancer au chargement du DOM
document.addEventListener('DOMContentLoaded', setupConvoyResetButtonsDebug);

// 6) Et relancer une fois après la 1re trame de données jeu (si updateUI existe)
(function hookAfterFirstUpdate(){
  if (typeof updateUI !== "function") return; // rien à faire
  if (window._updateUI_hooked) return;
  window._updateUI_hooked = true;

  const _oldUpdateUI = updateUI;
  window.updateUI = function(data) {
    const r = _oldUpdateUI.call(this, data);
    // ré-applique la visibilité au cas où la page a bougé/état changé entre-temps
    try { setupConvoyResetButtonsDebug(); } catch(e) { console.error("[ATS-Elog Convoy] hook error:", e); }
    return r;
  };
})();

// === About.html : Remplir + CACHER la liste des contributeurs (col. B = "Chauffeur") ===
// === About.html : Contributeurs (col. B = "Chauffeur") avec spinner et cache ===
(function contributorsAutoFillCached() {
  const target = document.getElementById('contributorsList');
  if (!target) return; // pas sur About.html

  const spinEl = document.getElementById('contributorsSpinner');
  const spin = {
    show() { if (spinEl) { spinEl.classList.remove('is-hidden'); spinEl.style.display = 'inline-block'; } },
    hide() { if (spinEl) { spinEl.classList.add('is-hidden');   spinEl.style.display = 'none'; } }
  };

  // Spinner ON dès l'arrivée sur la page
  spin.show();

  // Cache (6h). Change 6 -> 24 si tu veux 24h.
  const CACHE_KEY = 'atselog.contributors.list.v1';
  const CACHE_TS  = 'atselog.contributors.ts.v1';
  const CACHE_TTL_MS = 6 * 60 * 60 * 1000;

  const render = (list) => { target.textContent = list?.length ? list.join(', ') : '—'; };
  const sameList = (a, b) => JSON.stringify(a || []) === JSON.stringify(b || []);

  const loadCache = () => {
    try {
      const ts = parseInt(localStorage.getItem(CACHE_TS) || '0', 10);
      const raw = localStorage.getItem(CACHE_KEY);
      if (!raw) return null;
      const list = JSON.parse(raw);
      if (!Array.isArray(list)) return null;
      const expired = (Date.now() - ts) > CACHE_TTL_MS;
      return { list, expired };
    } catch { return null; }
  };

  const saveCache = (list) => {
    try {
      localStorage.setItem(CACHE_KEY, JSON.stringify(list || []));
      localStorage.setItem(CACHE_TS, String(Date.now()));
    } catch {}
  };

  const buildList = (rows) => {
    const seen = new Map(); // dédoublonnage insensible à la casse
    for (const r of rows || []) {
      let name = (r.Chauffeur ?? r.chauffeur ?? '').toString().trim();
      if (!name) continue;
      name = name.replace(/^🪪\s*/, '').replace(/\s+/g, ' ').trim();
      if (!name) continue;
      const norm = name.toLocaleLowerCase('fr-CA');
      if (!seen.has(norm)) seen.set(norm, name);
    }
    return Array.from(seen.values())
      .sort((a, b) => a.localeCompare(b, 'fr', { sensitivity: 'base' }));
  };

  // 1) Affiche le cache immédiatement si dispo (mais laisse le spinner jusqu'au réseau)
  const cached = loadCache();
  if (cached?.list?.length) render(cached.list);
  else target.textContent = '…';

  // Sécurité : si rien ne répond, on coupe le spinner au bout de 10 s
  let timeoutId = setTimeout(() => spin.hide(), 10000);

  const useRows = (rows) => {
    const list = buildList(rows);
    if (list.length) {
      if (!cached || !sameList(list, cached.list)) {
        render(list);
        saveCache(list);
      } else if (cached?.expired) {
        // Identique mais cache expiré → rafraîchir juste le timestamp
        saveCache(list);
      }
    }
    if (timeoutId) { clearTimeout(timeoutId); timeoutId = null; }
    spin.hide(); // ✅ base de données chargée → couper le spinner
  };

  // 2) Déjà en mémoire ?
  if (Array.isArray(window._sheetRawRows)) { useRows(window._sheetRawRows); return; }

  // 3) Sinon, JSONP réseau
  if (typeof jsonp === 'function' && window.GAS_URL) {
    jsonp(`${window.GAS_URL}?list=1`)
      .then(payload => {
        const rows = Array.isArray(payload?.rows) ? payload.rows : [];
        window._sheetRawRows = rows;
        useRows(rows);
      })
      .catch(() => {
        if (timeoutId) { clearTimeout(timeoutId); timeoutId = null; }
        spin.hide(); // en cas d’erreur, on coupe quand même pour ne pas tourner à vide
      });
  } else {
    if (timeoutId) { clearTimeout(timeoutId); timeoutId = null; }
    spin.hide(); // pas de jsonp dispo
  }
})();




// Hauteur visible fiable (iOS/Android/Desktop)
(function fixVh() {
  const setVh = () => {
    const vh = window.innerHeight * 0.01; // 1% de la hauteur visible
    document.documentElement.style.setProperty('--vh', `${vh}px`);
  };
  setVh();
  window.addEventListener('resize', setVh);
  window.addEventListener('orientationchange', setVh);
})();

// Optionnel : helper pour vider le cache depuis la console
window.clearContributorsCache = function () {
  localStorage.removeItem('atselog.contributors.list.v1');
  localStorage.removeItem('atselog.contributors.ts.v1');
  console.log('Contributors cache cleared.');
};


// Optionnel : helper pour vider le cache depuis la console ou un bouton
window.clearContributorsCache = function () {
  localStorage.removeItem('atselog.contributors.list.v1');
  localStorage.removeItem('atselog.contributors.ts.v1');
  console.log('Contributors cache cleared.');
};

// Spinner Recherche Vile Etat Pays
function showInlineSpinner(el){
  if (!el) return;
  el.innerHTML = '<span class="inline-spinner" aria-label="Chargement…"></span>';
}
function setInlineText(el, txt){
  if (!el) return;
  el.textContent = txt ?? '';
}
// === Enregistrement du Service Worker pour PWA ===
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js")
    .then(() => console.log("✅ Service Worker enregistré"))
    .catch(err => console.warn("❌ Erreur Service Worker :", err));
}

// vider le cache

// === Réinitialisation complète du cache + redirection vers index ===
document.addEventListener('DOMContentLoaded', () => {
  const resetBtn = document.getElementById('reset-cache-app');
  if (!resetBtn) return;

  resetBtn.addEventListener('click', async () => {
    const confirmReset = confirm("Voulez-vous vraiment vider le cache de l'application ?\n\nToutes les données locales seront effacées et vous serez redirigé vers la page d'accueil.");
    if (!confirmReset) return;

    try {
      // Effacer les caches (PWA)
      if ('caches' in window) {
        const names = await caches.keys();
        for (let name of names) await caches.delete(name);
      }

      // Effacer le stockage local et de session
      localStorage.clear();
      sessionStorage.clear();

      // Supprimer les Service Workers (pour éviter les anciens caches)
      if ('serviceWorker' in navigator) {
        const regs = await navigator.serviceWorker.getRegistrations();
        for (let reg of regs) await reg.unregister();
      }

      // Message rapide avant redirection
      alert("Cache vidé avec succès.\nRedirection vers la page principale...");
      window.location.href = "index.html"; // 🔁 redirection vers la page d'accueil

    } catch (err) {
      console.error("Erreur lors du reset du cache :", err);
      alert("Une erreur est survenue lors de la réinitialisation du cache.");
    }
  });
});

// Alerte Plaque Immat Vierge Trailer 2-3
// Alerte plaques remorque quand on passe en D (fatigue désactivée)
// ====== ALERTE SONORE / VIBRATION – plus fort + répétitif ======
let _rwAudioCtx = null;
function playWarnBeepLoud() {
  try {
    _rwAudioCtx = _rwAudioCtx || new (window.AudioContext || window.webkitAudioContext)();
    const ctx = _rwAudioCtx;

    // Envelope commune
    const mkBeep = (freq, startTime) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = "square";                 // plus perçant qu’un sine
      o.frequency.setValueAtTime(freq, startTime);
      g.gain.setValueAtTime(0.0001, startTime);
      g.gain.exponentialRampToValueAtTime(0.5, startTime + 0.02);  // attaque rapide
      g.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.25);
      o.connect(g); g.connect(ctx.destination);
      o.start(startTime); o.stop(startTime + 0.26);
    };

    const t0 = ctx.currentTime;
    // Petit motif triton (2 kHz -> 3 kHz -> 2.4 kHz), très audible dans un moteur
    mkBeep(2000, t0 + 0.00);
    mkBeep(3000, t0 + 0.18);
    mkBeep(2400, t0 + 0.36);
  } catch (e) {
    // silencieux si bloqué par l’OS/navigateur
  }
}

// Répétition jusqu’à acquittement
let _rwAlertTimer = null;
function startWarnLoop() {
  if (_rwAlertTimer) return;
  const doAlert = () => {
    playWarnBeepLoud();
    if (navigator.vibrate) {
      // motif de vibration (fonctionne même en silencieux si vibrations activées par l’utilisateur)
      navigator.vibrate([300, 150, 300]);
    }
  };
  doAlert();                              // lance tout de suite
  _rwAlertTimer = setInterval(doAlert, 6000); // répète toutes les 6 s
}
function stopWarnLoop() {
  if (_rwAlertTimer) { clearInterval(_rwAlertTimer); _rwAlertTimer = null; }
}

// ====== OVERLAY TRIANGLE (identique à avant, avec latch) ======
function ensurePlatesWarningNode() {
  let node = document.getElementById('plates-warning');
  if (node) return node;

  node = document.createElement('div');
  node.id = 'plates-warning';
  node.className = 'road-warning';
  node.innerHTML = `
    <div class="rw-card" id="rw-card">
      <svg class="rw-tri" viewBox="0 0 100 90" aria-hidden="true">
        <path d="M50 5 L95 85 H5 Z" fill="#fff" stroke="#e53935" stroke-width="6"/>
        <rect x="47" y="32" width="6" height="28" rx="3" fill="#e53935"/>
        <circle cx="50" cy="70" r="4" fill="#e53935"/>
      </svg>
      <div class="rw-text" data-i18n="warn_trailer_plates">
        Veuillez remplir les plaques de remorque avant de rouler.
      </div>
    </div>
  `;
  document.body.appendChild(node);

  // Clic = acquittement + stop répétition + redirection
  node.querySelector('#rw-card').addEventListener('click', () => {
    sessionStorage.removeItem('warnedMissingPlatesLatched');
    stopWarnLoop();
    window.location.href = 'vehicules.html';
  });

  return node;
}

function showPlatesWarning() {
  const node = ensurePlatesWarningNode();
  node.style.display = 'flex';
  startWarnLoop();                // ▶️ lance répétition
}
function hidePlatesWarning() {
  const node = ensurePlatesWarningNode();
  node.style.display = 'none';
  stopWarnLoop();                 // ⏹️ stop si jamais on masque
}

// ====== Contrôle avec LATCH (ne disparaît plus tout seul) ======
function checkTrailerPlatesOnD(data) {
  try {
    const isDriving  = Number(data.status) === 2;   // D
    const fatigueOff = Number(data.Auto)   === 0;   // Simulation / fatigue OFF

    // mph (supporte speed_mph ou speed)
    let speedMph = 0;
    if (data.speed_mph != null) speedMph = Number(data.speed_mph) || 0;
    else if (data.speed != null) speedMph = Number(data.speed) || 0;

    const chain = String(data.trailer_ChainType || '').toLowerCase();
    const multiTrailers = chain.includes('double') || chain.includes('bi-train')
                       || chain.includes('triple') || chain.includes('road');

    const t2 = (data.trailer_immat_2 || '').trim();
    const t3 = (data.trailer_immat_3 || '').trim();
    const need2 = (chain.includes('double') || chain.includes('bi-train')) && !t2;
    const need3 = (chain.includes('triple') || chain.includes('road'))     && !t3;
    const missing = need2 || need3;

    const shouldTrigger = isDriving && fatigueOff && multiTrailers && missing && speedMph > 5;
    const latched = sessionStorage.getItem('warnedMissingPlatesLatched') === '1';

    if (!latched) {
      if (shouldTrigger) {
        sessionStorage.setItem('warnedMissingPlatesLatched', '1');
        showPlatesWarning();      // affiche + lance bip/vibration répétés
      } else {
        hidePlatesWarning();      // pas encore déclenché → caché
      }
    } else {
      showPlatesWarning();        // déjà déclenché → reste affiché quoi qu’il arrive
    }
  } catch (e) {
    console.error('checkTrailerPlatesOnD error:', e);
  }
}

// === Retour automatique vers la page index quand D actif ======================
function autoReturnToIndex(data) {
  try {
    // Statut de conduite actif (D = 2)
    const isDriving = Number(data.status) === 2;
    // Mode manuel uniquement (fatigue OFF = Auto=0)
    const fatigueOff = Number(data.Auto) === 0;

    if (isDriving && fatigueOff) {
      // URL actuelle
      const current = window.location.pathname.toLowerCase();

      // Si on n’est PAS déjà sur index, on redirige
      if (!current.endsWith("index.html") && !current.endsWith("/")) {
        console.log("🚚 Statut D actif → retour automatique sur index.html");
        window.location.href = "index.html";
      }
    }
  } catch (e) {
    console.error("autoReturnToIndex error:", e);
  }
}

// ==== ÉTAT HOS — Step 1.1 (fix couleur + bips) ==============================
// - Rouge dès <= 02:00 (spécificité CSS forte)
// - 2 bips (une fois) au passage sous 02:00
// - 3 bips (une fois) au passage sous 01:00
// - Boucle de bips (toutes 20s) < 00:00 (violation)
// - Silence si OFF ou SB (pas de bip dans ces statuts)

(function HOS_Alerts_Step11(){
  // === CSS à forte spécificité (couleur rouge garantie) ===
  (function injectHosAlertStyles() {
    if (document.getElementById('hos-alert-styles')) return;
    const style = document.createElement('style');
    style.id = 'hos-alert-styles';
    style.textContent = `
      #primary-timer.timer-warning,
      #primaryTimer.timer-warning { color:#C62828 !important; font-weight:700 !important; }
      #primary-timer.timer-violation,
      #primaryTimer.timer-violation { color:#C62828 !important; font-weight:800 !important; text-shadow:0 0 0.6px #C62828; }
    `;
    document.head.appendChild(style);
  })();

  // === Helpers DOM / parse ===
  function $(s){ return document.querySelector(s); }
  function getPrimaryEl(){ return $('#primary-timer') || $('#primaryTimer') || null; }

  // Parse "HH:MM" (éventuellement préfixé par - ou −) -> secondes (peut être négatif)
  function parseHHMMToSeconds(txt){
    if (!txt) return NaN;
    const cleaned = String(txt).trim().replace(/[^\d:\-−]/g,'');
    const isNeg = cleaned.startsWith('-') || cleaned.startsWith('−');
    const core = cleaned.replace(/^[-−]/,'');
    const [hS,mS] = core.split(':');
    const h = parseInt(hS,10), m = parseInt(mS,10);
    if (Number.isNaN(h) || Number.isNaN(m)) return NaN;
    const s = h*3600 + m*60;
    return isNeg ? -s : s;
  }

  // Statut courant via les boutons (fallbacks possibles plus tard si besoin)
  function getCurrentStatus(){
    const off = $('#btn-OFF')?.classList.contains('active');
    const sb  = $('#btn-SB') ?.classList.contains('active');
    const d   = $('#btn-D')  ?.classList.contains('active');
    const on  = $('#btn-ON') ?.classList.contains('active');
    if (off) return 'OFF';
    if (sb)  return 'SB';
    if (d)   return 'DRIVING';
    if (on)  return 'ON';
    return 'UNKNOWN';
  }
  function isDrivingOrOn(){ const s = getCurrentStatus(); return s === 'DRIVING' || s === 'ON'; }

// === Moteur audio (bips nets, non “batterie faible”) ===
const audio = {
  ctx: null,
  ensure() {
    try { this.ctx ||= new (window.AudioContext || window.webkitAudioContext)(); }
    catch { /* navigateur peut bloquer → on reste silencieux */ }
    return this.ctx;
  },
  // Bip court, clair, “net”
  bip({ freq = 1350, dur = 110, gain = 0.10, type = 'square' } = {}) {
    const ctx = this.ensure(); if (!ctx) return;
    const osc = ctx.createOscillator();
    const g   = ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    g.gain.value = gain;
    osc.connect(g); g.connect(ctx.destination);
    const t0 = ctx.currentTime;

    // petite enveloppe pour éviter les clics
    g.gain.setValueAtTime(gain, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur/1000);

    osc.start(t0);
    osc.stop(t0 + dur/1000 + 0.005);
  },
  // Enchaînement “n bips” (170 ms de gap). Muet si OFF/SB.
  burst(n, gapMs = 170) {
    if (!isDrivingOrOn()) return;
    let i = 0;
    const tick = () => {
      if (!isDrivingOrOn()) return;
      this.bip();                      // bip net
      if (++i < n) setTimeout(tick, gapMs);
    };
    tick();
  },
  alert2h() { this.burst(2, 170); },   // “bip bip”
  alert1h() { this.burst(3, 170); },   // “bip bip bip”
  violationTick() { this.burst(3, 160); } // utilisé par la boucle < 00:00
};


  // === État interne des seuils ===
  const S2H = 2*3600, S1H = 1*3600;   // secondes
  const RESET_BAND = 7800;            // > 2h10 => on réarme les seuils
  let lastSec = null;
  let fired2h = false;
  let fired1h = false;
  let violationLoop = null;

	function applyVisual(el, secs){
  if (!el) return;
	  // Ne JAMAIS toucher au primary si déjà en overrun
	  if (el.id === 'primary-timer' && el.dataset.isOverrun === '1') return;

	  const warn = (secs <= S2H && secs > 0); // ≤ 2h et > 0 → rouge fixe
	  const viol = (secs <= 0);               // ≤ 00:00 → rouge (géré aussi par overrun)

	  el.classList.toggle('timer-warning',   warn);
	  el.classList.toggle('timer-violation', viol);
	  el.classList.remove('hos-pulse');      // on bannit le pulse avant 00:00
	}


  function startViolationLoop(){
    stopViolationLoop();
    violationLoop = setInterval(()=>{
      if (!isDrivingOrOn()) return;   // pas de bip en OFF/SB
      audio.violationTick();         // 3 bips rapides toutes les 20s
    }, 20000);
  }
  function stopViolationLoop(){
    if (violationLoop) { clearInterval(violationLoop); violationLoop = null; }
  }

  // === Boucle d’observation (1 Hz) ===
  const el = getPrimaryEl();
  if (!el){
    console.warn('[HOS] #primary-timer introuvable → Step 1.1 inactif');
    return;
  }

  setInterval(()=>{
    const txt = (el.textContent||'').trim();
    const secs = parseHHMMToSeconds(txt);
    if (!Number.isFinite(secs)) return;

    applyVisual(el, secs);

    if (lastSec != null){
      // Passage sous 02:00 → 2 bips une seule fois
      if (!fired2h && lastSec > S2H && secs <= S2H) {
        if (isDrivingOrOn()) audio.alert2h();
        fired2h = true;
      }
      // Passage sous 01:00 → 3 bips une seule fois
      if (!fired1h && lastSec > S1H && secs <= S1H) {
        if (isDrivingOrOn()) audio.alert1h();
        fired1h = true;
      }
      // Début violation (<= 00:00) → boucle régulière
      if (lastSec > 0 && secs <= 0) {
        startViolationLoop();
      }
      // Si on remonte au-dessus de 02:10 (reset naturel) → réarmement
      if (secs > RESET_BAND) {
        fired2h = false; fired1h = false;
      }
      // Si on repasse clairement > 00:01 → on stoppe la boucle violation
      if (secs > 60 && violationLoop) {
        stopViolationLoop();
      }
    }
    lastSec = secs;
  }, 1000);
})();

// ==== ÉTAT HOS — Step 2 : négatif continu + propagation ====================
// ==== HOS_OVERRUN_FINAL — affichage négatif après 00:00, sans conflit UI ====
(function () {
  function $(s){ return document.querySelector(s); }
  function getPrimaryEl(){ return $('#primary-timer') || $('#primaryTimer') || null; }

  // Parse "HH:MM" (éventuellement avec un signe) -> secondes (peut être négatif)
  function parseHHMMToSeconds(txt){
    if (!txt) return NaN;
    const cleaned = String(txt).trim().replace(/[^\d:\-−]/g,'');
    const neg = cleaned.startsWith('-') || cleaned.startsWith('−');
    const core = cleaned.replace(/^[-−]/,'');
    const [hS,mS] = core.split(':');
    const h = parseInt(hS,10), m = parseInt(mS,10);
    if (Number.isNaN(h) || Number.isNaN(m)) return NaN;
    const s = h*3600 + m*60;
    return neg ? -s : s;
  }
  function toHHMM(sec){
    sec = Math.max(0, sec|0);
    const h = String(Math.floor(sec/3600)).padStart(2,'0');
    const m = String(Math.floor((sec%3600)/60)).padStart(2,'0');
    return `${h}:${m}`;
  }
  function getCurrentStatus(){
    const off = $('#btn-OFF')?.classList.contains('active');
    const sb  = $('#btn-SB') ?.classList.contains('active');
    const d   = $('#btn-D')  ?.classList.contains('active');
    const on  = $('#btn-ON') ?.classList.contains('active');
    if (off) return 'OFF';
    if (sb)  return 'SB';
    if (d)   return 'DRIVING';
    if (on)  return 'ON';
    return 'UNKNOWN';
  }

  const primaryEl = getPrimaryEl();
  if (!primaryEl) return;

  let overrun = { active:false, startGameMin:0 };

  setInterval(() => {
    const status = getCurrentStatus();

    // OFF/SB : on fige le compteur, mais on GARDE le visuel négatif
	if (status === 'OFF' || status === 'SB') {
	  overrun.active = true;                 // on laisse actif pour conserver l'affichage
	  // ⚠️ ne pas retirer les classes, ne pas remettre isOverrun à 0
	  return;
	}


    // source "propre" du plugin
    const raw = (primaryEl.dataset.rawTimer || primaryEl.textContent || '').trim();
    const sec = parseHHMMToSeconds(raw);

    // Tant que > 0 : JAMAIS on ne modifie le texte (l’UI reste maître)
    if (Number.isFinite(sec) && sec > 0) {
      overrun.active = false;
      return;
    }

    // À partir de 00:00 en D/ON : on affiche le négatif basé sur l’heure de jeu
    if ((status === 'DRIVING' || status === 'ON')) {
      // À chaque tick, on récupère la minute du jour actuelle
	const gameMin = window._lastGameMin | 0;
      if (!overrun.active) {
        overrun.active = true;
        overrun.startMin = window._lastGameMin | 0; // minute de départ dans la journée (0..1439)
		primaryEl.dataset.isOverrun = "1";
      }
	  
	
	
	
	// Écart en minutes en gérant le passage de minuit
	let elapsedMin = gameMin - overrun.startMin;
	if (elapsedMin < 0) elapsedMin += 1440;

// ==== HOS_OVERRUN_PERSIST — conserve/restaure le négatif au refresh =====
(function(){
  const elP = document.getElementById('primary-timer');
  const elD = document.getElementById('driveTimer');
  const elW = document.getElementById('workdayTimer');
  if (!elP) return;

  const LSKEY = 'atselog.overrun'; // { day, startMin }
  let tick = null;

  // Utilitaire: HH:MM pour secondes (négatives possibles)
  function fmtHMM(totalSec){
    const neg = totalSec < 0;
    let s = Math.abs(totalSec)|0;
    const h = Math.floor(s/3600);
    const m = Math.floor((s%3600)/60);
    const txt = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;
    return neg ? `-${txt}` : txt;
  }

  function saveOverrun(startMin) {
    const day = new Date().toDateString(); // journée réelle affichée
    localStorage.setItem(LSKEY, JSON.stringify({ day, startMin }));
    elP.dataset.isOverrun = '1';
  }
  function clearOverrun() {
    localStorage.removeItem(LSKEY);
    elP.dataset.isOverrun = '';
    // Restaure le texte reçu
    if (elP.dataset.rawTimer) elP.textContent = elP.dataset.rawTimer;
    if (elD?.dataset.rawTimer) elD.textContent = elD.dataset.rawTimer;
    if (elW?.dataset.rawTimer) elW.textContent = elW.dataset.rawTimer;
    elP.classList.remove('timer-violation','hos-pulse');
    elD?.classList.remove('timer-violation');
    elW?.classList.remove('timer-violation');
    if (tick) { clearInterval(tick); tick = null; }
  }

  // Restaure si besoin à l'ouverture
  try {
    const raw = localStorage.getItem(LSKEY);
    if (raw) {
      const { day, startMin } = JSON.parse(raw);
      if (day === new Date().toDateString()) {
        startOverrun(startMin|0, /*resume*/true);
      } else {
        localStorage.removeItem(LSKEY);
      }
    }
  } catch {}

  function startOverrun(startMin, resume=false){
    // Marque visuelle immédiate
    elP.classList.add('timer-violation','hos-pulse');
    elP.dataset.isOverrun = '1';
    if (!resume) saveOverrun(startMin);

    if (tick) clearInterval(tick);
    tick = setInterval(() => {
      const gd = window.lastGameData || {};
      // minute en jeu actuelle normalisée 0..1439
      const nowMin = ((gd.game_time|0) % 1440 + 1440) % 1440;
      // minutes écoulées depuis l’entrée en négatif (gère le wrap minuit)
      const diffMin = (nowMin - startMin + 1440) % 1440;
      const negSec = -diffMin * 60;

      // PRIMARY: toujours en négatif
      elP.textContent = fmtHMM(negSec);
      elP.dataset.isOverrun = '1';

      // Choix du timer actif selon statut courant (DRIVING vs ON)
      const status = (gd.statusText || '').toUpperCase() || (window.getCurrentStatus?.() || '');
      if (status === 'DRIVING' && elD) {
        elD.textContent = fmtHMM(negSec);
        elD.classList.add('timer-violation');
      } else if (status === 'ON' && elW) {
        elW.textContent = fmtHMM(negSec);
        elW.classList.add('timer-violation');
      }

      // Silence si OFF/SB (tu le fais déjà côté bips), ici on ne touche rien.

      // TODO (quand prêt) : détecter 10h de OFF/SB → clearOverrun()
      // if (gd.rest10hDone === true) clearOverrun();
    }, 1000);
  }

  // Détection du passage sous 00:00 : à appeler quand tu détectes la bascule.
  // Exemple: juste après avoir parsé data.*rem → si <= "00:00", on "latch"
  window.hosEnterOverrunIfNeeded = function(currentPrimaryText){
    // Appelle cette fonction là où tu sais que primary vient d’atteindre 00:00.
    if (elP.dataset.isOverrun === '1') return;
    // Utilise window._lastGameMin mis à jour par updateUI
    const startMin = (window._lastGameMin|0);
    startOverrun(startMin);
	
  };



})();



    
    }
  });
})();
