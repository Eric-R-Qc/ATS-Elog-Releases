/* Pont Android : sans effet dans le navigateur PC/PWA.
   L'APK charge l'interface depuis ses fichiers locaux, redirige les appels
   relatifs vers le plugin sur le PC et garde la dernière réponse utilisable
   lorsque ATS est arrêté. */
(() => {
  const bridge = window.Android;
  if (!bridge || typeof bridge.getApiBase !== 'function') return;

  // Distingue l'APK de la version Web ouverte dans un navigateur mobile.
  // La PWA est utile dans Safari/Chrome, mais pas dans l'APK déjà installée.
  document.documentElement.classList.add('android-native');
  document.addEventListener('DOMContentLoaded', () => {
    document.body.classList.add('android-native');
  }, { once: true });

  // La connexion depuis la page Web transporte aussi les préférences visibles
  // de l'utilisateur. Elles sont appliquées avant le chargement de script.js,
  // afin que le premier écran de l'APK utilise tout de suite la bonne langue
  // et le même nom de conducteur.
  try {
    const initialLang = typeof bridge.getInitialLanguage === 'function'
      ? String(bridge.getInitialLanguage() || '').trim().toLowerCase()
      : '';
    const initialDriver = typeof bridge.getInitialDriverName === 'function'
      ? String(bridge.getInitialDriverName() || '').trim()
      : '';
    const profileSignature = JSON.stringify([initialLang, initialDriver]);
    const profileKey = 'atselog.android.profile.seed.v1';
    if ((initialLang || initialDriver) && localStorage.getItem(profileKey) !== profileSignature) {
      if (/^(fr|en|es|de)$/.test(initialLang)) localStorage.setItem('lang', initialLang);
      if (initialDriver) localStorage.setItem('nomChauffeur', initialDriver);
      localStorage.setItem(profileKey, profileSignature);
    }
  } catch (_) {}

  const base = String(bridge.getApiBase() || '').replace(/\/$/, '');
  if (!base) return;

  // Métadonnée de l'APK native, utilisée uniquement pour les mises à jour
  // Android. Elle ne dépend jamais de la version du DLL ATS Elog.
  try {
    if (typeof bridge.getAppVersion === 'function') {
      window.ATS_ELOG_ANDROID_VERSION = String(bridge.getAppVersion() || '').trim();
    }
  } catch (_) {}

  const nativeFetch = window.fetch.bind(window);
  const cachePrefix = 'atselog.android.response.v1.';

  function remoteUrl(input) {
    const raw = input instanceof Request ? input.url : String(input);
    const url = new URL(raw, window.location.href);
    if (url.origin === window.location.origin && url.pathname.startsWith('/')) {
      return base + url.pathname + url.search;
    }
    return input;
  }

  function cacheKey(input) {
    const raw = input instanceof Request ? input.url : String(input);
    return cachePrefix + btoa(unescape(encodeURIComponent(raw))).slice(0, 220);
  }

  window.fetch = async (input, init = {}) => {
    const method = String(init.method || (input instanceof Request ? input.method : 'GET')).toUpperCase();
    const key = cacheKey(input);
    try {
      const response = await nativeFetch(remoteUrl(input), init);
      if (method === 'GET' && response.ok) {
        response.clone().text().then(text => {
          localStorage.setItem(key, JSON.stringify({ text, type: response.headers.get('content-type') || 'application/json' }));
        }).catch(() => {});
      }
      return response;
    } catch (error) {
      if (method === 'GET') {
        try {
          const cached = JSON.parse(localStorage.getItem(key) || 'null');
          if (cached && typeof cached.text === 'string') {
            return new Response(cached.text, { status: 200, headers: { 'Content-Type': cached.type } });
          }
        } catch (_) {}
      }
      throw error;
    }
  };
})();
