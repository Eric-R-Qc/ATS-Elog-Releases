ATS Elog 1.0.5 Beta
Copyright (c) 2025-2026 Eric R. All rights reserved.

EASY INSTALLATION
1. Close American Truck Simulator.
2. Fully extract the ZIP to a temporary folder.
3. Find the ATS bin\win_x64 folder through Steam (explained below).
4. Copy the supplied win_x64 folder contents into ATS bin\win_x64. Accept merging folders and replacing ATS_Elog.dll if Windows asks.
5. Open a browser on the same PC and go to:
   http://localhost:8080/index.html
   An error page before ATS starts is normal.
6. Start ATS and load your profile. Once you are in the truck, the page refreshes automatically and the log appears.
7. Press Ctrl+F5 once only if an older interface is still displayed.

FIND THE ATS INSTALLATION FOLDER IN STEAM
1. Open Steam, then Library.
2. Right-click American Truck Simulator.
3. Select Manage, then Browse local files.
4. In File Explorer, open bin and then win_x64.
5. Keep this window open: it is the destination folder for the copy.

MANUAL INSTALLATION
Copy the supplied win_x64 folder contents to:
...\Steam\steamapps\common\American Truck Simulator\bin\win_x64\

You should have:
bin\win_x64\plugins\ATS_Elog.dll
bin\win_x64\ats_elog\App\index.html

MOBILE / TABLET ACCESS
With ATS running, open Settings and use the external-interface link. Your phone/tablet and PC must be on the same Wi-Fi network.

SUPPORT AND OFFICIAL LINKS
SCS Forum: https://forum.scssoft.com/viewtopic.php?t=342205
Discord: https://discord.gg/RgREczXMcx
Email: ats.elog@gmail.com
Buy me a coffee: https://paypal.me/ericrqc

Download ATS Elog only from official links to avoid outdated or modified versions.
