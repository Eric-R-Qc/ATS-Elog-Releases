// Incrémenté à chaque mise à jour des ressources UI afin que l'application
// ne continue pas à servir un ancien script depuis le cache hors-ligne.
const CACHE = 'elog-v65';

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(cache =>
    cache.addAll([
      '/index.html',
      '/logs.html',
      '/vehicules.html',
      '/settings.html',
      '/documentation.html',
      '/about.html',
      '/dev.html',
      '/style.css',
      '/cities-ats.js',
      '/api-bridge.js',
      '/script.js',
      '/profile-sync.js',
      '/settings-guard.js',
      '/documentation.js',
      '/scriptlogs.js', // ← corrige la typo
      '/telemetry-consent.js',
      '/textures/icon-conv.png',
      '/textures/icon-conr.png',
      '/textures/ats_elog_icon.ico',
      '/textures/icon-192.png',
      '/textures/icon-512.png',
      '/manifest.json'
    ])
  ));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys
        .filter(k => k.startsWith('elog-') && k !== CACHE)
        .map(k => caches.delete(k))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;

  // Réseau d'abord : données live fraîches lorsque ATS fonctionne.
  // Repli cache : les pages, LogBooks et dernière télémétrie déjà consultés
  // restent lisibles si le jeu ou le serveur local sont arrêtés.
  e.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const url = new URL(e.request.url);
    const isLiveData = url.origin === self.location.origin && (
      url.pathname === '/data91' ||
      url.pathname === '/logs-list' ||
      /^\/hos_.*\.json$/i.test(url.pathname)
    );

    // Hors jeu, servir immédiatement la dernière page et les journaux déjà
    // consultés. Le réseau reste prioritaire uniquement pour la télémétrie.
    if (!isLiveData) {
      const cached = await cache.match(e.request);
      if (cached) {
        e.waitUntil(fetch(e.request).then(response => {
          if (response && response.ok && url.origin === self.location.origin) {
            return cache.put(e.request, response.clone());
          }
        }).catch(() => {}));
        return cached;
      }
    }
    try {
      const response = await fetch(e.request);
      if (response && response.ok && url.origin === self.location.origin) {
        cache.put(e.request, response.clone());
      }
      return response;
    } catch (_) {
      const cached = await cache.match(e.request);
      if (cached) return cached;
      throw _;
    }
  })());
});
