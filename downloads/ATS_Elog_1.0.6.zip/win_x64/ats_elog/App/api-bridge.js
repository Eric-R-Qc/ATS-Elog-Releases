/* Pont Android : sans effet dans le navigateur PC/PWA.
   L'APK charge l'interface depuis ses fichiers locaux, redirige les appels
   relatifs vers le plugin sur le PC et garde la dernière réponse utilisable
   lorsque ATS est arrêté. */
(() => {
  const bridge = window.Android;
  if (!bridge || typeof bridge.getApiBase !== 'function') return;

  // Distingue l'APK de la version Web ouverte dans un navigateur mobile.
  // La PWA est utile dans Safari/Chrome, mais pas dans l'APK déjà installée.
  document.documentElement.classList.add('android-native');
  document.addEventListener('DOMContentLoaded', () => {
    document.body.classList.add('android-native');
  }, { once: true });

  // La connexion depuis la page Web transporte aussi les préférences visibles
  // de l'utilisateur. Elles sont appliquées avant le chargement de script.js,
  // afin que le premier écran de l'APK utilise tout de suite la bonne langue
  // et le même nom de conducteur.
  try {
    const initialLang = typeof bridge.getInitialLanguage === 'function'
      ? String(bridge.getInitialLanguage() || '').trim().toLowerCase()
      : '';
    const initialDriver = typeof bridge.getInitialDriverName === 'function'
      ? String(bridge.getInitialDriverName() || '').trim()
      : '';
    const profileSignature = JSON.stringify([initialLang, initialDriver]);
    const profileKey = 'atselog.android.profile.seed.v1';
    if ((initialLang || initialDriver) && localStorage.getItem(profileKey) !== profileSignature) {
      if (/^(fr|en|es|de)$/.test(initialLang)) localStorage.setItem('lang', initialLang);
      if (initialDriver) localStorage.setItem('nomChauffeur', initialDriver);
      localStorage.setItem(profileKey, profileSignature);
    }
  } catch (_) {}

  const base = String(bridge.getApiBase() || '').replace(/\/$/, '');
  if (!base) return;

  // Le même téléphone peut changer de PC ATS. Les données du camion, du QG
  // et des LogBooks ne doivent surtout pas traverser ce changement, alors que
  // la langue, le thème et le nom du conducteur restent des préférences du
  // téléphone. Les réponses HTTP seront aussi séparées par serveur ci-dessous.
  try {
    const serverKey = 'atselog.android.server.v1';
    const previousBase = localStorage.getItem(serverKey) || '';
    if (previousBase && previousBase !== base) {
      [
        'lastValidData',
        'atselog.hq_city',
        'atselog.htz.raw_city',
        'atselog.tz',
        'atselog.cache.tz',
        'atselog.logs.list.v1',
        'atselog.rods.tz_plan'
      ].forEach(key => localStorage.removeItem(key));
    }
    localStorage.setItem(serverKey, base);
  } catch (_) {}

  // Métadonnée de l'APK native, utilisée uniquement pour les mises à jour
  // Android. Elle ne dépend jamais de la version du DLL ATS Elog.
  try {
    if (typeof bridge.getAppVersion === 'function') {
      window.ATS_ELOG_ANDROID_VERSION = String(bridge.getAppVersion() || '').trim();
    }
  } catch (_) {}

  const nativeFetch = window.fetch.bind(window);

  // La v2 utilisait l'URL complète comme clé. Or /data91 reçoit ?t=... à
  // chaque seconde : une entrée distincte était donc créée à chaque lecture,
  // jusqu'à saturer le stockage WebView et figer l'écran. On élimine ces
  // anciennes copies une fois et la v3 normalise l'URL ci-dessous.
  try {
    Object.keys(localStorage)
      .filter(key => key.startsWith('atselog.android.response.v2.'))
      .forEach(key => localStorage.removeItem(key));
  } catch (_) {}

  const cachePrefix = 'atselog.android.response.v3.' + btoa(unescape(encodeURIComponent(base))).slice(0, 120) + '.';

  function remoteUrl(input) {
    const raw = input instanceof Request ? input.url : String(input);
    const url = new URL(raw, window.location.href);
    if (url.origin === window.location.origin && url.pathname.startsWith('/')) {
      return base + url.pathname + url.search;
    }
    return input;
  }

  function cacheKey(input) {
    const raw = input instanceof Request ? input.url : String(input);
    const url = new URL(raw, window.location.href);
    // Le cache hors-ligne garde la dernière réponse de chaque route, jamais
    // les centaines de variantes ?t= créées par le rafraîchissement live.
    url.searchParams.delete('t');
    return cachePrefix + btoa(unescape(encodeURIComponent(url.pathname + url.search))).slice(0, 220);
  }

  function isLiveTelemetry(input) {
    const raw = input instanceof Request ? input.url : String(input);
    try { return new URL(raw, window.location.href).pathname === '/data91'; }
    catch (_) { return false; }
  }

  window.fetch = async (input, init = {}) => {
    const method = String(init.method || (input instanceof Request ? input.method : 'GET')).toUpperCase();
    const key = cacheKey(input);
    try {
      const response = await nativeFetch(remoteUrl(input), init);
      if (method === 'GET' && response.ok) {
        response.clone().text().then(text => {
          try {
            localStorage.setItem(key, JSON.stringify({ text, type: response.headers.get('content-type') || 'application/json' }));
          } catch (_) {
            // Le cache hors ligne est optionnel : un manque d'espace ne doit
            // jamais empêcher l'affichage de la télémétrie en direct.
          }
        }).catch(() => {});
      }
      return response;
    } catch (error) {
      // La télémétrie ne doit jamais être remplacée silencieusement par le
      // cache : script.js doit connaître l'échec et passer l'icône au rouge.
      // Les autres routes (journaux, pages) peuvent rester consultables hors
      // connexion grâce au cache.
      if (method === 'GET' && !isLiveTelemetry(input)) {
        try {
          const cached = JSON.parse(localStorage.getItem(key) || 'null');
          if (cached && typeof cached.text === 'string') {
            return new Response(cached.text, { status: 200, headers: { 'Content-Type': cached.type } });
          }
        } catch (_) {}
      }
      throw error;
    }
  };
})();
