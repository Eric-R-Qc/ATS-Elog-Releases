/* ATS Elog — consentement aux statistiques anonymes.
 * Aucun trajet, LogBook, pseudo, position ou adresse IP n'est volontairement
 * transmis. Ce fichier ne contacte le service que lorsque l'utilisateur a
 * explicitement accepté dans le dialogue ci-dessous.
 */
(function () {
  'use strict';

  const CONSENT_KEY = 'atselog.telemetry.consent';
  const DEVICE_KEY = 'atselog.telemetry.device_id';
  const LAST_SENT_KEY = 'atselog.telemetry.last_interface_ping';
  const ENDPOINT = 'https://ats-elog-stats.ats-elog.workers.dev/api/collect';
  const PING_INTERVAL = 12 * 60 * 60 * 1000;

  const TEXT = {
    fr: { title: 'Aidez ATS Elog à évoluer', body: 'Acceptez-vous de partager des statistiques anonymes d’utilisation ? Elles permettent de savoir combien de personnes utilisent réellement ATS Elog et quelles versions restent à mettre à jour.', private: 'Aucun nom, trajet, position, pseudo, LogBook ni donnée personnelle n’est envoyé.', accept: 'Accepter', decline: 'Non merci', settings: 'Télémetrie anonyme', enabled: 'Participer aux statistiques anonymes d’utilisation', detail: 'Vous pouvez modifier ce choix à tout moment. Les données servent uniquement à suivre l’utilisation globale et améliorer ATS Elog.' },
    en: { title: 'Help ATS Elog improve', body: 'Would you like to share anonymous usage statistics? They help us understand how many people really use ATS Elog and which versions still need updating.', private: 'No name, trip, location, username, LogBook or personal data is sent.', accept: 'Accept', decline: 'No thanks', settings: 'Anonymous telemetry', enabled: 'Take part in anonymous usage statistics', detail: 'You can change this choice at any time. Data is only used to measure overall usage and improve ATS Elog.' },
    de: { title: 'Hilf, ATS Elog zu verbessern', body: 'Möchtest du anonyme Nutzungsstatistiken teilen? Damit sehen wir, wie viele Personen ATS Elog wirklich verwenden und welche Versionen noch aktualisiert werden müssen.', private: 'Es werden weder Name, Fahrt, Standort, Benutzername, LogBook noch persönliche Daten gesendet.', accept: 'Akzeptieren', decline: 'Nein, danke', settings: 'Anonyme Telemetrie', enabled: 'An anonymen Nutzungsstatistiken teilnehmen', detail: 'Du kannst diese Auswahl jederzeit ändern. Die Daten dienen ausschließlich der allgemeinen Nutzungsmessung und der Verbesserung von ATS Elog.' },
    es: { title: 'Ayuda a mejorar ATS Elog', body: '¿Aceptas compartir estadísticas anónimas de uso? Permiten saber cuántas personas utilizan realmente ATS Elog y qué versiones deben actualizarse.', private: 'No se envían nombre, viaje, ubicación, usuario, LogBook ni datos personales.', accept: 'Aceptar', decline: 'No, gracias', settings: 'Telemetría anónima', enabled: 'Participar en las estadísticas anónimas de uso', detail: 'Puedes cambiar esta decisión en cualquier momento. Los datos solo sirven para medir el uso global y mejorar ATS Elog.' }
  };

  function language() {
    const value = String(localStorage.getItem('lang') || document.documentElement.lang || 'fr').slice(0, 2).toLowerCase();
    return TEXT[value] ? value : 'fr';
  }
  function strings() { return TEXT[language()]; }
  function deviceId() {
    let id = localStorage.getItem(DEVICE_KEY);
    if (!id) {
      id = (crypto && crypto.randomUUID) ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
      localStorage.setItem(DEVICE_KEY, id);
    }
    return id;
  }
  function platform() {
    const ua = navigator.userAgent || '';
    if (/android/i.test(ua)) return 'android';
    if (/iphone|ipad|ipod/i.test(ua)) return 'ios';
    return 'web-pc';
  }
  function sendInterfacePing() {
    if (localStorage.getItem(CONSENT_KEY) !== 'yes') return;
    const now = Date.now();
    if (now - Number(localStorage.getItem(LAST_SENT_KEY) || 0) < PING_INTERVAL) return;
    const payload = { id: deviceId(), event: 'interface_open', version: String(window.ATS_ELOG_BUILD || 'unknown'), platform: platform() };
    fetch(ENDPOINT, { method: 'POST', mode: 'cors', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload), keepalive: true }).then(response => {
      if (response.ok) localStorage.setItem(LAST_SENT_KEY, String(now));
    }).catch(() => { /* Hors ligne ou service non encore publié : ne rien bloquer. */ });
  }
  function closeDialog() { document.getElementById('ats-telemetry-dialog')?.remove(); }
  function showDialog() {
    if (localStorage.getItem(CONSENT_KEY)) return;
    const t = strings();
    const dialog = document.createElement('div');
    dialog.id = 'ats-telemetry-dialog';
    dialog.innerHTML = `<section role="dialog" aria-modal="true" aria-labelledby="ats-telemetry-title" class="ats-telemetry-card"><h2 id="ats-telemetry-title">📊 ${t.title}</h2><p>${t.body}</p><p class="ats-telemetry-private">🔒 ${t.private}</p><div class="ats-telemetry-actions"><button type="button" data-choice="no" class="ats-telemetry-secondary">${t.decline}</button><button type="button" data-choice="yes" class="ats-telemetry-primary">${t.accept}</button></div></section>`;
    dialog.addEventListener('click', event => {
      const choice = event.target?.dataset?.choice;
      if (!choice) return;
      localStorage.setItem(CONSENT_KEY, choice);
      closeDialog();
      if (choice === 'yes') sendInterfacePing();
      renderSettings();
    });
    document.body.append(dialog);
  }
  function renderSettings() {
    const target = document.getElementById('ats-telemetry-settings');
    if (!target) return;
    const t = strings();
    const enabled = localStorage.getItem(CONSENT_KEY) === 'yes';
    target.innerHTML = `<section class="ats-telemetry-settings-card"><h3>📊 ${t.settings}</h3><label><input type="checkbox" id="ats-telemetry-toggle" ${enabled ? 'checked' : ''}> <strong>${t.enabled}</strong></label><p>${t.detail}</p></section>`;
    target.querySelector('#ats-telemetry-toggle').addEventListener('change', event => {
      localStorage.setItem(CONSENT_KEY, event.target.checked ? 'yes' : 'no');
      if (event.target.checked) sendInterfacePing();
    });
  }
  function injectStyle() {
    const style = document.createElement('style');
    style.textContent = `#ats-telemetry-dialog{position:fixed;inset:0;z-index:10000;display:grid;place-items:center;padding:1rem;background:#071525a8}.ats-telemetry-card{width:min(31rem,100%);padding:1.35rem;border-radius:18px;background:#fff;color:#18222c;box-shadow:0 18px 50px #0008}.ats-telemetry-card h2{text-align:center;margin:.1rem 0 1rem}.ats-telemetry-card p{line-height:1.45}.ats-telemetry-private{padding:.7rem;border-radius:10px;background:#e8f5eb;color:#17633a;font-size:.92em}.ats-telemetry-actions{display:flex;gap:.7rem;justify-content:center;margin-top:1.15rem}.ats-telemetry-actions button{border:0;border-radius:9px;padding:.7rem 1rem;font-weight:700;font-size:1rem;cursor:pointer}.ats-telemetry-primary{background:#14528a;color:#fff}.ats-telemetry-secondary{background:#e8edf2;color:#263849}.ats-telemetry-settings-card{margin:1rem 0;padding:1rem;border:1px solid #cbd9e7;border-radius:12px;background:#f5f9fd}.ats-telemetry-settings-card h3{margin:0 0 .65rem}.ats-telemetry-settings-card p{margin:.7rem 0 0;color:#506272;font-size:.9em}html[data-theme="dark"] .ats-telemetry-card{background:#1c232b;color:#f3f7fb}html[data-theme="dark"] .ats-telemetry-private{background:#244033;color:#d9f5e0}html[data-theme="dark"] .ats-telemetry-settings-card{background:#1c2731;border-color:#385068}html[data-theme="dark"] .ats-telemetry-settings-card p{color:#c5d1dd}@media(max-width:420px){.ats-telemetry-card{padding:1rem}.ats-telemetry-actions{flex-direction:column-reverse}.ats-telemetry-actions button{width:100%}}`;
    document.head.append(style);
  }
  document.addEventListener('DOMContentLoaded', () => { injectStyle(); renderSettings(); setTimeout(showDialog, 350); if (localStorage.getItem(CONSENT_KEY) === 'yes') sendInterfacePing(); });
  window.atsElogTelemetry = { sendInterfacePing, renderSettings };
})();
