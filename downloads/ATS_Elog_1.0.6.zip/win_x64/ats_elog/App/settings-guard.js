/* Protection des réglages non sauvegardés.
   Les changements restent dans le formulaire jusqu'à ce que le conducteur
   choisisse Enregistrer, Quitter sans enregistrer ou Annuler. */
(() => {
  const copy = {
    fr: { title: 'Modifications non enregistrées', body: 'Voulez-vous enregistrer vos réglages avant de quitter cette page ?', save: 'Enregistrer', discard: 'Quitter sans enregistrer', cancel: 'Annuler', failed: 'Impossible de synchroniser les réglages. Vérifie la connexion ATS Elog ou choisis « Quitter sans enregistrer ».' },
    en: { title: 'Unsaved changes', body: 'Do you want to save your settings before leaving this page?', save: 'Save', discard: 'Leave without saving', cancel: 'Cancel', failed: 'Unable to synchronize settings. Check the ATS Elog connection or choose “Leave without saving”.' },
    es: { title: 'Cambios sin guardar', body: '¿Quieres guardar los ajustes antes de salir de esta página?', save: 'Guardar', discard: 'Salir sin guardar', cancel: 'Cancelar', failed: 'No se pudieron sincronizar los ajustes. Comprueba la conexión de ATS Elog o elige « Salir sin guardar ».' },
    de: { title: 'Ungespeicherte Änderungen', body: 'Möchtest du deine Einstellungen speichern, bevor du diese Seite verlässt?', save: 'Speichern', discard: 'Ohne Speichern verlassen', cancel: 'Abbrechen', failed: 'Die Einstellungen konnten nicht synchronisiert werden. Prüfe die ATS-Elog-Verbindung oder wähle „Ohne Speichern verlassen“. ' }
  };

  const text = () => copy[localStorage.getItem('lang')] || copy.fr;
  let originalSettings = null;

  function applyFormToStorage() {
    const lang = document.getElementById('lang');
    const convoy = document.getElementById('convoyMode');
    const dark = document.getElementById('darkMode');
    const tz = document.getElementById('tzMode');
    if (lang) localStorage.setItem('lang', lang.value);
    if (convoy) localStorage.setItem('convoy_mode', convoy.checked ? '1' : '0');
    if (dark) {
      localStorage.setItem('atselog.theme', dark.checked ? 'dark' : 'light');
      document.documentElement.dataset.theme = dark.checked ? 'dark' : 'light';
    }
    if (tz) localStorage.setItem('tz_mode', tz.value);
  }

  async function discard() {
    const profile = window.ATS_ELOG_UI_PROFILE;
    if (originalSettings && profile?.applySettings) profile.applySettings(originalSettings);
    profile?.discardUnsavedSettings?.();
    await profile?.syncFromServer?.(false);
  }

  function ask(target) {
    if (document.getElementById('settings-leave-modal')) return;
    const t = text();
    const modal = document.createElement('div');
    modal.id = 'settings-leave-modal';
    modal.className = 'update-modal show';
    modal.innerHTML = `<div class="update-card"><h3>${t.title}</h3><p>${t.body}</p><p data-error style="display:none;color:#b42318;font-size:.9em"></p><div class="update-actions"><button type="button" data-cancel>${t.cancel}</button><button type="button" data-discard>${t.discard}</button><button type="button" class="btn btn-primary" data-save>${t.save}</button></div></div>`;
    const go = () => { window.location.href = target; };
    modal.querySelector('[data-cancel]').onclick = () => modal.remove();
    modal.querySelector('[data-discard]').onclick = async () => {
      modal.querySelectorAll('button').forEach(button => { button.disabled = true; });
      await discard();
      go();
    };
    modal.querySelector('[data-save]').onclick = async () => {
      const button = modal.querySelector('[data-save]');
      button.disabled = true;
      applyFormToStorage();
      const saved = await window.ATS_ELOG_UI_PROFILE?.save?.();
      if (saved !== false) {
        originalSettings = window.ATS_ELOG_UI_PROFILE?.localSettings?.() || originalSettings;
        go();
        return;
      }
      button.disabled = false;
      const error = modal.querySelector('[data-error]');
      error.textContent = t.failed;
      error.style.display = 'block';
    };
    document.body.appendChild(modal);
  }

  document.addEventListener('DOMContentLoaded', () => {
    originalSettings = window.ATS_ELOG_UI_PROFILE?.localSettings?.() || null;
    document.addEventListener('click', event => {
      const link = event.target.closest?.('a[href]');
      if (!link || event.defaultPrevented || link.target || link.hasAttribute('download')) return;
      const target = new URL(link.href, window.location.href);
      if (target.href === window.location.href || !window.ATS_ELOG_UI_PROFILE?.hasUnsavedSettings?.()) return;
      event.preventDefault();
      ask(target.href);
    }, true);
    window.addEventListener('beforeunload', event => {
      if (!window.ATS_ELOG_UI_PROFILE?.hasUnsavedSettings?.()) return;
      event.preventDefault();
      event.returnValue = '';
    });
  }, { once: true });
})();
