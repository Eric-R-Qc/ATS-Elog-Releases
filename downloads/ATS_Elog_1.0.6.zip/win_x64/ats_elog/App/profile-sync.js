/* Profil partagé ATS Elog 1.0.6.
   Les préférences de conduite suivent le profil ATS, pas l'écran utilisé. */
(() => {
  const profileEndpoint = '/api/ui/profile';
  const validLanguages = new Set(['fr', 'en', 'es', 'de']);
  let hasUnsavedSettings = false;
  let lastConnectionCardCheckAt = 0;

  function cleanDriver(value) {
    return String(value || '').replace(/^🪪\s*/u, '').trim().replace(/\s+/g, ' ').slice(0, 80);
  }

  function localSettings() {
    const active = cleanDriver(localStorage.getItem('nomChauffeur'));
    let drivers = [];
    try { drivers = JSON.parse(localStorage.getItem('atselog.drivers.v1') || '[]'); } catch (_) {}
    drivers = Array.isArray(drivers) ? drivers.map(cleanDriver).filter(Boolean) : [];
    if (active && !drivers.includes(active)) drivers.push(active);
    return {
      language: validLanguages.has(localStorage.getItem('lang')) ? localStorage.getItem('lang') : 'fr',
      dark_mode: localStorage.getItem('atselog.theme') === 'dark',
      convoy_mode: localStorage.getItem('convoy_mode') === '1',
      personal_driving: localStorage.getItem('atselog.personalDriving') === '1',
      timezone_mode: ['off', 'auto', 'htz'].includes(localStorage.getItem('tz_mode'))
        ? localStorage.getItem('tz_mode') : 'off',
      drivers,
      active_driver: active
    };
  }

  function applySettings(settings) {
    if (!settings || typeof settings !== 'object') return false;
    const before = JSON.stringify(localSettings());
    const language = validLanguages.has(settings.language) ? settings.language : 'fr';
    const active = cleanDriver(settings.active_driver);
    const drivers = Array.isArray(settings.drivers)
      ? [...new Set(settings.drivers.map(cleanDriver).filter(Boolean))].slice(0, 20) : [];
    if (active && !drivers.includes(active)) drivers.push(active);
    localStorage.setItem('lang', language);
    localStorage.setItem('atselog.theme', settings.dark_mode ? 'dark' : 'light');
    localStorage.setItem('convoy_mode', settings.convoy_mode ? '1' : '0');
    localStorage.setItem('atselog.personalDriving', settings.personal_driving ? '1' : '0');
    localStorage.setItem('tz_mode', ['off', 'auto', 'htz'].includes(settings.timezone_mode) ? settings.timezone_mode : 'off');
    localStorage.setItem('atselog.drivers.v1', JSON.stringify(drivers));
    if (active) localStorage.setItem('nomChauffeur', active);
    return before !== JSON.stringify(localSettings());
  }

  async function request(method, body) {
    const options = { method, headers: { 'Accept': 'application/json' } };
    if (body) {
      options.headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(body);
    }
    // Une lecture sans conducteur retourne toujours le conducteur actif du
    // plugin. C'est ce qui permet à PC, Web App et APK de se rejoindre.
    const response = await fetch(profileEndpoint, options);
    if (!response.ok) throw new Error('profile request failed');
    return response.json();
  }

  async function save(settings) {
    const normalized = settings || localSettings();
    applySettings(normalized);
    try {
      const reply = await request('POST', { settings: normalized });
      if (reply && reply.settings) applySettings(reply.settings);
      hasUnsavedSettings = false;
      return true;
    } catch (_) {
      // Hors connexion, la copie locale reste prête à être envoyée au prochain ATS.
      return false;
    }
  }

  async function activateDriver(value) {
    const driver = cleanDriver(value);
    if (!driver) return false;
    let preferences = null;
    try {
      const response = await fetch(`${profileEndpoint}?driver=${encodeURIComponent(driver)}`, {
        headers: { 'Accept': 'application/json' }
      });
      const reply = response.ok ? await response.json() : null;
      if (reply?.settings?.initialized) preferences = reply.settings;
    } catch (_) {}

    const local = localSettings();
    const drivers = [...new Set([...(local.drivers || []), ...(preferences?.drivers || []), driver])];
    const next = {
      ...local,
      ...(preferences || {}),
      drivers,
      active_driver: driver
    };
    applySettings(next);
    return save(next);
  }

  async function syncFromServer(respectUnsavedChanges = false) {
    try {
      const reply = await request('GET');
      if (!reply?.settings) return false;
      if (reply.settings.initialized) {
        // Ne jamais écraser un formulaire modifié avant Enregistrer. Dès que
        // le réglage est sauvegardé, les autres interfaces peuvent recevoir
        // la nouvelle version automatiquement.
        if (respectUnsavedChanges && hasUnsavedSettings) return false;
        return applySettings(reply.settings);
      }
      await save(localSettings());
    } catch (_) {}
    return false;
  }

  window.ATS_ELOG_UI_PROFILE = {
    localSettings, save, activateDriver, applySettings, syncFromServer, showConnectionCard,
    hasUnsavedSettings: () => hasUnsavedSettings,
    discardUnsavedSettings: () => { hasUnsavedSettings = false; }
  };

  // Les pages existantes possèdent déjà leur bouton Enregistrer. Ce pont les
  // conserve tels quels et ajoute simplement la sauvegarde du profil partagé.
  document.addEventListener('click', event => {
    if (event.target && event.target.id === 'saveBtn') setTimeout(() => save(localSettings()), 0);
  });

  // Les contrôles des Réglages enregistrent souvent leur valeur locale dès le
  // changement. Ce drapeau distingue une modification en cours d'une valeur
  // reçue depuis une autre interface.
  document.addEventListener('input', event => {
    if (event.target?.closest?.('main.settings')) hasUnsavedSettings = true;
  }, true);
  document.addEventListener('change', event => {
    if (event.target?.closest?.('main.settings')) hasUnsavedSettings = true;
  }, true);

  async function showConnectionCard() {
    // L'APK possède déjà une confirmation native fiable lors du changement de
    // camion/réseau. Ne jamais lui ajouter une seconde fenêtre Web : elle peut
    // rester au-dessus de l'interface après la validation native.
    if (window.Android && typeof window.Android.getApiBase === 'function') return;
    const now = Date.now();
    if (now - lastConnectionCardCheckAt < 2500) return;
    lastConnectionCardCheckAt = now;
    try {
      const identityResponse = await fetch('/api/vehicle/identity');
      if (!identityResponse.ok) return;
      const identity = await identityResponse.json();
      if (!identity || !identity.active || !identity.id) return;
      const scope = (window.Android && typeof window.Android.getApiBase === 'function')
        ? String(window.Android.getApiBase() || '') : window.location.origin;
      const key = `atselog.connection.confirmed.v1.${scope}.${identity.id}`;
      if (identity.session_confirmed === true) {
        localStorage.setItem(key, '1');
        document.getElementById('atselog-connection-card')?.remove();
        return;
      }
      if (localStorage.getItem(key) === '1' || document.getElementById('atselog-connection-card')) return;
      const vehicle = `${identity.make || ''} ${identity.model || ''}`.trim() || 'Camion ATS';
      const plate = [identity.plate, identity.plate_country].filter(Boolean).join(' ');
      const driver = cleanDriver(identity.driver) || cleanDriver(localStorage.getItem('nomChauffeur')) || 'Conducteur non sélectionné';
      const card = document.createElement('div');
      card.id = 'atselog-connection-card';
      card.style.cssText = 'position:fixed;inset:0;z-index:10001;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.58);padding:20px';
      card.innerHTML = `<section style="max-width:390px;width:100%;background:#fff;color:#17212b;border-radius:18px;padding:24px;box-sizing:border-box;text-align:center;box-shadow:0 12px 40px #0008;font-family:inherit"><h2 style="margin:0 0 16px">Confirmer la session</h2><p style="margin:9px 0">👤 <strong>${escapeHtml(driver)}</strong></p><p style="margin:9px 0">🚛 <strong>${escapeHtml(vehicle)}</strong></p><p style="margin:9px 0">🪪 ${escapeHtml(plate || 'Plaque non disponible')}</p><p style="font-size:.9em;color:#56616d;margin:18px 0">Confirme que tu conduis ce camion avant de charger les données ATS Elog.</p><button type="button" data-confirm style="border:0;border-radius:10px;background:#1f4f8c;color:#fff;font-weight:700;padding:12px 25px;font-size:1em;cursor:pointer">Confirmer la session</button></section>`;
      card.querySelector('[data-confirm]').addEventListener('click', async event => {
        const button = event.currentTarget;
        button.disabled = true;
        try {
          const response = await fetch('/api/vehicle/confirm-session', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({ id: identity.id })
          });
          if (!response.ok) throw new Error('session confirmation failed');
          localStorage.setItem(key, '1');
          save(localSettings());
          card.remove();
        } catch (_) {
          button.disabled = false;
          button.textContent = 'Réessayer';
        }
      });
      document.body.appendChild(card);
    } catch (_) {}
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
  }

  document.addEventListener('DOMContentLoaded', async () => {
    const changed = await syncFromServer(false);
    window.dispatchEvent(new CustomEvent('atselog:profile-synced', { detail: { changed } }));
    showConnectionCard();
    if (changed) setTimeout(() => window.location.reload(), 60);
  }, { once: true });

  // Une autre interface peut sélectionner un conducteur pendant que celle-ci
  // reste ouverte. Vérification légère, et immédiate au retour au premier plan.
  let syncInProgress = false;
  async function refreshActiveDriver() {
    if (syncInProgress || document.hidden) return;
    syncInProgress = true;
    const changed = await syncFromServer(true);
    syncInProgress = false;
    if (changed) window.location.reload();
  }
  setInterval(refreshActiveDriver, 3500);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshActiveDriver(); });
})();
