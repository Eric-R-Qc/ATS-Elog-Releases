/* Gestion des conducteurs depuis la barre bleue, sans modifier les LogBooks ATS. */
(() => {
  const clean = value => String(value || '').replace(/^🪪\s*/u, '').trim().replace(/\s+/g, ' ').slice(0, 80);
  const labels = {
    fr: { title: 'Conducteur', help: 'Les LogBooks restent associés à la sauvegarde ATS.', add: 'Ajouter un conducteur', remove: 'Supprimer le conducteur sélectionné', cancel: 'Annuler', confirm: 'Confirmer', prompt: 'Nom du nouveau conducteur', onlyOne: 'Il faut conserver au moins un conducteur.', ask: name => `Supprimer « ${name} » de la liste des conducteurs ?`, active: 'Ce conducteur est actif. Un autre conducteur sera sélectionné.', saveError: 'La suppression n’a pas pu être synchronisée.' },
    en: { title: 'Driver', help: 'LogBooks remain associated with the ATS save.', add: 'Add a driver', remove: 'Remove selected driver', cancel: 'Cancel', confirm: 'Confirm', prompt: 'New driver name', onlyOne: 'At least one driver must remain.', ask: name => `Remove “${name}” from the driver list?`, active: 'This driver is active. Another driver will be selected.', saveError: 'The deletion could not be synchronized.' },
    es: { title: 'Conductor', help: 'Los registros siguen vinculados a la partida guardada de ATS.', add: 'Añadir un conductor', remove: 'Eliminar el conductor seleccionado', cancel: 'Cancelar', confirm: 'Confirmar', prompt: 'Nombre del nuevo conductor', onlyOne: 'Debe conservarse al menos un conductor.', ask: name => `¿Eliminar a « ${name} » de la lista de conductores?`, active: 'Este conductor está activo. Se seleccionará otro conductor.', saveError: 'No se pudo sincronizar la eliminación.' },
    de: { title: 'Fahrer', help: 'Die Protokolle bleiben mit dem ATS-Spielstand verknüpft.', add: 'Fahrer hinzufügen', remove: 'Ausgewählten Fahrer löschen', cancel: 'Abbrechen', confirm: 'Bestätigen', prompt: 'Name des neuen Fahrers', onlyOne: 'Mindestens ein Fahrer muss erhalten bleiben.', ask: name => `„${name}“ aus der Fahrerliste löschen?`, active: 'Dieser Fahrer ist aktiv. Ein anderer Fahrer wird ausgewählt.', saveError: 'Die Löschung konnte nicht synchronisiert werden.' }
  };
  const ui = () => labels[localStorage.getItem('lang')] || labels.fr;

  function drivers() {
    try {
      const saved = JSON.parse(localStorage.getItem('atselog.drivers.v1') || '[]');
      return Array.isArray(saved) ? [...new Set(saved.map(clean).filter(Boolean))] : [];
    } catch (_) { return []; }
  }

  function saveDrivers(list) {
    localStorage.setItem('atselog.drivers.v1', JSON.stringify([...new Set(list.map(clean).filter(Boolean))].slice(0, 20)));
  }

  document.addEventListener('DOMContentLoaded', () => {
    // La carte d'identité déjà présente dans la barre est l'unique accès au
    // choix conducteur : inutile d'ajouter une seconde icône 👤.
    const button = document.getElementById('affichageChauffeur');
    if (!button || button.dataset.driverManagerBound === '1') return;
    button.dataset.driverManagerBound = '1';
    button.title = 'Conducteur';
    button.setAttribute('aria-label', 'Choisir le conducteur');
    button.setAttribute('role', 'button');
    button.tabIndex = 0;
    button.style.cursor = 'pointer';

    const openDriverDialog = () => {
      if (document.getElementById('driverProfileDialog')) return;
      const current = clean(localStorage.getItem('nomChauffeur'));
      const dialog = document.createElement('div');
      dialog.id = 'driverProfileDialog';
      dialog.style.cssText = 'position:fixed;inset:0;z-index:10002;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.58);padding:20px';
      const text = ui();
      dialog.innerHTML = `<section style="max-width:390px;width:100%;background:#fff;color:#17212b;border-radius:18px;padding:22px;box-sizing:border-box;box-shadow:0 12px 40px #0008;font-family:inherit"><h2 style="margin:0 0 12px;text-align:center">👤 ${text.title}</h2><select data-driver aria-label="${text.title}" style="width:100%;padding:10px;border-radius:8px;border:1px solid #b9c3cd"></select><div style="display:flex;gap:8px;margin-top:10px"><button type="button" data-add title="${text.add}" aria-label="${text.add}" style="border:0;background:transparent;color:#1f4f8c;font-size:1.2em;font-weight:700;cursor:pointer">👤＋</button><button type="button" data-remove title="${text.remove}" aria-label="${text.remove}" style="border:0;background:transparent;color:#b42318;font-size:1.15em;font-weight:700;cursor:pointer">🗑️</button></div><p style="font-size:.82em;color:#65707b;line-height:1.35">${text.help}</p><p data-message aria-live="polite" style="min-height:1.2em;margin:.2rem 0;color:#b42318;font-size:.82em"></p><div style="display:flex;gap:10px;justify-content:flex-end"><button type="button" data-cancel title="${text.cancel}" aria-label="${text.cancel}" style="padding:9px 13px;border:1px solid #d5a5a5;border-radius:9px;background:#fff;font-size:1.1em">❌</button><button type="button" data-confirm title="${text.confirm}" aria-label="${text.confirm}" style="padding:9px 13px;border:0;border-radius:9px;background:#15803d;color:#fff;font-size:1.1em;font-weight:700">✔️</button></div></section>`;
      const select = dialog.querySelector('[data-driver]');
      const message = dialog.querySelector('[data-message]');
      const showAction = ({ title, body, input = false, onConfirm }) => {
        const action = document.createElement('div');
        action.style.cssText = 'position:fixed;inset:0;z-index:10003;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.32);padding:20px';
        action.innerHTML = `<section style="max-width:340px;width:100%;background:#fff;color:#17212b;border-radius:14px;padding:20px;box-sizing:border-box;box-shadow:0 10px 30px #0007;font-family:inherit"><h3 style="margin:0 0 10px">${title}</h3><p style="margin:0 0 14px;white-space:pre-line">${body}</p>${input ? `<input data-name aria-label="${text.prompt}" style="width:100%;box-sizing:border-box;padding:10px;border-radius:8px;border:1px solid #b9c3cd" autofocus>` : ''}<div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px"><button type="button" data-action-cancel title="${text.cancel}" aria-label="${text.cancel}" style="padding:9px 13px;border:1px solid #d5a5a5;border-radius:9px;background:#fff;font-size:1.1em">❌</button><button type="button" data-action-confirm title="${text.confirm}" aria-label="${text.confirm}" style="padding:9px 13px;border:0;border-radius:9px;background:#15803d;color:#fff;font-size:1.1em;font-weight:700">✔️</button></div></section>`;
        action.querySelector('[data-action-cancel]').onclick = () => action.remove();
        action.querySelector('[data-action-confirm]').onclick = async () => {
          const value = input ? clean(action.querySelector('[data-name]').value) : '';
          if (input && !value) return;
          await onConfirm(value);
          action.remove();
        };
        dialog.appendChild(action);
        action.querySelector('[data-name]')?.focus();
      };
      const populate = chosen => {
        const names = drivers();
        if (current && !names.includes(current)) names.push(current);
        select.replaceChildren(...names.map(name => {
          const option = document.createElement('option'); option.value = name; option.textContent = name; return option;
        }));
        if (chosen) select.value = chosen;
      };
      populate(current);
      dialog.querySelector('[data-add]').addEventListener('click', () => {
        showAction({ title: text.add, body: text.prompt, input: true, onConfirm: name => {
          const names = drivers(); if (!names.includes(name)) names.push(name); saveDrivers(names); populate(name);
        }});
      });
      dialog.querySelector('[data-remove]').addEventListener('click', async () => {
        const name = clean(select.value);
        const names = drivers();
        if (current && !names.includes(current)) names.push(current);
        if (!name || names.length <= 1) { message.textContent = text.onlyOne; return; }
        showAction({ title: text.remove, body: `${text.ask(name)}${name === current ? `\n\n${text.active}` : ''}`, onConfirm: async () => {
          const remaining = names.filter(driver => driver !== name);
          const nextDriver = name === current ? remaining[0] : current;
          saveDrivers(remaining);
          let saved = true;
          try {
            saved = await window.ATS_ELOG_UI_PROFILE?.save({
              ...window.ATS_ELOG_UI_PROFILE.localSettings(), drivers: remaining,
              active_driver: nextDriver, replace_drivers: true
            });
          } catch (_) { saved = false; }
          if (!saved) { message.textContent = text.saveError; return; }
          if (name === current) localStorage.setItem('nomChauffeur', nextDriver);
          message.textContent = '';
          populate(nextDriver);
        }});
      });
      dialog.querySelector('[data-cancel]').addEventListener('click', () => dialog.remove());
      dialog.querySelector('[data-confirm]').addEventListener('click', async () => {
        const name = clean(select.value);
        if (!name) return;
        try {
          await window.ATS_ELOG_UI_PROFILE?.activateDriver(name);
        } catch (_) {}
        dialog.remove();
        window.location.reload();
      });
      document.body.appendChild(dialog);
    };
    button.addEventListener('click', openDriverDialog);
    button.addEventListener('keydown', event => {
      if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); openDriverDialog(); }
    });
  });
})();
